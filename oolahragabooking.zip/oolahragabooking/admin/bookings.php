<?php 
include '../config/database.php';
if (!isLoggedIn() || !isAdmin()) {
    header("Location: ../login.php");
    exit();
}

function redirectBookings($params = '') {
    header("Location: bookings.php" . $params);
    exit();
}

function normalizeTimeInputAdmin($time) {
    $time = trim((string) $time);
    if (!preg_match('/^([0-9]{1,2}):([0-9]{2})(:[0-9]{2})?$/', $time, $m)) {
        return '';
    }
    $hour = (int) $m[1];
    $minute = (int) $m[2];
    if ($hour < 0 || $hour > 23 || $minute < 0 || $minute > 59) {
        return '';
    }
    return sprintf('%02d:%02d:00', $hour, $minute);
}

function timeToMinutesAdmin($time) {
    $parts = explode(':', $time);
    return ((int) $parts[0] * 60) + (int) $parts[1];
}

function hitungHargaFleksibelAdmin($hargaPerJam, $durasiMenit) {
    return (int) ceil(((float) $hargaPerJam / 60) * $durasiMenit);
}

function getOwnedBookingIdsAdmin(PDO $pdo, int $adminId, array $ids): array {
    $ids = array_values(array_unique(array_filter(array_map('intval', $ids), fn($id) => $id > 0)));
    if (!$ids) return [];
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $pdo->prepare("SELECT b.id FROM bookings b JOIN lapangan l ON b.lapangan_id = l.id WHERE l.admin_id = ? AND b.id IN ($placeholders)");
    $stmt->execute(array_merge([$adminId], $ids));
    return array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));
}

function hideBookingsFromAdmin(PDO $pdo, int $adminId, array $ids): int {
    $owned = getOwnedBookingIdsAdmin($pdo, $adminId, $ids);
    if (!$owned) return 0;
    $stmt = $pdo->prepare("INSERT IGNORE INTO admin_booking_hidden (admin_id, booking_id) VALUES (?, ?)");
    $count = 0;
    foreach ($owned as $bookingId) {
        $stmt->execute([$adminId, $bookingId]);
        $count += $stmt->rowCount();
    }
    return $count;
}

function showBookingsToAdmin(PDO $pdo, int $adminId, array $ids): int {
    $owned = getOwnedBookingIdsAdmin($pdo, $adminId, $ids);
    if (!$owned) return 0;
    $placeholders = implode(',', array_fill(0, count($owned), '?'));
    $stmt = $pdo->prepare("DELETE FROM admin_booking_hidden WHERE admin_id = ? AND booking_id IN ($placeholders)");
    $stmt->execute(array_merge([$adminId], $owned));
    return $stmt->rowCount();
}

function bookingGroupKeyAdmin($booking): string {
    return (int)$booking['lapangan_id'] . '_' . (int)$booking['nomor_lapangan'];
}

function formatBookingDateTimeAdmin($booking): string {
    return date('d/m/Y', strtotime($booking['tanggal'])) . ' · ' . substr($booking['jam_mulai'], 0, 5) . ' - ' . substr($booking['jam_selesai'], 0, 5);
}

function renderTeamListAdmin($participants, $team) {
    $items = array_filter($participants ?? [], fn($p) => $p['team'] === $team);
    if (!$items) return '<small class="small-muted">Belum ada pemain</small>';
    $html = '<div class="team-mini-list">';
    foreach ($items as $p) {
        $badge = $p['status'] === 'accepted' ? 'completed' : ($p['status'] === 'rejected' ? 'rejected' : 'waiting');
        $html .= '<span><b>' . e($p['player_name']) . '</b> <small>ID ' . e($p['player_code']) . '</small> <em class="match-badge ' . $badge . '">' . e($p['status']) . '</em></span>';
    }
    $html .= '</div>';
    return $html;
}

$adminId = (int) $_SESSION['user_id'];

// Tambah booking langsung/offline untuk pelanggan yang datang ke lapangan
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_offline_booking'])) {
    $lapangan_id = (int) ($_POST['lapangan_id'] ?? 0);
    $nomor_lapangan = (int) ($_POST['nomor_lapangan'] ?? 1);
    $nama_pelanggan = trim($_POST['nama_pelanggan'] ?? 'Pelanggan Offline');
    $telepon_pelanggan = trim($_POST['telepon_pelanggan'] ?? '');
    $tanggal = $_POST['tanggal'] ?? '';
    $jam_mulai = normalizeTimeInputAdmin($_POST['jam_mulai'] ?? '');
    $jam_selesai = normalizeTimeInputAdmin($_POST['jam_selesai'] ?? '');
    $payment_status = ($_POST['payment_status'] ?? '') === 'paid' ? 'paid' : 'unpaid';
    $catatan = trim($_POST['catatan'] ?? '');

    $cekLapangan = $pdo->prepare("SELECT id, nama_lapangan, harga_per_jam, jumlah_lapangan FROM lapangan WHERE id = ? AND admin_id = ?");
    $cekLapangan->execute([$lapangan_id, $adminId]);
    $field = $cekLapangan->fetch();

    $durasiMenit = ($jam_mulai && $jam_selesai) ? (timeToMinutesAdmin($jam_selesai) - timeToMinutesAdmin($jam_mulai)) : 0;

    if (!$field) {
        redirectBookings('?error=Lapangan tidak valid');
    } elseif ($nama_pelanggan === '') {
        redirectBookings('?error=Nama pelanggan wajib diisi');
    } elseif ($tanggal < date('Y-m-d')) {
        redirectBookings('?error=Tanggal booking tidak boleh tanggal lewat');
    } elseif ($nomor_lapangan < 1 || $nomor_lapangan > (int) $field['jumlah_lapangan']) {
        redirectBookings('?error=Nomor lapangan tidak valid');
    } elseif (!$jam_mulai || !$jam_selesai) {
        redirectBookings('?error=Format jam tidak valid');
    } elseif ($durasiMenit < 15) {
        redirectBookings('?error=Durasi minimal booking langsung adalah 15 menit');
    } elseif (timeToMinutesAdmin($jam_mulai) < 360 || timeToMinutesAdmin($jam_selesai) > 1380) {
        redirectBookings('?error=Jam booking harus berada di antara 06:00 - 23:00');
    }

    try {
        $pdo->beginTransaction();

        $cekBooking = $pdo->prepare("SELECT id FROM bookings
                                     WHERE lapangan_id = ?
                                     AND nomor_lapangan = ?
                                     AND tanggal = ?
                                     AND status <> 'cancelled'
                                     AND jam_mulai < ?
                                     AND jam_selesai > ?
                                     LIMIT 1 FOR UPDATE");
        $cekBooking->execute([$lapangan_id, $nomor_lapangan, $tanggal, $jam_selesai, $jam_mulai]);

        $cekTutup = $pdo->prepare("SELECT id FROM lapangan_tutup
                                   WHERE lapangan_id = ?
                                   AND nomor_lapangan = ?
                                   AND tanggal = ?
                                   AND jam_mulai < ?
                                   AND jam_selesai > ?
                                   LIMIT 1 FOR UPDATE");
        $cekTutup->execute([$lapangan_id, $nomor_lapangan, $tanggal, $jam_selesai, $jam_mulai]);

        if ($cekBooking->fetch()) {
            $pdo->rollBack();
            redirectBookings('?error=Jam tersebut sudah ada booking. Pilih jam lain.');
        }
        if ($cekTutup->fetch()) {
            $pdo->rollBack();
            redirectBookings('?error=Jam tersebut sedang ditutup admin. Pilih jam lain.');
        }

        $total_harga = hitungHargaFleksibelAdmin($field['harga_per_jam'], $durasiMenit);
        $platform_fee = calculatePlatformFee($total_harga);
        $owner_amount = max(0, $total_harga - $platform_fee);
        $booking_code = 'OFF' . date('Ymd') . rand(1000, 9999);

        $stmt = $pdo->prepare("INSERT INTO bookings
            (user_id, lapangan_id, nomor_lapangan, tanggal, jam_mulai, jam_selesai, total_harga, platform_fee, owner_amount, status, payment_method, payment_status, booking_code, booking_source, nama_pelanggan, telepon_pelanggan, catatan)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'confirmed', 'offline_cash', ?, ?, 'offline', ?, ?, ?)");
        $stmt->execute([$adminId, $lapangan_id, $nomor_lapangan, $tanggal, $jam_mulai, $jam_selesai, $total_harga, $platform_fee, $owner_amount, $payment_status, $booking_code, $nama_pelanggan, $telepon_pelanggan, $catatan]);
        $booking_id = $pdo->lastInsertId();

        if ($payment_status === 'paid') {
            $transaction_code = 'OFFTRX' . date('YmdHis') . rand(100, 999);
            $trx = $pdo->prepare("INSERT INTO transactions (booking_id, user_id, amount, payment_method, payment_channel, transaction_code, status, payment_date)
                                  VALUES (?, ?, ?, 'offline_cash', 'Bayar Langsung di Lapangan', ?, 'success', NOW())");
            $trx->execute([$booking_id, $adminId, $total_harga, $transaction_code]);
        }

        $pdo->commit();
        redirectBookings('?success=Booking langsung/offline berhasil ditambahkan');
    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        redirectBookings('?error=' . urlencode('Booking langsung gagal: ' . $e->getMessage()));
    }
}

// Update status booking dari admin lapangan.
// Jika cancelled, jadwal otomatis terbuka lagi karena sistem bentrok hanya membaca booking status selain cancelled.
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_status'])) {
    $booking_id = (int) $_POST['booking_id'];
    $status = $_POST['status'] ?? '';
    if (!in_array($status, ['pending', 'paid', 'confirmed', 'cancelled'], true)) {
        redirectBookings('?error=Status tidak valid');
    }
    $cekOwner = $pdo->prepare("SELECT b.id FROM bookings b JOIN lapangan l ON b.lapangan_id = l.id WHERE b.id = ? AND l.admin_id = ?");
    $cekOwner->execute([$booking_id, $adminId]);
    if (!$cekOwner->fetch()) redirectBookings('?error=Booking bukan milik lapangan kamu');

    syncTransactionFromBookingStatus($pdo, $booking_id, $status);
    redirectBookings('?success=Status booking berhasil diupdate. Jika dibatalkan, slot jadwal sudah bisa dibooking lagi.');
}

// Bersihkan tampilan booking admin lapangan saja. Data utama tetap aman di tabel bookings dan match_results.
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['booking_view_action'])) {
    $action = $_POST['booking_view_action'];
    try {
        if ($action === 'hide_single') {
            $total = hideBookingsFromAdmin($pdo, $adminId, [$_POST['booking_id'] ?? 0]);
            redirectBookings('?success=' . urlencode($total > 0 ? 'Booking berhasil dibersihkan dari tampilan.' : 'Booking sudah bersih atau tidak ditemukan.'));
        }

        if ($action === 'hide_selected') {
            $total = hideBookingsFromAdmin($pdo, $adminId, $_POST['booking_ids'] ?? []);
            redirectBookings('?success=' . urlencode($total . ' booking pilihan berhasil dibersihkan dari tampilan.'));
        }

        if ($action === 'hide_group') {
            $lapanganId = (int) ($_POST['lapangan_id'] ?? 0);
            $nomorLapangan = (int) ($_POST['nomor_lapangan'] ?? 0);
            $stmt = $pdo->prepare("SELECT b.id
                                   FROM bookings b
                                   JOIN lapangan l ON b.lapangan_id = l.id
                                   LEFT JOIN admin_booking_hidden abh ON abh.booking_id = b.id AND abh.admin_id = ?
                                   WHERE l.admin_id = ? AND b.lapangan_id = ? AND b.nomor_lapangan = ? AND abh.id IS NULL");
            $stmt->execute([$adminId, $adminId, $lapanganId, $nomorLapangan]);
            $total = hideBookingsFromAdmin($pdo, $adminId, $stmt->fetchAll(PDO::FETCH_COLUMN));
            redirectBookings('?success=' . urlencode($total . ' booking pada grup lapangan ini berhasil dibersihkan dari tampilan.'));
        }

        if ($action === 'hide_done') {
            $stmt = $pdo->prepare("SELECT b.id
                                   FROM bookings b
                                   JOIN lapangan l ON b.lapangan_id = l.id
                                   LEFT JOIN admin_booking_hidden abh ON abh.booking_id = b.id AND abh.admin_id = ?
                                   LEFT JOIN match_results mr ON mr.booking_id = b.id AND mr.user_id = b.user_id
                                   WHERE l.admin_id = ?
                                   AND abh.id IS NULL
                                   AND (
                                        b.status = 'cancelled'
                                        OR b.match_status IN ('inactive','completed','rejected','cancelled')
                                        OR (b.match_enabled = 1 AND mr.id IS NOT NULL)
                                   )");
            $stmt->execute([$adminId, $adminId]);
            $total = hideBookingsFromAdmin($pdo, $adminId, $stmt->fetchAll(PDO::FETCH_COLUMN));
            redirectBookings('?success=' . urlencode($total . ' booking yang sudah pasti selesai berhasil dibersihkan dari tampilan.'));
        }

        if ($action === 'hide_all_visible') {
            $stmt = $pdo->prepare("SELECT b.id
                                   FROM bookings b
                                   JOIN lapangan l ON b.lapangan_id = l.id
                                   LEFT JOIN admin_booking_hidden abh ON abh.booking_id = b.id AND abh.admin_id = ?
                                   WHERE l.admin_id = ? AND abh.id IS NULL");
            $stmt->execute([$adminId, $adminId]);
            $total = hideBookingsFromAdmin($pdo, $adminId, $stmt->fetchAll(PDO::FETCH_COLUMN));
            redirectBookings('?success=' . urlencode($total . ' booking berhasil dibersihkan dari tampilan.'));
        }

        if ($action === 'show_single') {
            $total = showBookingsToAdmin($pdo, $adminId, [$_POST['booking_id'] ?? 0]);
            redirectBookings('?tab=hidden&success=' . urlencode($total > 0 ? 'Booking berhasil ditampilkan lagi.' : 'Booking tidak ditemukan di daftar bersih.'));
        }

        if ($action === 'show_selected') {
            $total = showBookingsToAdmin($pdo, $adminId, $_POST['booking_ids'] ?? []);
            redirectBookings('?tab=hidden&success=' . urlencode($total . ' booking pilihan berhasil ditampilkan lagi.'));
        }

        if ($action === 'show_all') {
            $stmt = $pdo->prepare("SELECT b.id FROM bookings b JOIN lapangan l ON b.lapangan_id = l.id JOIN admin_booking_hidden abh ON abh.booking_id = b.id AND abh.admin_id = ? WHERE l.admin_id = ?");
            $stmt->execute([$adminId, $adminId]);
            $total = showBookingsToAdmin($pdo, $adminId, $stmt->fetchAll(PDO::FETCH_COLUMN));
            redirectBookings('?tab=hidden&success=' . urlencode($total . ' booking berhasil ditampilkan lagi.'));
        }
    } catch (Exception $e) {
        redirectBookings('?error=' . urlencode('Aksi bersihkan tampilan gagal: ' . $e->getMessage()));
    }
}

$stmt = $pdo->prepare("SELECT * FROM lapangan WHERE admin_id = ? ORDER BY nama_lapangan ASC");
$stmt->execute([$adminId]);
$lapangan_list = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT COUNT(*) AS total_waiting_match
                       FROM bookings b
                       JOIN lapangan l ON b.lapangan_id = l.id
                       LEFT JOIN admin_booking_hidden abh ON abh.booking_id = b.id AND abh.admin_id = ?
                       LEFT JOIN match_results mr ON mr.booking_id = b.id AND mr.user_id = b.user_id
                       WHERE l.admin_id = ? AND abh.id IS NULL AND b.match_enabled = 1 AND b.match_status = 'waiting_score' AND mr.id IS NULL");
$stmt->execute([$adminId, $adminId]);
$total_waiting_match = (int) $stmt->fetch()['total_waiting_match'];

$stmt = $pdo->prepare("SELECT b.*, l.nama_lapangan, l.jenis_olahraga,
                       COALESCE(NULLIF(b.nama_pelanggan, ''), NULLIF(u.display_name, ''), NULLIF(u.full_name, ''), u.username, 'User') AS nama_customer,
                       u.username,
                       mr.id AS match_result_id, mr.user_score, mr.opponent_score, mr.points, mr.winner
                       FROM bookings b
                       JOIN lapangan l ON b.lapangan_id = l.id
                       LEFT JOIN users u ON b.user_id = u.id
                       LEFT JOIN match_results mr ON mr.booking_id = b.id AND mr.user_id = b.user_id
                       LEFT JOIN admin_booking_hidden abh ON abh.booking_id = b.id AND abh.admin_id = ?
                       WHERE l.admin_id = ? AND abh.id IS NULL
                       ORDER BY l.nama_lapangan ASC, b.nomor_lapangan ASC, b.match_status = 'waiting_score' DESC, b.tanggal DESC, b.jam_mulai DESC, b.created_at DESC");
$stmt->execute([$adminId, $adminId]);
$bookings = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT b.*, l.nama_lapangan, l.jenis_olahraga,
                       COALESCE(NULLIF(b.nama_pelanggan, ''), NULLIF(u.display_name, ''), NULLIF(u.full_name, ''), u.username, 'User') AS nama_customer,
                       abh.hidden_at
                       FROM bookings b
                       JOIN lapangan l ON b.lapangan_id = l.id
                       LEFT JOIN users u ON b.user_id = u.id
                       JOIN admin_booking_hidden abh ON abh.booking_id = b.id AND abh.admin_id = ?
                       WHERE l.admin_id = ?
                       ORDER BY abh.hidden_at DESC, b.tanggal DESC, b.jam_mulai DESC");
$stmt->execute([$adminId, $adminId]);
$hidden_bookings = $stmt->fetchAll();

$participant_map = [];
if (count($bookings) > 0) {
    $ids = array_map(fn($b) => (int)$b['id'], $bookings);
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmtParticipants = $pdo->prepare("SELECT mp.*, COALESCE(NULLIF(u.display_name,''), NULLIF(u.full_name,''), u.username) AS player_name, u.player_code, u.username
                                      FROM match_participants mp
                                      JOIN users u ON mp.user_id = u.id
                                      WHERE mp.booking_id IN ($placeholders)
                                      ORDER BY mp.team ASC, mp.is_captain DESC, u.username ASC");
    $stmtParticipants->execute($ids);
    foreach ($stmtParticipants->fetchAll() as $part) {
        $participant_map[(int)$part['booking_id']][] = $part;
    }
}

$groups = [];
foreach ($bookings as $booking) {
    $key = bookingGroupKeyAdmin($booking);
    if (!isset($groups[$key])) {
        $groups[$key] = [
            'lapangan_id' => (int)$booking['lapangan_id'],
            'nomor_lapangan' => (int)$booking['nomor_lapangan'],
            'nama_lapangan' => $booking['nama_lapangan'],
            'jenis_olahraga' => $booking['jenis_olahraga'],
            'bookings' => [],
            'waiting_score' => 0,
        ];
    }
    if ((int)($booking['match_enabled'] ?? 0) === 1 && ($booking['match_status'] ?? '') === 'waiting_score' && empty($booking['match_result_id'])) {
        $groups[$key]['waiting_score']++;
    }
    $groups[$key]['bookings'][] = $booking;
}

$activeTab = ($_GET['tab'] ?? 'active') === 'hidden' ? 'hidden' : 'active';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Booking - Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .status-select { padding: 8px 12px; border-radius: 12px; border: 1px solid rgba(255,255,255,.14); background: rgba(255,255,255,.08); color: #fff; font-family: 'Poppins', sans-serif; }
        .admin-summary-grid { display:grid; grid-template-columns: repeat(auto-fit,minmax(160px,1fr)); gap:14px; margin:20px 0; }
        .admin-mini-card { background:rgba(255,255,255,.08); border:1px solid rgba(255,255,255,.12); border-radius:18px; padding:15px; }
        .admin-mini-card strong { display:block; color:#00ffb3; font-size:25px; }
        .small-muted { color:rgba(255,255,255,.65); font-size:12px; }
        .admin-booking-tabs { display:flex; flex-wrap:wrap; gap:10px; margin:0 0 14px; }
        .admin-booking-tabs a { text-decoration:none; color:#fff; padding:10px 14px; border-radius:999px; border:1px solid rgba(255,255,255,.14); background:rgba(255,255,255,.07); font-weight:700; }
        .admin-booking-tabs a.active { background:linear-gradient(135deg,#00ffb3,#00a3ff); color:#041014; border-color:transparent; }
        .booking-board-head { display:flex; justify-content:space-between; gap:14px; align-items:flex-start; flex-wrap:wrap; margin-bottom:12px; }
        .booking-board-tools { display:flex; gap:8px; flex-wrap:wrap; align-items:center; }
        .btn-danger-soft { border:1px solid rgba(255,80,80,.45); background:rgba(255,59,59,.12); color:#ffb7b7; border-radius:12px; padding:9px 12px; cursor:pointer; font-weight:700; }
        .btn-secondary.small-btn, .btn-primary.small-btn, .btn-danger-soft.small-btn { padding:7px 10px; border-radius:10px; font-size:12px; line-height:1.2; }
        .admin-group-list { display:flex; flex-direction:column; gap:14px; }
        .booking-field-group { border:1px solid rgba(255,255,255,.12); background:rgba(255,255,255,.055); border-radius:20px; overflow:hidden; }
        .booking-field-summary { width:100%; display:flex; align-items:center; justify-content:space-between; gap:12px; padding:15px 16px; background:rgba(0,0,0,.22); color:#fff; cursor:pointer; border:0; text-align:left; }
        .booking-field-title { display:flex; flex-direction:column; gap:4px; }
        .booking-field-title strong { font-size:18px; }
        .booking-field-meta { display:flex; flex-wrap:wrap; gap:8px; align-items:center; justify-content:flex-end; }
        .tiny-pill { display:inline-flex; align-items:center; gap:6px; border-radius:999px; padding:6px 9px; background:rgba(255,255,255,.1); border:1px solid rgba(255,255,255,.12); font-size:12px; font-weight:700; }
        .tiny-pill.warning { color:#ffe29a; border-color:rgba(255,201,71,.4); background:rgba(255,184,0,.12); }
        .booking-group-body { display:none; padding:14px; }
        .booking-field-group.open .booking-group-body { display:block; }
        .booking-code-toolbar { display:flex; justify-content:space-between; align-items:center; gap:10px; flex-wrap:wrap; margin-bottom:12px; padding-bottom:12px; border-bottom:1px solid rgba(255,255,255,.1); }
        .booking-code-list { display:grid; grid-template-columns:repeat(auto-fill,minmax(220px,1fr)); gap:10px; }
        .booking-code-item { display:grid; grid-template-columns:auto 1fr auto; align-items:center; gap:8px; padding:10px; border-radius:14px; background:rgba(0,0,0,.22); border:1px solid rgba(255,255,255,.1); }
        .booking-code-btn { border:0; background:transparent; color:#fff; text-align:left; cursor:pointer; padding:0; min-width:0; }
        .booking-code-btn strong { display:block; color:#00ffb3; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
        .booking-code-btn span { display:block; font-size:11px; color:rgba(255,255,255,.65); margin-top:3px; }
        .booking-code-item.is-active { border-color:rgba(0,255,179,.55); background:rgba(0,255,179,.09); }
        .booking-detail-wrap { margin-top:14px; }
        .admin-booking-card { display:none; border:1px solid rgba(0,255,179,.25); background:rgba(0,0,0,.28); border-radius:18px; padding:14px; }
        .admin-booking-card.active { display:block; }
        .admin-booking-top { display:flex; align-items:flex-start; justify-content:space-between; gap:12px; margin-bottom:10px; }
        .admin-booking-top small { display:block; color:rgba(255,255,255,.6); }
        .admin-booking-top strong { font-size:20px; color:#00ffb3; }
        .source-badge { display:inline-flex; padding:6px 10px; border-radius:999px; font-size:12px; font-weight:800; border:1px solid rgba(255,255,255,.15); }
        .source-badge.offline { background:rgba(255,184,0,.15); color:#ffd98a; }
        .source-badge.online { background:rgba(0,163,255,.13); color:#99dcff; }
        .admin-booking-info-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(160px,1fr)); gap:10px; }
        .admin-booking-info-grid div, .admin-control-box { padding:10px; border-radius:14px; background:rgba(255,255,255,.065); border:1px solid rgba(255,255,255,.08); }
        .admin-booking-info-grid small, .admin-control-box small { display:block; color:rgba(255,255,255,.62); margin-bottom:3px; }
        .admin-booking-info-grid b { display:block; color:#fff; }
        .admin-booking-info-grid span { display:block; color:rgba(255,255,255,.72); font-size:12px; margin-top:2px; }
        .admin-booking-control-grid { display:grid; grid-template-columns:minmax(180px,.7fr) minmax(260px,1.6fr) minmax(150px,.7fr); gap:10px; margin-top:10px; }
        .admin-control-box form { margin-top:6px; }
        .score-form { background:rgba(0,0,0,.22); border:1px solid rgba(255,255,255,.1); padding:10px; border-radius:14px; margin-top:8px; }
        .compact-score-form-card { display:grid; grid-template-columns: repeat(2,minmax(120px,1fr)) minmax(130px,1fr) auto; gap:8px; align-items:end; }
        .compact-score-form-card label { font-size:12px; color:rgba(255,255,255,.72); }
        .compact-score-form-card input, .compact-score-form-card textarea { width:100%; padding:8px; border-radius:10px; border:1px solid rgba(255,255,255,.15); background:rgba(255,255,255,.08); color:#fff; margin-top:4px; }
        .admin-teams-box.compact { display:grid; grid-template-columns:1fr 1fr; gap:8px; margin:8px 0; }
        .admin-teams-box.compact > div { border-radius:12px; background:rgba(0,0,0,.18); border:1px solid rgba(255,255,255,.08); padding:8px; }
        .team-mini-list { display:flex; flex-direction:column; gap:6px; margin-top:5px; }
        .team-mini-list span { display:block; font-size:12px; }
        .match-badge { display:inline-flex; align-items:center; border-radius:999px; padding:5px 8px; font-size:11px; font-weight:800; background:rgba(255,255,255,.12); color:#fff; margin:2px 0; }
        .match-badge.completed { background:rgba(0,255,179,.16); color:#7dffd8; }
        .match-badge.waiting { background:rgba(255,184,0,.16); color:#ffe29a; }
        .match-badge.rejected { background:rgba(255,59,59,.14); color:#ffb7b7; }
        .match-badge.inactive { background:rgba(255,255,255,.1); color:rgba(255,255,255,.68); }
        .action-stack { display:flex; flex-wrap:wrap; gap:7px; align-items:center; }
        .hidden-booking-list { display:grid; grid-template-columns:repeat(auto-fill,minmax(260px,1fr)); gap:10px; }
        .hidden-booking-item { border:1px solid rgba(255,255,255,.11); background:rgba(0,0,0,.22); border-radius:16px; padding:12px; display:grid; gap:8px; }
        .hidden-booking-row { display:flex; gap:9px; align-items:flex-start; }
        .empty-booking-box { padding:26px; border-radius:18px; border:1px dashed rgba(255,255,255,.18); text-align:center; color:rgba(255,255,255,.7); }
        .offline-price-preview { grid-column:1 / -1; padding:10px 12px; border-radius:14px; background:rgba(0,255,179,.09); border:1px solid rgba(0,255,179,.18); color:#bfffee; }
        @media(max-width:1050px){ .admin-booking-control-grid { grid-template-columns:1fr; } .compact-score-form-card { grid-template-columns:1fr; } }
        @media(max-width:700px){ .booking-field-summary, .booking-code-toolbar { align-items:flex-start; flex-direction:column; } .booking-code-list { grid-template-columns:1fr; } .admin-teams-box.compact { grid-template-columns:1fr; } }
    </style>
</head>
<body>
<div class="top-header">
    <div class="promo-box"> Kelola Booking <span>ADMIN</span></div>
    <div class="top-right">
        <div class="user-info">
            <i class="fa-regular fa-user"></i> <?= htmlspecialchars($_SESSION['username']) ?>
            <a href="../logout.php" style="color:#ff003c;">Logout</a>
        </div>
    </div>
</div>
<?php renderNavbar('../'); ?>

<div class="dashboard-wrapper">
    <div class="sidebar">
        <h2>Menu Admin</h2>
        <a href="dashboard.php"><i class="fa-solid fa-chart-line"></i> Dashboard</a>
        <a href="lapangan.php"><i class="fa-solid fa-futbol"></i> Kelola Lapangan</a>
        <a href="bookings.php" class="active"><i class="fa-solid fa-calendar-check"></i> Kelola Booking</a>
        <a href="transactions.php"><i class="fa-solid fa-credit-card"></i> Transaksi</a>
        <a href="../marketplace.php"><i class="fa-solid fa-store"></i> Market Olahraga</a>
        <a href="../logout.php"><i class="fa-solid fa-sign-out-alt"></i> Logout</a>
    </div>
    
    <div class="main-content">
        <h1>Kelola Booking</h1>
        <p>Booking online dan booking langsung/offline akan sama-sama memblokir jadwal agar tidak bentrok.</p>
        <div class="admin-summary-grid">
            <div class="admin-mini-card"><small>Booking Tampil</small><strong><?= count($bookings) ?></strong></div>
            <div class="admin-mini-card"><small>Menunggu Skor</small><strong><?= $total_waiting_match ?></strong></div>
            <div class="admin-mini-card"><small>Sudah Dibersihkan</small><strong><?= count($hidden_bookings) ?></strong></div>
            <div class="admin-mini-card"><small>Grup Lapangan</small><strong><?= count($groups) ?></strong></div>
        </div>

        <?php if($total_waiting_match > 0): ?>
            <div class="match-notification"><i class="fa-solid fa-bell"></i> Ada <strong><?= $total_waiting_match ?></strong> mode tanding yang menunggu input skor akhir.</div>
        <?php endif; ?>

        <?php if(isset($_GET['success'])): ?>
            <div class="alert-success"><?= htmlspecialchars($_GET['success']) ?></div>
        <?php endif; ?>
        <?php if(isset($_GET['error'])): ?>
            <div class="alert-error"><?= htmlspecialchars($_GET['error']) ?></div>
        <?php endif; ?>

        <div class="form-card">
            <h2>Tambah Booking Langsung / Offline</h2>
            <p class="helper-text">Pakai form ini kalau ada pelanggan datang langsung ke lapangan, misalnya main 07:43 - 08:43. Jadwal ini otomatis tidak bisa dibooking user online.</p>
            <form method="POST" class="admin-grid-form" id="offlineBookingForm">
                <input type="text" name="nama_pelanggan" placeholder="Nama pelanggan offline" required>
                <input type="text" name="telepon_pelanggan" placeholder="No. HP pelanggan (opsional)">
                <select name="lapangan_id" id="offlineLapanganSelect" required>
                    <option value="">Pilih Lapangan</option>
                    <?php foreach($lapangan_list as $l): ?>
                        <option value="<?= $l['id'] ?>" data-jumlah="<?= (int) $l['jumlah_lapangan'] ?>" data-harga="<?= (float) $l['harga_per_jam'] ?>">
                            <?= htmlspecialchars($l['nama_lapangan']) ?> - <?= (int) $l['jumlah_lapangan'] ?> unit
                        </option>
                    <?php endforeach; ?>
                </select>
                <select name="nomor_lapangan" id="offlineNomorLapanganSelect" required>
                    <option value="1">Lapangan 1</option>
                </select>
                <input type="date" name="tanggal" min="<?= date('Y-m-d') ?>" required>
                <input type="time" name="jam_mulai" id="offlineJamMulai" step="60" min="06:00" max="22:59" required>
                <input type="time" name="jam_selesai" id="offlineJamSelesai" step="60" min="06:01" max="23:00" required>
                <select name="payment_status" required>
                    <option value="paid">Sudah bayar di tempat</option>
                    <option value="unpaid">Belum bayar</option>
                </select>
                <textarea name="catatan" placeholder="Catatan booking offline (opsional)" rows="2"></textarea>
                <div class="offline-price-preview" id="offlinePricePreview">Total akan dihitung otomatis dari durasi x harga per jam.</div>
                <button type="submit" name="add_offline_booking" class="btn-primary">Simpan Booking Offline</button>
            </form>
        </div>
        
        <div class="form-card admin-booking-list-card">
            <div class="booking-board-head">
                <div>
                    <h2>Daftar Booking</h2>
                    <p class="helper-text">Booking dipisah per lapangan. Klik grup lapangan, lalu klik kode booking untuk membuka detail kartu. Tombol bersihkan hanya menyembunyikan dari tampilan admin, bukan menghapus database.</p>
                </div>
                <div class="booking-board-tools">
                    <form method="POST" onsubmit="return confirm('Bersihkan semua booking yang sudah pasti selesai dari tampilan? Data tetap aman di database.');">
                        <input type="hidden" name="booking_view_action" value="hide_done">
                        <button type="submit" class="btn-secondary small-btn"><i class="fa-solid fa-broom"></i> Bersihkan yang Selesai</button>
                    </form>
                    <form method="POST" onsubmit="return confirm('Bersihkan SEMUA booking yang tampil? Data tetap aman di database.');">
                        <input type="hidden" name="booking_view_action" value="hide_all_visible">
                        <button type="submit" class="btn-danger-soft small-btn"><i class="fa-solid fa-eye-slash"></i> Bersihkan Semua Tampil</button>
                    </form>
                </div>
            </div>

            <div class="admin-booking-tabs">
                <a href="bookings.php" class="<?= $activeTab === 'active' ? 'active' : '' ?>">Booking Tampil</a>
                <a href="bookings.php?tab=hidden" class="<?= $activeTab === 'hidden' ? 'active' : '' ?>">Sudah Dibersihkan</a>
            </div>

            <?php if($activeTab === 'active'): ?>
                <div class="admin-group-list">
                    <?php foreach($groups as $groupKey => $group): ?>
                        <?php $formId = 'hide_group_form_' . preg_replace('/[^a-zA-Z0-9_]/', '_', $groupKey); ?>
                        <section class="booking-field-group">
                            <button type="button" class="booking-field-summary">
                                <div class="booking-field-title">
                                    <strong><?= e($group['nama_lapangan']) ?> - Lapangan <?= (int)$group['nomor_lapangan'] ?></strong>
                                    <small><?= e($group['jenis_olahraga']) ?></small>
                                </div>
                                <div class="booking-field-meta">
                                    <span class="tiny-pill"><i class="fa-solid fa-ticket"></i> <?= count($group['bookings']) ?> booking</span>
                                    <?php if($group['waiting_score'] > 0): ?><span class="tiny-pill warning"><i class="fa-solid fa-trophy"></i> <?= $group['waiting_score'] ?> tunggu skor</span><?php endif; ?>
                                    <span class="tiny-pill"><i class="fa-solid fa-chevron-down"></i> Klik buka</span>
                                </div>
                            </button>
                            <div class="booking-group-body">
                                <div class="booking-code-toolbar">
                                    <div>
                                        <b>Pilih kode booking</b>
                                        <p class="small-muted">Detail kartu hanya muncul untuk booking yang diklik.</p>
                                    </div>
                                    <div class="booking-board-tools">
                                        <form method="POST" id="<?= e($formId) ?>" onsubmit="return confirm('Bersihkan booking pilihan dari tampilan? Data tetap aman di database.');">
                                            <input type="hidden" name="booking_view_action" value="hide_selected">
                                            <button type="submit" class="btn-secondary small-btn"><i class="fa-solid fa-check-square"></i> Bersihkan Pilihan</button>
                                        </form>
                                        <form method="POST" onsubmit="return confirm('Bersihkan semua booking dalam grup lapangan ini dari tampilan? Data tetap aman di database.');">
                                            <input type="hidden" name="booking_view_action" value="hide_group">
                                            <input type="hidden" name="lapangan_id" value="<?= (int)$group['lapangan_id'] ?>">
                                            <input type="hidden" name="nomor_lapangan" value="<?= (int)$group['nomor_lapangan'] ?>">
                                            <button type="submit" class="btn-danger-soft small-btn"><i class="fa-solid fa-broom"></i> Bersihkan Grup</button>
                                        </form>
                                    </div>
                                </div>

                                <div class="booking-code-list">
                                    <?php foreach($group['bookings'] as $index => $booking): ?>
                                        <?php $detailId = 'booking_detail_' . (int)$booking['id']; ?>
                                        <div class="booking-code-item">
                                            <input type="checkbox" name="booking_ids[]" value="<?= (int)$booking['id'] ?>" form="<?= e($formId) ?>" aria-label="Pilih booking <?= e($booking['booking_code']) ?>">
                                            <button type="button" class="booking-code-btn" data-target="<?= e($detailId) ?>">
                                                <strong><?= e($booking['booking_code'] ?: ('BOOK-' . $booking['id'])) ?></strong>
                                                <span><?= e($booking['nama_customer']) ?> · <?= formatBookingDateTimeAdmin($booking) ?></span>
                                            </button>
                                            <?php if((int)($booking['match_enabled'] ?? 0) === 1 && ($booking['match_status'] ?? '') === 'waiting_score' && empty($booking['match_result_id'])): ?>
                                                <span class="match-badge waiting">Skor</span>
                                            <?php else: ?>
                                                <span class="source-badge <?= e($booking['booking_source'] ?? 'online') ?>"><?= e(($booking['booking_source'] ?? 'online') === 'offline' ? 'OFF' : 'ON') ?></span>
                                            <?php endif; ?>
                                        </div>
                                    <?php endforeach; ?>
                                </div>

                                <div class="booking-detail-wrap">
                                    <?php foreach($group['bookings'] as $booking): ?>
                                        <?php
                                            $parts = $participant_map[(int)$booking['id']] ?? [];
                                            $matchStatus = $booking['match_status'] ?? 'inactive';
                                            $detailId = 'booking_detail_' . (int)$booking['id'];
                                        ?>
                                        <article class="admin-booking-card" id="<?= e($detailId) ?>">
                                            <div class="admin-booking-top">
                                                <div>
                                                    <small>Kode Booking</small>
                                                    <strong><?= e($booking['booking_code'] ?: ('BOOK-' . $booking['id'])) ?></strong>
                                                </div>
                                                <span class="source-badge <?= e($booking['booking_source'] ?? 'online') ?>">
                                                    <?= ($booking['booking_source'] ?? 'online') === 'offline' ? 'Offline' : 'Online' ?>
                                                </span>
                                            </div>

                                            <div class="admin-booking-info-grid">
                                                <div><small>Customer</small><b><?= e($booking['nama_customer']) ?></b><?php if(($booking['booking_source'] ?? 'online') === 'offline' && !empty($booking['telepon_pelanggan'])): ?><span><?= e($booking['telepon_pelanggan']) ?></span><?php endif; ?></div>
                                                <div><small>Lapangan</small><b><?= e($booking['nama_lapangan']) ?></b><span>Lapangan <?= (int)$booking['nomor_lapangan'] ?></span></div>
                                                <div><small>Tanggal</small><b><?= date('d/m/Y', strtotime($booking['tanggal'])) ?></b><span><?= substr($booking['jam_mulai'], 0, 5) ?> - <?= substr($booking['jam_selesai'], 0, 5) ?></span></div>
                                                <div><small>Total</small><b>Rp <?= number_format($booking['total_harga'], 0, ',', '.') ?></b><span>Fee sistem: Rp <?= number_format((float)($booking['platform_fee'] ?? 0),0,',','.') ?></span></div>
                                            </div>

                                            <div class="admin-booking-control-grid">
                                                <div class="admin-control-box">
                                                    <small>Status Booking</small>
                                                    <form method="POST" class="admin-status-form">
                                                        <input type="hidden" name="booking_id" value="<?= (int)$booking['id'] ?>">
                                                        <select name="status" class="status-select" onchange="this.form.submit()">
                                                            <option value="pending" <?= $booking['status'] == 'pending' ? 'selected' : '' ?>>Pending</option>
                                                            <option value="paid" <?= $booking['status'] == 'paid' ? 'selected' : '' ?>>Paid</option>
                                                            <option value="confirmed" <?= $booking['status'] == 'confirmed' ? 'selected' : '' ?>>Confirmed</option>
                                                            <option value="cancelled" <?= $booking['status'] == 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
                                                        </select>
                                                        <input type="hidden" name="update_status" value="1">
                                                    </form>
                                                </div>

                                                <div class="admin-control-box match-control-box">
                                                    <small>Mode Tanding / Input Skor</small>
                                                    <?php if((int)($booking['match_enabled'] ?? 0) === 1): ?>
                                                        <span class="match-badge <?= $matchStatus === 'completed' ? 'completed' : ($matchStatus === 'rejected' ? 'rejected' : 'waiting') ?>">
                                                            <?= e(str_replace('_', ' ', ucfirst($matchStatus))) ?>
                                                        </span>
                                                        <small class="small-muted">Mode: <?= e($booking['match_type'] ?? 'solo') ?></small>
                                                        <div class="admin-teams-box compact">
                                                            <div><strong>Team/User 1</strong><?= renderTeamListAdmin($parts, 'challenger') ?></div>
                                                            <div><strong>Team/User 2</strong><?= renderTeamListAdmin($parts, 'opponent') ?></div>
                                                        </div>

                                                        <?php if($booking['match_result_id']): ?>
                                                            <small>Skor terakhir: <?= (int)$booking['user_score'] ?> - <?= (int)$booking['opponent_score'] ?> | Poin pembooking: <?= (int)$booking['points'] ?></small>
                                                            <form method="POST" action="simpan-skor.php" class="score-form compact-score-form-card">
                                                                <input type="hidden" name="booking_id" value="<?= (int)$booking['id'] ?>">
                                                                <label>Skor User/Team 1<input type="number" name="score_team1" min="0" value="<?= (int)$booking['user_score'] ?>" required></label>
                                                                <label>Skor User/Team 2<input type="number" name="score_team2" min="0" value="<?= (int)$booking['opponent_score'] ?>" required></label>
                                                                <span></span>
                                                                <button type="submit" class="btn-secondary small-btn">Edit Skor</button>
                                                            </form>
                                                        <?php elseif($matchStatus === 'waiting_score'): ?>
                                                            <form method="POST" action="simpan-skor.php" class="score-form compact-score-form-card">
                                                                <input type="hidden" name="booking_id" value="<?= (int)$booking['id'] ?>">
                                                                <label>Skor User/Team 1<input type="number" name="score_team1" min="0" placeholder="0" required></label>
                                                                <label>Skor User/Team 2<input type="number" name="score_team2" min="0" placeholder="0" required></label>
                                                                <textarea name="catatan" rows="1" placeholder="Catatan opsional"></textarea>
                                                                <button type="submit" class="btn-primary small-btn">Simpan Skor</button>
                                                            </form>
                                                        <?php elseif($matchStatus === 'pending_approval'): ?>
                                                            <small>Menunggu semua pemain menerima undangan. Skor belum bisa diinput.</small>
                                                        <?php elseif($matchStatus === 'rejected'): ?>
                                                            <small><?= e($booking['match_rejected_reason'] ?: 'Permintaan ditolak salah satu pemain.') ?></small>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <span class="match-badge inactive">Nonaktif</span>
                                                    <?php endif; ?>
                                                </div>

                                                <div class="admin-control-box action-control-box">
                                                    <small>Aksi</small>
                                                    <div class="action-stack">
                                                        <?php if($booking['status'] == 'confirmed' || $booking['status'] == 'paid'): ?>
                                                            <a href="../cetak-struk.php?booking_id=<?= (int)$booking['id'] ?>" class="btn-secondary small-btn">Cetak</a>
                                                        <?php endif; ?>
                                                        <form method="POST" onsubmit="return confirm('Bersihkan booking ini dari tampilan? Data tetap aman di database.');">
                                                            <input type="hidden" name="booking_view_action" value="hide_single">
                                                            <input type="hidden" name="booking_id" value="<?= (int)$booking['id'] ?>">
                                                            <button type="submit" class="btn-danger-soft small-btn">Bersihkan</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </article>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </section>
                    <?php endforeach; ?>

                    <?php if(count($groups) == 0): ?>
                        <div class="empty-booking-box">Belum ada booking yang tampil. Cek tab <b>Sudah Dibersihkan</b> kalau sebelumnya pernah dibersihkan.</div>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <div class="booking-code-toolbar">
                    <div>
                        <b>Booking yang sudah dibersihkan dari tampilan</b>
                        <p class="small-muted">Data masih ada di database dan masih bisa dipakai untuk leaderboard. Gunakan tombol tampilkan lagi kalau ingin muncul kembali di daftar booking.</p>
                    </div>
                    <form method="POST" onsubmit="return confirm('Tampilkan lagi semua booking yang sudah dibersihkan?');">
                        <input type="hidden" name="booking_view_action" value="show_all">
                        <button type="submit" class="btn-secondary small-btn">Tampilkan Lagi Semua</button>
                    </form>
                </div>

                <?php if(count($hidden_bookings) > 0): ?>
                    <form method="POST" id="showSelectedHiddenForm" onsubmit="return confirm('Tampilkan lagi booking pilihan?');" style="margin-bottom:12px;">
                        <input type="hidden" name="booking_view_action" value="show_selected">
                        <button type="submit" class="btn-primary small-btn">Tampilkan Lagi Pilihan</button>
                    </form>
                    <div class="hidden-booking-list">
                        <?php foreach($hidden_bookings as $booking): ?>
                            <div class="hidden-booking-item">
                                <div class="hidden-booking-row">
                                    <input type="checkbox" name="booking_ids[]" value="<?= (int)$booking['id'] ?>" form="showSelectedHiddenForm">
                                    <div>
                                        <b><?= e($booking['booking_code'] ?: ('BOOK-' . $booking['id'])) ?></b>
                                        <p class="small-muted"><?= e($booking['nama_customer']) ?> · <?= e($booking['nama_lapangan']) ?> Lapangan <?= (int)$booking['nomor_lapangan'] ?></p>
                                        <p class="small-muted"><?= formatBookingDateTimeAdmin($booking) ?> · Dibersihkan: <?= date('d/m/Y H:i', strtotime($booking['hidden_at'])) ?></p>
                                    </div>
                                </div>
                                <form method="POST">
                                    <input type="hidden" name="booking_view_action" value="show_single">
                                    <input type="hidden" name="booking_id" value="<?= (int)$booking['id'] ?>">
                                    <button type="submit" class="btn-secondary small-btn">Tampilkan Lagi</button>
                                </form>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="empty-booking-box">Belum ada booking yang dibersihkan.</div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
<script>
const offlineLapanganSelect = document.getElementById('offlineLapanganSelect');
const offlineNomorSelect = document.getElementById('offlineNomorLapanganSelect');
const offlineStart = document.getElementById('offlineJamMulai');
const offlineEnd = document.getElementById('offlineJamSelesai');
const offlinePricePreview = document.getElementById('offlinePricePreview');

function rupiah(value) {
    return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(value);
}

function timeToMinutes(time) {
    if (!time || !time.includes(':')) return NaN;
    const [h, m] = time.split(':').map(Number);
    return h * 60 + m;
}

function renderOfflineNomorLapangan() {
    if (!offlineLapanganSelect || !offlineNomorSelect) return;
    const selected = offlineLapanganSelect.options[offlineLapanganSelect.selectedIndex];
    const jumlah = Number(selected?.dataset?.jumlah || 1);
    offlineNomorSelect.innerHTML = '';
    for (let i = 1; i <= jumlah; i++) {
        const opt = document.createElement('option');
        opt.value = i;
        opt.textContent = 'Lapangan ' + i;
        offlineNomorSelect.appendChild(opt);
    }
    updateOfflinePreview();
}

function updateOfflinePreview() {
    if (!offlineLapanganSelect || !offlinePricePreview) return;
    const selected = offlineLapanganSelect.options[offlineLapanganSelect.selectedIndex];
    const harga = Number(selected?.dataset?.harga || 0);
    const start = timeToMinutes(offlineStart.value);
    const end = timeToMinutes(offlineEnd.value);
    if (!harga || Number.isNaN(start) || Number.isNaN(end) || end <= start) {
        offlinePricePreview.textContent = 'Total akan dihitung otomatis dari durasi x harga per jam.';
        return;
    }
    const durasi = end - start;
    const total = Math.ceil((harga / 60) * durasi);
    offlinePricePreview.textContent = `Durasi ${durasi} menit. Perkiraan total: ${rupiah(total)}.`;
}

if (offlineLapanganSelect) {
    offlineLapanganSelect.addEventListener('change', renderOfflineNomorLapangan);
    offlineStart.addEventListener('input', updateOfflinePreview);
    offlineEnd.addEventListener('input', updateOfflinePreview);
    renderOfflineNomorLapangan();
}

document.querySelectorAll('.booking-field-summary').forEach((button) => {
    button.addEventListener('click', () => {
        const group = button.closest('.booking-field-group');
        group.classList.toggle('open');
    });
});

document.querySelectorAll('.booking-code-btn').forEach((button) => {
    button.addEventListener('click', () => {
        const group = button.closest('.booking-group-body');
        const targetId = button.dataset.target;
        if (!group || !targetId) return;
        group.querySelectorAll('.admin-booking-card').forEach(card => card.classList.remove('active'));
        group.querySelectorAll('.booking-code-item').forEach(item => item.classList.remove('is-active'));
        const card = group.querySelector('#' + CSS.escape(targetId));
        if (card) {
            card.classList.add('active');
            button.closest('.booking-code-item')?.classList.add('is-active');
            card.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
    });
});
</script>
</body>
</html>
