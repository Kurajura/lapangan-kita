<?php 
include '../config/database.php';
if (!isLoggedIn() || !isAdmin()) {
    header("Location: ../login.php");
    exit();
}

// Statistik admin
$stmt = $pdo->prepare("SELECT COUNT(*) as total_lapangan FROM lapangan WHERE admin_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$total_lapangan = $stmt->fetch()['total_lapangan'];

$stmt = $pdo->prepare("SELECT COUNT(*) as total_booking FROM bookings b JOIN lapangan l ON b.lapangan_id = l.id WHERE l.admin_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$total_booking = $stmt->fetch()['total_booking'];

$stmt = $pdo->prepare("SELECT SUM(b.total_harga) as total_revenue FROM bookings b JOIN lapangan l ON b.lapangan_id = l.id WHERE l.admin_id = ? AND b.status = 'confirmed'");
$stmt->execute([$_SESSION['user_id']]);
$total_revenue = $stmt->fetch()['total_revenue'];

$stmt = $pdo->prepare("SELECT COUNT(*) AS total_waiting_match
                       FROM bookings b
                       JOIN lapangan l ON b.lapangan_id = l.id
                       LEFT JOIN match_results mr ON mr.booking_id = b.id
                       WHERE l.admin_id = ? AND b.match_enabled = 1 AND b.match_status = 'waiting_score' AND mr.id IS NULL");
$stmt->execute([$_SESSION['user_id']]);
$total_waiting_match = (int) $stmt->fetch()['total_waiting_match'];

$stmt = $pdo->prepare("SELECT b.*, l.nama_lapangan, u.username FROM bookings b JOIN lapangan l ON b.lapangan_id = l.id JOIN users u ON b.user_id = u.id WHERE l.admin_id = ? ORDER BY b.created_at DESC LIMIT 5");
$stmt->execute([$_SESSION['user_id']]);
$recent_bookings = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - LapanganKita</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="top-header">
    <div class="promo-box"> Admin Dashboard <span>MANAGEMENT</span></div>
    <div class="top-right">
        <div class="user-info">
            <i class="fa-regular fa-user"></i> <?= $_SESSION['username'] ?>
            <span style="background:#00ffb3; padding:2px 8px; border-radius:20px; color:#000;">Admin</span>
            <a href="../logout.php" style="color:#ff003c;">Logout</a>
        </div>
    </div>
</div>
<?php renderNavbar('../'); ?>

<div class="dashboard-wrapper">
    <div class="sidebar">
        <h2>Menu Admin</h2>
        <a href="dashboard.php" class="active"><i class="fa-solid fa-chart-line"></i> Dashboard</a>
        <a href="lapangan.php"><i class="fa-solid fa-futbol"></i> Kelola Lapangan</a>
        <a href="bookings.php"><i class="fa-solid fa-calendar-check"></i> Kelola Booking</a>
        <a href="transactions.php"><i class="fa-solid fa-credit-card"></i> Transaksi</a>
        <a href="../marketplace.php"><i class="fa-solid fa-store"></i> Market Olahraga</a><a href="../logout.php"><i class="fa-solid fa-sign-out-alt"></i> Logout</a>
    </div>
    
    <div class="main-content">
        <h1>Dashboard Admin</h1>
        <p>Kelola lapangan dan booking Anda di sini</p>
        
        <div class="stats-grid">
            <div class="stat-card">
                <i class="fa-solid fa-futbol"></i>
                <h2><?= $total_lapangan ?></h2>
                <p>Total Lapangan</p>
            </div>
            <div class="stat-card">
                <i class="fa-solid fa-calendar-check"></i>
                <h2><?= $total_booking ?></h2>
                <p>Total Booking</p>
            </div>
            <div class="stat-card">
                <i class="fa-solid fa-money-bill-wave"></i>
                <h2>Rp <?= number_format($total_revenue ?: 0, 0, ',', '.') ?></h2>
                <p>Total Pendapatan</p>
            </div>
            <div class="stat-card">
                <i class="fa-solid fa-bell"></i>
                <h2><?= $total_waiting_match ?></h2>
                <p>Skor Tanding Menunggu Input</p>
            </div>
        </div>
        <?php if($total_waiting_match > 0): ?>
            <div class="form-card match-notification"><i class="fa-solid fa-bell"></i> Ada mode tanding yang perlu input skor. <a href="bookings.php" class="btn-primary small-btn">Input Sekarang</a></div>
        <?php endif; ?>
        
        <div class="form-card">
            <h2>Booking Terbaru</h2>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Kode</th>
                        <th>User</th>
                        <th>Lapangan</th>
                        <th>No.</th>
                        <th>Tanggal</th>
                        <th>Total</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($recent_bookings as $booking): ?>
                    <tr>
                        <td><?= $booking['booking_code'] ?></td>
                        <td><?= htmlspecialchars($booking['username']) ?></td>
                        <td><?= htmlspecialchars($booking['nama_lapangan']) ?></td>
                        <td>Lapangan <?= (int) $booking['nomor_lapangan'] ?></td>
                        <td><?= date('d/m/Y', strtotime($booking['tanggal'])) ?></td>
                        <td>Rp <?= number_format($booking['total_harga'], 0, ',', '.') ?></td>
                        <td><span class="status-badge status-<?= $booking['status'] ?>"><?= ucfirst($booking['status']) ?></span></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<style>
.status-badge {
    display: inline-block;
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: bold;
}
.status-pending { background: #ff9800; color: #000; }
.status-confirmed { background: #4caf50; color: #fff; }
.status-cancelled { background: #f44336; color: #fff; }
</style>
</body>
</html>