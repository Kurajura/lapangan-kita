<?php 
include '../config/database.php';
if (!isLoggedIn() || !isAdmin()) {
    header("Location: ../login.php");
    exit();
}

function redirectLapangan($params = '') {
    header("Location: lapangan.php" . $params);
    exit();
}

// Handle upload foto dan tambah lapangan
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_lapangan'])) {
    $nama_lapangan = trim($_POST['nama_lapangan']);
    $jenis_olahraga = trim($_POST['jenis_olahraga']);
    $deskripsi = trim($_POST['deskripsi'] ?? '');
    $harga_per_jam = (float) $_POST['harga_per_jam'];
    $jumlah_lapangan = max(1, (int) ($_POST['jumlah_lapangan'] ?? 1));
    $alamat = trim($_POST['alamat'] ?? '');
    
    $foto = null;
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {
        $target_dir = "../assets/uploads/";
        if (!is_dir($target_dir)) mkdir($target_dir, 0777, true);
        $ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
        $foto = time() . '_' . bin2hex(random_bytes(8)) . ($ext ? '.' . $ext : '');
        move_uploaded_file($_FILES['foto']['tmp_name'], $target_dir . $foto);
    }
    
    $stmt = $pdo->prepare("INSERT INTO lapangan (admin_id, nama_lapangan, jenis_olahraga, deskripsi, harga_per_jam, jumlah_lapangan, foto, alamat) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$_SESSION['user_id'], $nama_lapangan, $jenis_olahraga, $deskripsi, $harga_per_jam, $jumlah_lapangan, $foto, $alamat]);
    redirectLapangan('?success=Lapangan berhasil ditambahkan');
}

// Handle tutup lapangan: bisa seharian atau manual beberapa jam
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_tutup'])) {
    $lapangan_id = (int) ($_POST['lapangan_id'] ?? 0);
    $nomor_lapangan = (int) ($_POST['nomor_lapangan'] ?? 1);
    $tanggal = $_POST['tanggal'] ?? '';
    $tipe_tutup = ($_POST['tipe_tutup'] ?? 'manual') === 'seharian' ? 'seharian' : 'manual';
    $jam_mulai = $tipe_tutup === 'seharian' ? '00:00:00' : ($_POST['jam_mulai'] ?? '');
    $jam_selesai = $tipe_tutup === 'seharian' ? '23:59:00' : ($_POST['jam_selesai'] ?? '');
    $alasan = trim($_POST['alasan'] ?? '');

    $cekLapangan = $pdo->prepare("SELECT id, jumlah_lapangan FROM lapangan WHERE id = ? AND admin_id = ?");
    $cekLapangan->execute([$lapangan_id, $_SESSION['user_id']]);
    $field = $cekLapangan->fetch();

    if (!$field) redirectLapangan('?error=Lapangan tidak valid');

    $durasi = (strtotime($jam_selesai) - strtotime($jam_mulai)) / 3600;
    if ($tanggal < date('Y-m-d')) {
        redirectLapangan('?error=Tanggal tutup tidak boleh tanggal lewat');
    } elseif ($nomor_lapangan < 1 || $nomor_lapangan > (int) $field['jumlah_lapangan']) {
        redirectLapangan('?error=Nomor lapangan tidak valid');
    } elseif ($durasi <= 0) {
        redirectLapangan('?error=Jam selesai harus lebih besar dari jam mulai');
    }

    $cekBooking = $pdo->prepare("SELECT id FROM bookings 
                                 WHERE lapangan_id = ? AND nomor_lapangan = ? AND tanggal = ? AND status <> 'cancelled'
                                 AND jam_mulai < ? AND jam_selesai > ? LIMIT 1");
    $cekBooking->execute([$lapangan_id, $nomor_lapangan, $tanggal, $jam_selesai, $jam_mulai]);
    if ($cekBooking->fetch()) redirectLapangan('?error=Jadwal tersebut sudah ada booking. Batalkan booking dulu jika ingin menutup jam itu.');

    $cekTutup = $pdo->prepare("SELECT id FROM lapangan_tutup 
                               WHERE lapangan_id = ? AND nomor_lapangan = ? AND tanggal = ?
                               AND jam_mulai < ? AND jam_selesai > ? LIMIT 1");
    $cekTutup->execute([$lapangan_id, $nomor_lapangan, $tanggal, $jam_selesai, $jam_mulai]);
    if ($cekTutup->fetch()) redirectLapangan('?error=Jadwal tutup bertabrakan dengan jadwal tutup yang sudah ada');

    $stmt = $pdo->prepare("INSERT INTO lapangan_tutup (lapangan_id, nomor_lapangan, tanggal, tipe_tutup, jam_mulai, jam_selesai, alasan) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$lapangan_id, $nomor_lapangan, $tanggal, $tipe_tutup, $jam_mulai, $jam_selesai, $alasan]);
    redirectLapangan('?success=Jadwal tutup lapangan berhasil ditambahkan');
}

// Handle hapus jadwal tutup
if (isset($_GET['delete_tutup'])) {
    $tutup_id = (int) $_GET['delete_tutup'];
    $stmt = $pdo->prepare("DELETE lt FROM lapangan_tutup lt JOIN lapangan l ON lt.lapangan_id = l.id WHERE lt.id = ? AND l.admin_id = ?");
    $stmt->execute([$tutup_id, $_SESSION['user_id']]);
    redirectLapangan('?success=Jadwal tutup berhasil dihapus');
}

// Handle delete lapangan
if (isset($_GET['delete'])) {
    $lapangan_id = (int) $_GET['delete'];

    $cek = $pdo->prepare("SELECT id FROM lapangan WHERE id = ? AND admin_id = ?");
    $cek->execute([$lapangan_id, $_SESSION['user_id']]);

    if ($cek->fetch()) {
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare("SELECT id FROM bookings WHERE lapangan_id = ?");
            $stmt->execute([$lapangan_id]);
            $booking_ids = $stmt->fetchAll(PDO::FETCH_COLUMN);

            if (!empty($booking_ids)) {
                $placeholders = implode(',', array_fill(0, count($booking_ids), '?'));
                $pdo->prepare("DELETE FROM transactions WHERE booking_id IN ($placeholders)")->execute($booking_ids);
                $pdo->prepare("DELETE FROM match_results WHERE booking_id IN ($placeholders)")->execute($booking_ids);
                $pdo->prepare("DELETE FROM match_participants WHERE booking_id IN ($placeholders)")->execute($booking_ids);
                $pdo->prepare("DELETE FROM team_match_requests WHERE booking_id IN ($placeholders)")->execute($booking_ids);
                $pdo->prepare("DELETE FROM bookings WHERE id IN ($placeholders)")->execute($booking_ids);
            }

            $pdo->prepare("DELETE FROM lapangan_tutup WHERE lapangan_id = ?")->execute([$lapangan_id]);
            $stmt = $pdo->prepare("DELETE FROM lapangan WHERE id = ? AND admin_id = ?");
            $stmt->execute([$lapangan_id, $_SESSION['user_id']]);
            $pdo->commit();
            redirectLapangan('?success=Lapangan berhasil dihapus');
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = "Lapangan gagal dihapus: " . $e->getMessage();
        }
    }
}

$stmt = $pdo->prepare("SELECT * FROM lapangan WHERE admin_id = ? ORDER BY created_at DESC");
$stmt->execute([$_SESSION['user_id']]);
$lapangan = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT lt.*, l.nama_lapangan 
                       FROM lapangan_tutup lt 
                       JOIN lapangan l ON lt.lapangan_id = l.id 
                       WHERE l.admin_id = ? 
                       ORDER BY lt.tanggal ASC, lt.jam_mulai ASC");
$stmt->execute([$_SESSION['user_id']]);
$jadwal_tutup = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Lapangan - Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .admin-summary-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:16px;margin:20px 0}.admin-mini-card{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);border-radius:18px;padding:16px}.admin-mini-card strong{display:block;color:#00ffb3;font-size:26px}.field-photo{width:56px;height:56px;border-radius:14px;object-fit:cover;background:rgba(255,255,255,.10)}.data-table td{vertical-align:top}.action-cell{display:flex;gap:8px;flex-wrap:wrap}.clean-section-title{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap}.helper-box{background:rgba(0,195,255,.09);border:1px solid rgba(0,195,255,.18);border-radius:16px;padding:14px;margin:12px 0 18px}
    </style>
</head>
<body>
<div class="top-header">
    <div class="promo-box"> Kelola Lapangan <span>ADMIN</span></div>
    <div class="top-right">
        <div class="user-info">
            <i class="fa-regular fa-user"></i> <?= htmlspecialchars($_SESSION['username']) ?>
            <a href="../logout.php" style="color:#ff003c;">Logout</a>
        </div>
    </div>
</div>
<?php renderNavbar('../'); ?>

<div class="dashboard-wrapper">
    <div class="sidebar">
        <h2>Menu Admin</h2>
        <a href="dashboard.php"><i class="fa-solid fa-chart-line"></i> Dashboard</a>
        <a href="lapangan.php" class="active"><i class="fa-solid fa-futbol"></i> Kelola Lapangan</a>
        <a href="bookings.php"><i class="fa-solid fa-calendar-check"></i> Kelola Booking</a>
        <a href="transactions.php"><i class="fa-solid fa-credit-card"></i> Transaksi</a>
        <a href="../marketplace.php"><i class="fa-solid fa-store"></i> Market Olahraga</a><a href="../logout.php"><i class="fa-solid fa-sign-out-alt"></i> Logout</a>
    </div>
    
    <div class="main-content">
        <h1>Kelola Lapangan</h1>
        <p>Tambah lapangan, tutup lapangan seharian/manual, dan lihat jadwal tutup dalam satu halaman.</p>
        <div class="admin-summary-grid">
            <div class="admin-mini-card"><small>Total Lapangan</small><strong><?= count($lapangan) ?></strong></div>
            <div class="admin-mini-card"><small>Lapangan Aktif</small><strong><?= count(array_filter($lapangan, fn($x)=>$x['status']==='aktif')) ?></strong></div>
            <div class="admin-mini-card"><small>Jadwal Tutup</small><strong><?= count($jadwal_tutup) ?></strong></div>
        </div>
                <?php if(isset($_GET['success'])): ?>
            <div class="alert-success"><?= htmlspecialchars($_GET['success']) ?></div>
        <?php endif; ?>
        <?php if(isset($_GET['error'])): ?>
            <div class="alert-error"><?= htmlspecialchars($_GET['error']) ?></div>
        <?php endif; ?>
        <?php if(isset($error)): ?>
            <div class="alert-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <div class="form-card">
            <h2>Tambah Lapangan Baru</h2>
            <form method="POST" enctype="multipart/form-data" class="admin-grid-form">
                <input type="text" name="nama_lapangan" placeholder="Nama Lapangan / Nama Tempat" required>
                <input type="text" name="jenis_olahraga" placeholder="Jenis Olahraga (Futsal, Badminton, Basket, dll)" required>
                <input type="number" name="harga_per_jam" placeholder="Harga per Jam" min="0" required>
                <input type="number" name="jumlah_lapangan" placeholder="Jumlah Lapangan / Unit" min="1" value="1" required>
                <textarea name="deskripsi" placeholder="Deskripsi Lapangan" rows="3"></textarea>
                <textarea name="alamat" placeholder="Alamat Lengkap" rows="3"></textarea>
                <input type="file" name="foto" accept="image/*">
                <button type="submit" name="add_lapangan" class="btn-primary">Tambah Lapangan</button>
            </form>
        </div>

        <div class="form-card">
            <div class="clean-section-title"><h2>Tutup Lapangan</h2><span class="source-badge offline">Seharian / Manual</span></div>
            <p class="helper-box">Pilih <b>tutup seharian</b> jika lapangan tidak buka satu hari penuh, atau pilih <b>manual beberapa jam</b> untuk menutup jam tertentu seperti 07:43 - 08:43.</p>
            <form method="POST" class="admin-grid-form">
                <select name="lapangan_id" id="tutupLapanganSelect" required>
                    <option value="">Pilih Lapangan</option>
                    <?php foreach($lapangan as $l): ?>
                        <option value="<?= $l['id'] ?>" data-jumlah="<?= (int) $l['jumlah_lapangan'] ?>"><?= htmlspecialchars($l['nama_lapangan']) ?> - <?= (int) $l['jumlah_lapangan'] ?> unit</option>
                    <?php endforeach; ?>
                </select>
                <select name="nomor_lapangan" id="nomorLapanganSelect" required>
                    <option value="1">Lapangan 1</option>
                </select>
                <input type="date" name="tanggal" min="<?= date('Y-m-d') ?>" required>
                <div class="closure-type-box">
                    <label><input type="radio" name="tipe_tutup" value="seharian" checked> Tutup seharian</label>
                    <label><input type="radio" name="tipe_tutup" value="manual"> Manual beberapa jam</label>
                </div>
                <div class="manual-time-box" style="display:none;">
                    <input type="time" name="jam_mulai" step="60">
                    <input type="time" name="jam_selesai" step="60">
                </div>
                <input type="text" name="alasan" placeholder="Alasan tutup (opsional)">
                <button type="submit" name="add_tutup" class="btn-primary">Simpan Jadwal Tutup</button>
            </form>
        </div>
        
        <div class="form-card">
            <h2>Daftar Lapangan Anda</h2>
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Foto</th>
                            <th>Nama</th>
                            <th>Jenis</th>
                            <th>Jumlah Unit</th>
                            <th>Harga/Jam</th>
                            <th>Status</th>
                            <th>Detail</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($lapangan as $l): ?>
                        <tr>
                            <td>
                                <?php if($l['foto']): ?>
                                    <img src="../assets/uploads/<?= htmlspecialchars($l['foto']) ?>" class="field-photo">
                                <?php else: ?>
                                    <i class="fa-solid fa-futbol"></i>
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($l['nama_lapangan']) ?></td>
                            <td><?= htmlspecialchars($l['jenis_olahraga']) ?></td>
                            <td><?= (int) $l['jumlah_lapangan'] ?> lapangan</td>
                            <td>Rp <?= number_format($l['harga_per_jam'], 0, ',', '.') ?></td>
                            <td><?= htmlspecialchars($l['status']) ?></td>
                            <td><a href="../detail-lapangan.php?id=<?= $l['id'] ?>" class="btn-secondary small-btn">Detail</a></td>
                            <td class="action-cell">
                                <a href="?delete=<?= $l['id'] ?>" class="btn-danger small-btn" onclick="return confirm('Yakin hapus? Semua booking, transaksi, dan jadwal tutup lapangan ini juga akan terhapus')">Hapus</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(count($lapangan) == 0): ?>
                        <tr>
                            <td colspan="8" style="text-align: center;">Belum ada lapangan</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="form-card">
            <h2>Jadwal Tutup Lapangan</h2>
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Lapangan</th>
                            <th>No. Lapangan</th>
                            <th>Tanggal</th>
                            <th>Tipe</th>
                            <th>Jam Tutup</th>
                            <th>Alasan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($jadwal_tutup as $jt): ?>
                        <tr>
                            <td><?= htmlspecialchars($jt['nama_lapangan']) ?></td>
                            <td>Lapangan <?= (int) $jt['nomor_lapangan'] ?></td>
                            <td><?= date('d/m/Y', strtotime($jt['tanggal'])) ?></td>
                            <td><?= ($jt['tipe_tutup'] ?? 'manual') === 'seharian' ? 'Seharian' : 'Manual' ?></td>
                            <td><?= substr($jt['jam_mulai'], 0, 5) ?> - <?= substr($jt['jam_selesai'], 0, 5) ?></td>
                            <td><?= htmlspecialchars($jt['alasan'] ?: '-') ?></td>
                            <td><a href="?delete_tutup=<?= $jt['id'] ?>" class="btn-danger small-btn" onclick="return confirm('Hapus jadwal tutup ini?')">Hapus</a></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(count($jadwal_tutup) == 0): ?>
                        <tr>
                            <td colspan="7" style="text-align: center;">Belum ada jadwal tutup</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script>
const lapanganSelect = document.getElementById('tutupLapanganSelect');
const nomorSelect = document.getElementById('nomorLapanganSelect');

function renderNomorLapangan() {
    const selected = lapanganSelect.options[lapanganSelect.selectedIndex];
    const jumlah = Number(selected?.dataset?.jumlah || 1);
    nomorSelect.innerHTML = '';
    for (let i = 1; i <= jumlah; i++) {
        const opt = document.createElement('option');
        opt.value = i;
        opt.textContent = 'Lapangan ' + i;
        nomorSelect.appendChild(opt);
    }
}

lapanganSelect.addEventListener('change', renderNomorLapangan);
renderNomorLapangan();

const typeRadios = document.querySelectorAll('input[name="tipe_tutup"]');
const manualTimeBox = document.querySelector('.manual-time-box');
function syncClosureType(){
    const type = document.querySelector('input[name="tipe_tutup"]:checked')?.value || 'seharian';
    const manual = type === 'manual';
    manualTimeBox.style.display = manual ? 'grid' : 'none';
    manualTimeBox.querySelectorAll('input').forEach(inp => inp.required = manual);
}
typeRadios.forEach(r => r.addEventListener('change', syncClosureType));
syncClosureType();
</script>
</body>
</html>
