<?php
include '../config/database.php';
if (!isLoggedIn() || !isAdmin()) {
    header("Location: ../login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: bookings.php");
    exit();
}

$booking_id = (int) ($_POST['booking_id'] ?? 0);
$score_team1 = isset($_POST['score_team1']) ? (int)$_POST['score_team1'] : (int)($_POST['user_score'] ?? 0);
$score_team2 = isset($_POST['score_team2']) ? (int)$_POST['score_team2'] : (int)($_POST['opponent_score'] ?? 0);
$catatan = trim($_POST['catatan'] ?? '');

if ($booking_id <= 0 || $score_team1 < 0 || $score_team2 < 0) {
    header("Location: bookings.php?error=Data skor tidak valid");
    exit();
}

$stmt = $pdo->prepare("SELECT b.*, l.nama_lapangan, l.jenis_olahraga, l.wilayah, l.kabupaten, l.admin_id
                       FROM bookings b
                       JOIN lapangan l ON b.lapangan_id = l.id
                       WHERE b.id = ? AND l.admin_id = ?");
$stmt->execute([$booking_id, $_SESSION['user_id']]);
$booking = $stmt->fetch();

if (!$booking) {
    header("Location: bookings.php?error=Booking tidak ditemukan atau bukan milik admin ini");
    exit();
}

if ((int)($booking['match_enabled'] ?? 0) !== 1) {
    header("Location: bookings.php?error=Mode tanding belum diaktifkan oleh user");
    exit();
}

if (!in_array($booking['status'], ['paid', 'confirmed'], true) || $booking['payment_status'] !== 'paid') {
    header("Location: bookings.php?error=Skor hanya bisa dicatat untuk booking yang sudah dibayar");
    exit();
}

if (!in_array($booking['match_status'], ['waiting_score','completed'], true)) {
    header("Location: bookings.php?error=Skor belum bisa diinput karena masih menunggu persetujuan pemain");
    exit();
}

$stmt = $pdo->prepare("SELECT mp.*, u.username, u.player_code, COALESCE(NULLIF(u.display_name,''), NULLIF(u.full_name,''), u.username) AS player_name
                       FROM match_participants mp
                       JOIN users u ON mp.user_id = u.id
                       WHERE mp.booking_id = ?
                       ORDER BY mp.team ASC, mp.is_captain DESC, u.username ASC");
$stmt->execute([$booking_id]);
$participants = $stmt->fetchAll();

if (!$participants) {
    $participants = [[
        'user_id' => $booking['user_id'],
        'team' => 'challenger',
        'player_name' => 'User Booking',
        'status' => 'accepted'
    ]];
}

foreach ($participants as $p) {
    if (($p['status'] ?? 'accepted') !== 'accepted') {
        header("Location: bookings.php?error=Masih ada pemain yang belum menyetujui permintaan tanding");
        exit();
    }
}

$team1Names = [];
$team2Names = [];
foreach ($participants as $p) {
    if ($p['team'] === 'opponent') $team2Names[] = $p['player_name'];
    else $team1Names[] = $p['player_name'];
}
$team1Label = $team1Names ? implode(', ', $team1Names) : 'Team 1';
$team2Label = $team2Names ? implode(', ', $team2Names) : ($booking['match_opponent_name'] ?: 'Team 2');

try {
    $pdo->beginTransaction();
    $pdo->prepare("DELETE FROM match_results WHERE booking_id = ?")->execute([$booking_id]);

    $insert = $pdo->prepare("INSERT INTO match_results
        (booking_id, user_id, lapangan_id, nomor_lapangan, jenis_olahraga, wilayah, kabupaten, opponent_name, user_score, opponent_score, winner, points, score_diff, catatan)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    foreach ($participants as $p) {
        $isOpponentTeam = $p['team'] === 'opponent';
        $ownScore = $isOpponentTeam ? $score_team2 : $score_team1;
        $otherScore = $isOpponentTeam ? $score_team1 : $score_team2;
        $opponentName = $isOpponentTeam ? $team1Label : $team2Label;

        if ($ownScore > $otherScore) {
            $winner = 'user';
            $points = 3;
        } elseif ($ownScore < $otherScore) {
            $winner = 'opponent';
            $points = 0;
        } else {
            $winner = 'draw';
            $points = 1;
        }
        $score_diff = $ownScore - $otherScore;

        $insert->execute([
            $booking_id,
            (int)$p['user_id'],
            $booking['lapangan_id'],
            $booking['nomor_lapangan'],
            $booking['jenis_olahraga'],
            $booking['wilayah'],
            $booking['kabupaten'],
            mb_substr($opponentName, 0, 100),
            $ownScore,
            $otherScore,
            $winner,
            $points,
            $score_diff,
            $catatan
        ]);

        createNotification(
            $pdo,
            (int)$p['user_id'],
            'Skor tanding sudah diinput',
            'Hasil pertandingan di ' . $booking['nama_lapangan'] . ': Team 1 ' . $score_team1 . ' - ' . $score_team2 . ' Team 2. Poin kamu: ' . $points . '.',
            'leaderboard.php?lapangan_id=' . $booking['lapangan_id']
        );
    }

    $stmt = $pdo->prepare("UPDATE bookings SET mode_main = 'kompetitif', match_status = 'completed', match_opponent_name = ? WHERE id = ?");
    $stmt->execute([mb_substr($team2Label, 0, 100), $booking_id]);
    $pdo->commit();

    header("Location: bookings.php?success=Skor pertandingan berhasil disimpan ke leaderboard. Menang +3 poin, seri +1 poin, kalah +0 poin.");
    exit();
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    header("Location: bookings.php?error=" . urlencode('Gagal simpan skor: ' . $e->getMessage()));
    exit();
}
?>
