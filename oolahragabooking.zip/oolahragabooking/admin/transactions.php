<?php 
include '../config/database.php';
if (!isLoggedIn() || !isAdmin()) {
    header("Location: ../login.php");
    exit();
}

function redirectTransactions($msg, $type = 'success') {
    header('Location: transactions.php?' . $type . '=' . urlencode($msg));
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_transaction'])) {
    $transaction_id = (int)($_POST['transaction_id'] ?? 0);
    $status = $_POST['status'] ?? '';
    if (!in_array($status, ['pending','success','failed','cancelled'], true)) {
        redirectTransactions('Status transaksi tidak valid', 'error');
    }
    $cek = $pdo->prepare("SELECT t.id FROM transactions t JOIN bookings b ON t.booking_id = b.id JOIN lapangan l ON b.lapangan_id = l.id WHERE t.id = ? AND l.admin_id = ?");
    $cek->execute([$transaction_id, $_SESSION['user_id']]);
    if (!$cek->fetch()) redirectTransactions('Transaksi bukan milik lapangan kamu', 'error');
    syncBookingFromTransactionStatus($pdo, $transaction_id, $status);
    redirectTransactions('Status transaksi berhasil diupdate. Status booking ikut disesuaikan.');
}

$stmt = $pdo->prepare("SELECT t.*, b.booking_code, b.tanggal, b.jam_mulai, b.jam_selesai, b.nomor_lapangan, b.booking_source, b.nama_pelanggan, b.status AS booking_status, b.payment_status, l.nama_lapangan, u.username, COALESCE(NULLIF(b.nama_pelanggan, ''), u.username) AS nama_customer 
                       FROM transactions t 
                       JOIN bookings b ON t.booking_id = b.id 
                       JOIN lapangan l ON b.lapangan_id = l.id 
                       JOIN users u ON b.user_id = u.id 
                       WHERE l.admin_id = ? 
                       ORDER BY t.created_at DESC");
$stmt->execute([$_SESSION['user_id']]);
$transactions = $stmt->fetchAll();
$total_amount = array_sum(array_map(fn($t)=>(float)$t['amount'], array_filter($transactions, fn($t)=>$t['status']==='success')));
$pending_count = count(array_filter($transactions, fn($t)=>$t['status']==='pending'));
$cancel_count = count(array_filter($transactions, fn($t)=>$t['status']==='cancelled'));
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaksi - Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .admin-summary-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:16px;margin:20px 0}.admin-mini-card{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);border-radius:18px;padding:16px}.admin-mini-card strong{display:block;color:#00ffb3;font-size:26px}.status-select{padding:8px 12px;border-radius:12px;border:1px solid rgba(255,255,255,.14);background:rgba(255,255,255,.08);color:#fff}.status-cancelled{background:#f44336;color:#fff}.action-cell{display:flex;gap:8px;flex-wrap:wrap;align-items:center}.data-table td{vertical-align:top}.filter-note{background:rgba(0,255,179,.08);border:1px solid rgba(0,255,179,.18);padding:12px 14px;border-radius:14px;margin:10px 0 18px;color:#cfe8e3}
    </style>
</head>
<body>
<div class="top-header"><div class="promo-box"> Transaksi <span>ADMIN</span></div><div class="top-right"><div class="user-info"><i class="fa-regular fa-user"></i> <?= e($_SESSION['username']) ?> <a href="../logout.php" style="color:#ff003c;">Logout</a></div></div></div>
<?php renderNavbar('../'); ?>
<div class="dashboard-wrapper">
    <div class="sidebar"><h2>Menu Admin</h2><a href="dashboard.php"><i class="fa-solid fa-chart-line"></i> Dashboard</a><a href="lapangan.php"><i class="fa-solid fa-futbol"></i> Kelola Lapangan</a><a href="bookings.php"><i class="fa-solid fa-calendar-check"></i> Kelola Booking</a><a href="transactions.php" class="active"><i class="fa-solid fa-credit-card"></i> Transaksi</a><a href="../marketplace.php"><i class="fa-solid fa-store"></i> Market Olahraga</a><a href="../logout.php"><i class="fa-solid fa-sign-out-alt"></i> Logout</a></div>
    <div class="main-content">
        <h1>Kelola Transaksi Lapangan</h1>
        <p>Admin lapangan bisa mengubah transaksi menjadi sukses, pending, gagal, atau cancel. Jika transaksi dicancel, booking ikut cancel dan jadwal terbuka lagi.</p>
        <?php if(isset($_GET['success'])): ?><div class="alert-success"><?= e($_GET['success']) ?></div><?php endif; ?>
        <?php if(isset($_GET['error'])): ?><div class="alert-error"><?= e($_GET['error']) ?></div><?php endif; ?>
        <div class="admin-summary-grid">
            <div class="admin-mini-card"><small>Total Transaksi</small><strong><?= count($transactions) ?></strong></div>
            <div class="admin-mini-card"><small>Berhasil</small><strong>Rp <?= number_format($total_amount,0,',','.') ?></strong></div>
            <div class="admin-mini-card"><small>Pending</small><strong><?= $pending_count ?></strong></div>
            <div class="admin-mini-card"><small>Cancel</small><strong><?= $cancel_count ?></strong></div>
        </div>
        <div class="form-card">
            <h2>Daftar Transaksi</h2>
            <div class="filter-note"><i class="fa-solid fa-circle-info"></i> Pilih status langsung dari kolom status. Status <b>cancelled</b> otomatis membatalkan booking.</div>
            <div class="table-responsive"><table class="data-table">
                <thead><tr><th>Kode</th><th>Customer</th><th>Lapangan</th><th>Jadwal</th><th>Jumlah</th><th>Metode</th><th>Status Transaksi</th><th>Status Booking</th><th>Aksi</th></tr></thead>
                <tbody>
                <?php foreach($transactions as $trx): ?>
                    <tr>
                        <td><strong><?= e($trx['transaction_code']) ?></strong><br><small><?= date('d/m/Y H:i', strtotime($trx['created_at'])) ?></small></td>
                        <td><?= e($trx['nama_customer']) ?><br><small><?= e($trx['booking_source'] ?? 'online') ?></small></td>
                        <td><?= e($trx['nama_lapangan']) ?><br><small>Lapangan <?= (int)$trx['nomor_lapangan'] ?> | <?= e($trx['booking_code']) ?></small></td>
                        <td><?= date('d/m/Y', strtotime($trx['tanggal'])) ?><br><small><?= substr($trx['jam_mulai'],0,5) ?> - <?= substr($trx['jam_selesai'],0,5) ?></small></td>
                        <td>Rp <?= number_format($trx['amount'],0,',','.') ?></td>
                        <td><?= e(strtoupper($trx['payment_method'])) ?><br><small><?= e($trx['payment_channel']) ?></small></td>
                        <td>
                            <form method="POST">
                                <input type="hidden" name="transaction_id" value="<?= (int)$trx['id'] ?>">
                                <select name="status" class="status-select" onchange="if(confirm('Update status transaksi ini?')) this.form.submit(); else this.value='<?= e($trx['status']) ?>';">
                                    <option value="pending" <?= $trx['status']==='pending'?'selected':'' ?>>Pending</option>
                                    <option value="success" <?= $trx['status']==='success'?'selected':'' ?>>Success</option>
                                    <option value="failed" <?= $trx['status']==='failed'?'selected':'' ?>>Failed</option>
                                    <option value="cancelled" <?= $trx['status']==='cancelled'?'selected':'' ?>>Cancelled</option>
                                </select>
                                <input type="hidden" name="update_transaction" value="1">
                            </form>
                        </td>
                        <td><span class="status-badge status-<?= e($trx['booking_status']) ?>"><?= e($trx['booking_status']) ?></span><br><small>Payment: <?= e($trx['payment_status']) ?></small></td>
                        <td class="action-cell"><a href="../cetak-struk.php?transaction_id=<?= (int)$trx['id'] ?>" class="btn-secondary small-btn">Cetak</a></td>
                    </tr>
                <?php endforeach; ?>
                <?php if(!$transactions): ?><tr><td colspan="9" style="text-align:center">Belum ada transaksi</td></tr><?php endif; ?>
                </tbody>
            </table></div>
        </div>
    </div>
</div>
</body>
</html>
