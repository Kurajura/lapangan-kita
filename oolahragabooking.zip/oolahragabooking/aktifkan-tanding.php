<?php
include 'config/database.php';
if (!isLoggedIn() || getUserRole() !== 'user') {
    header("Location: login.php?error=Silakan login sebagai user terlebih dahulu");
    exit();
}
function backToHistory($message, $type = 'error') {
    header('Location: riwayat.php?' . $type . '=' . urlencode($message));
    exit();
}

$booking_id = (int)($_GET['booking_id'] ?? $_POST['booking_id'] ?? 0);
$stmt = $pdo->prepare("SELECT b.*, l.nama_lapangan, l.jenis_olahraga
                       FROM bookings b JOIN lapangan l ON b.lapangan_id = l.id
                       WHERE b.id = ? AND b.user_id = ? AND (b.booking_source IS NULL OR b.booking_source = 'online')");
$stmt->execute([$booking_id, getUserId()]);
$booking = $stmt->fetch();
if (!$booking) backToHistory('Booking tidak ditemukan');

$paidOk = in_array($booking['status'], ['paid','confirmed'], true) && $booking['payment_status'] === 'paid';
if (!$paidOk) backToHistory('Mode tanding hanya bisa diaktifkan setelah pembayaran benar-benar sukses');
if (!userHasActiveVip($pdo)) backToHistory('Mode tanding khusus member VIP. Aktifkan VIP dulu untuk memakai fitur tanding.');

$cek = $pdo->prepare("SELECT id FROM match_results WHERE booking_id = ? LIMIT 1");
$cek->execute([$booking_id]);
if ($cek->fetch()) backToHistory('Skor pertandingan ini sudah tercatat dan tidak bisa diajukan ulang');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $opponent_raw = trim($_POST['opponent_player'] ?? '');
    if ($opponent_raw === '') backToHistory('Masukkan ID/username/nama lawan solo.');
    if (in_array($booking['match_status'], ['pending_approval','waiting_score','pending_opponent_team','team_setup'], true)) {
        backToHistory('Permintaan tanding untuk booking ini masih berjalan.');
    }
    $ownerId = getUserId();
    $opponent = findPlayerByKeyword($pdo, $opponent_raw, [$ownerId]);
    if (!$opponent) backToHistory('User lawan tidak ditemukan. Gunakan ID pemain 6 angka atau username yang benar.');

    try {
        $pdo->beginTransaction();
        $pdo->prepare("DELETE FROM match_participants WHERE booking_id = ?")->execute([$booking_id]);
        $pdo->prepare("UPDATE team_match_requests SET status = 'cancelled' WHERE booking_id = ? AND status = 'pending'")->execute([$booking_id]);
        $insert = $pdo->prepare("INSERT INTO match_participants (booking_id, user_id, team, status, is_captain, invited_by, responded_at) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $insert->execute([$booking_id, $ownerId, 'challenger', 'accepted', 1, $ownerId, date('Y-m-d H:i:s')]);
        $insert->execute([$booking_id, (int)$opponent['id'], 'opponent', 'pending', 1, $ownerId, null]);
        $stmt = $pdo->prepare("UPDATE bookings SET mode_main='kompetitif', match_enabled=1, match_type='solo', match_status='pending_approval', match_requested_at=NOW(), match_opponent_name=?, match_rejected_reason=NULL, requester_team_id=NULL, opponent_team_id=NULL, team_match_request_id=NULL WHERE id=? AND user_id=?");
        $stmt->execute([getPlayerPublicName($opponent), $booking_id, $ownerId]);
        createNotification($pdo, (int)$opponent['id'], 'Undangan tanding solo', $_SESSION['username'] . ' mengundang kamu tanding solo di ' . $booking['nama_lapangan'] . '.', 'match-invitations.php');
        $pdo->commit();
        backToHistory('Undangan tanding solo berhasil dikirim. Menunggu persetujuan lawan.', 'success');
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        backToHistory('Gagal mengirim undangan solo: ' . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Tanding Solo - LapanganKita</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"><link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="top-header"><div class="promo-box">Mode Tanding <span>SOLO</span></div><div class="top-right"><div class="user-info"><i class="fa-regular fa-user"></i> <?= e($_SESSION['username']) ?> <a href="logout.php" style="color:#ff003c;">Logout</a></div></div></div>
<?php renderNavbar(''); ?>
<div class="public-page-wrap">
    <div class="form-card match-mode-card">
        <span class="match-badge completed">Solo / Single</span>
        <h2>Input Lawan Tanding Solo</h2>
        <p class="helper-text">Booking: <?= e($booking['booking_code']) ?> | <?= e($booking['nama_lapangan']) ?> | <?= date('d/m/Y', strtotime($booking['tanggal'])) ?>, <?= substr($booking['jam_mulai'],0,5) ?> - <?= substr($booking['jam_selesai'],0,5) ?></p>
        <form method="POST" class="match-solo-form">
            <input type="hidden" name="booking_id" value="<?= (int)$booking_id ?>">
            <label>ID / Username / Nama Lawan</label>
            <input type="text" name="opponent_player" id="opponent_player" placeholder="Contoh: 301902 atau budi" required>
            <div class="player-search-box">
                <input type="text" class="player-smart-search" placeholder="Cari pemain dulu di sini">
                <div class="player-search-result"></div>
            </div>
            <button class="btn-primary">Kirim Undangan Solo</button>
            <a href="team-tanding.php?booking_id=<?= (int)$booking_id ?>" class="btn-secondary">Pilih Mode Team</a>
        </form>
    </div>
</div>
<script>
const searchInput = document.querySelector('.player-smart-search');
const resultBox = document.querySelector('.player-search-result');
const targetInput = document.getElementById('opponent_player');
let timer = null;
searchInput.addEventListener('input', () => {
    clearTimeout(timer);
    const q = searchInput.value.trim();
    if (q.length < 2) { resultBox.innerHTML = ''; return; }
    timer = setTimeout(() => {
        fetch('search-players.php?q=' + encodeURIComponent(q)).then(r=>r.json()).then(rows=>{
            resultBox.innerHTML = rows.map(row => `<button type="button" data-code="${row.player_code}">${row.label}</button>`).join('') || '<small>Tidak ada pemain ditemukan</small>';
        });
    }, 250);
});
resultBox.addEventListener('click', e => {
    const btn = e.target.closest('button[data-code]');
    if (!btn) return;
    targetInput.value = btn.dataset.code;
    searchInput.value = '';
    resultBox.innerHTML = '';
});
</script>
</body></html>
