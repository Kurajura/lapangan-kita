<?php 
include 'config/database.php';
if (!isLoggedIn()) {
    header("Location: login.php?error=Silakan login terlebih dahulu");
    exit();
}

$lapangan_id = (int) ($_GET['id'] ?? $_POST['lapangan_id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM lapangan WHERE id = ? AND status = 'aktif'");
$stmt->execute([$lapangan_id]);
$lapangan = $stmt->fetch();

if (!$lapangan) {
    header("Location: booking.php?error=Lapangan tidak ditemukan");
    exit();
}

$jumlah_lapangan = max(1, (int) ($lapangan['jumlah_lapangan'] ?? 1));
$selected_date = $_POST['tanggal'] ?? $_GET['tanggal'] ?? date('Y-m-d');
$selected_nomor = (int) ($_POST['nomor_lapangan'] ?? $_GET['nomor_lapangan'] ?? 1);
if ($selected_nomor < 1 || $selected_nomor > $jumlah_lapangan) {
    $selected_nomor = 1;
}
if (!$selected_date || $selected_date < date('Y-m-d')) {
    $selected_date = date('Y-m-d');
}

$jam_buka = '06:00:00';
$jam_tutup = '23:00:00';
$jam_buka_min = 6 * 60;
$jam_tutup_min = 23 * 60;
$interval_timeline = 15; // menit, hanya untuk tampilan timeline

function formatJam($time) {
    return substr($time, 0, 5);
}

function normalizeTimeInput($time) {
    $time = trim((string) $time);
    if (!preg_match('/^([0-9]{1,2}):([0-9]{2})(:[0-9]{2})?$/', $time, $m)) {
        return '';
    }
    $hour = (int) $m[1];
    $minute = (int) $m[2];
    if ($hour < 0 || $hour > 23 || $minute < 0 || $minute > 59) {
        return '';
    }
    return sprintf('%02d:%02d:00', $hour, $minute);
}

function timeToMinutes($time) {
    $parts = explode(':', $time);
    return ((int) $parts[0] * 60) + (int) $parts[1];
}

function minutesToTime($minutes) {
    $hour = floor($minutes / 60);
    $minute = $minutes % 60;
    return sprintf('%02d:%02d:00', $hour, $minute);
}

function rangesOverlap($startA, $endA, $startB, $endB) {
    return timeToMinutes($startA) < timeToMinutes($endB) && timeToMinutes($endA) > timeToMinutes($startB);
}

function hitungDurasiMenit($start, $end) {
    return timeToMinutes($end) - timeToMinutes($start);
}

function hitungHargaFleksibel($hargaPerJam, $durasiMenit) {
    return (int) ceil(((float) $hargaPerJam / 60) * $durasiMenit);
}

function getBookedRanges($pdo, $lapangan_id, $nomor_lapangan, $tanggal) {
    $stmt = $pdo->prepare("SELECT b.jam_mulai, b.jam_selesai, b.booking_code, b.status, b.booking_source, b.nama_pelanggan, u.username
                           FROM bookings b
                           JOIN users u ON b.user_id = u.id
                           WHERE b.lapangan_id = ?
                           AND b.nomor_lapangan = ?
                           AND b.tanggal = ?
                           AND b.status <> 'cancelled'
                           ORDER BY b.jam_mulai ASC");
    $stmt->execute([$lapangan_id, $nomor_lapangan, $tanggal]);
    return $stmt->fetchAll();
}

function getClosedRanges($pdo, $lapangan_id, $nomor_lapangan, $tanggal) {
    $stmt = $pdo->prepare("SELECT jam_mulai, jam_selesai, alasan
                           FROM lapangan_tutup
                           WHERE lapangan_id = ?
                           AND nomor_lapangan = ?
                           AND tanggal = ?
                           ORDER BY jam_mulai ASC");
    $stmt->execute([$lapangan_id, $nomor_lapangan, $tanggal]);
    return $stmt->fetchAll();
}

function cekBentrokBooking($pdo, $lapangan_id, $nomor_lapangan, $tanggal, $jam_mulai, $jam_selesai) {
    $cekBooking = $pdo->prepare("SELECT id FROM bookings
                                 WHERE lapangan_id = ?
                                 AND nomor_lapangan = ?
                                 AND tanggal = ?
                                 AND status <> 'cancelled'
                                 AND jam_mulai < ?
                                 AND jam_selesai > ?
                                 LIMIT 1 FOR UPDATE");
    $cekBooking->execute([$lapangan_id, $nomor_lapangan, $tanggal, $jam_selesai, $jam_mulai]);
    return (bool) $cekBooking->fetch();
}

function cekBentrokTutup($pdo, $lapangan_id, $nomor_lapangan, $tanggal, $jam_mulai, $jam_selesai) {
    $cekTutup = $pdo->prepare("SELECT id FROM lapangan_tutup
                               WHERE lapangan_id = ?
                               AND nomor_lapangan = ?
                               AND tanggal = ?
                               AND jam_mulai < ?
                               AND jam_selesai > ?
                               LIMIT 1 FOR UPDATE");
    $cekTutup->execute([$lapangan_id, $nomor_lapangan, $tanggal, $jam_selesai, $jam_mulai]);
    return (bool) $cekTutup->fetch();
}

$booked_ranges = getBookedRanges($pdo, $lapangan_id, $selected_nomor, $selected_date);
$closed_ranges = getClosedRanges($pdo, $lapangan_id, $selected_nomor, $selected_date);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['buat_booking'])) {
    $tanggal = $_POST['tanggal'] ?? '';
    $nomor_lapangan = (int) ($_POST['nomor_lapangan'] ?? 1);
    $jam_mulai = normalizeTimeInput($_POST['jam_mulai'] ?? '');
    $jam_selesai = normalizeTimeInput($_POST['jam_selesai'] ?? '');
    $durasiMenit = ($jam_mulai && $jam_selesai) ? hitungDurasiMenit($jam_mulai, $jam_selesai) : 0;

    if ($tanggal < date('Y-m-d')) {
        $error = "Tanggal booking tidak boleh tanggal yang sudah lewat";
    } elseif ($nomor_lapangan < 1 || $nomor_lapangan > $jumlah_lapangan) {
        $error = "Nomor lapangan tidak valid";
    } elseif (!$jam_mulai || !$jam_selesai) {
        $error = "Format jam tidak valid. Gunakan format jam seperti 07:30 atau 09:23.";
    } elseif ($durasiMenit < 15) {
        $error = "Durasi minimal booking adalah 15 menit.";
    } elseif (timeToMinutes($jam_mulai) < $jam_buka_min || timeToMinutes($jam_selesai) > $jam_tutup_min) {
        $error = "Jam booking di luar jam operasional " . formatJam($jam_buka) . " - " . formatJam($jam_tutup);
    } else {
        $harga_normal = hitungHargaFleksibel($lapangan['harga_per_jam'], $durasiMenit);
        $vip_percent = getVipDiscountPercent($pdo, $_SESSION['user_id']);
        $vip_discount_amount = $vip_percent > 0 ? (int) floor($harga_normal * ($vip_percent / 100)) : 0;
        $total_harga = max(0, $harga_normal - $vip_discount_amount);
        $platform_fee = calculatePlatformFee($total_harga);
        $owner_amount = max(0, $total_harga - $platform_fee);
        $booking_code = 'BK' . date('Ymd') . rand(1000, 9999);

        try {
            $pdo->beginTransaction();

            if (cekBentrokBooking($pdo, $lapangan_id, $nomor_lapangan, $tanggal, $jam_mulai, $jam_selesai)) {
                $pdo->rollBack();
                $error = "Jam tersebut sudah dibooking. Silakan pilih jam lain.";
            } elseif (cekBentrokTutup($pdo, $lapangan_id, $nomor_lapangan, $tanggal, $jam_mulai, $jam_selesai)) {
                $pdo->rollBack();
                $error = "Jam tersebut sedang ditutup oleh admin. Silakan pilih jam lain.";
            } else {
                $stmt = $pdo->prepare("INSERT INTO bookings
                    (user_id, lapangan_id, nomor_lapangan, tanggal, jam_mulai, jam_selesai, total_harga, vip_discount_percent, vip_discount_amount, platform_fee, owner_amount, booking_code, booking_source)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'online')");
                $stmt->execute([$_SESSION['user_id'], $lapangan_id, $nomor_lapangan, $tanggal, $jam_mulai, $jam_selesai, $total_harga, $vip_percent, $vip_discount_amount, $platform_fee, $owner_amount, $booking_code]);
                $booking_id = $pdo->lastInsertId();
                $pdo->commit();
                header("Location: payment.php?booking_id=" . $booking_id);
                exit();
            }
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = "Booking gagal: " . $e->getMessage();
        }
    }

    $selected_date = $tanggal ?: $selected_date;
    $selected_nomor = $nomor_lapangan ?: $selected_nomor;
    $booked_ranges = getBookedRanges($pdo, $lapangan_id, $selected_nomor, $selected_date);
    $closed_ranges = getClosedRanges($pdo, $lapangan_id, $selected_nomor, $selected_date);
}

$timeline = [];
for ($minute = $jam_buka_min; $minute < $jam_tutup_min; $minute += $interval_timeline) {
    $start = minutesToTime($minute);
    $end = minutesToTime(min($minute + $interval_timeline, $jam_tutup_min));
    $status = 'available';
    $label = 'Tersedia';
    $note = 'Bisa dipilih sebagai patokan jam mulai';

    foreach ($closed_ranges as $range) {
        if (rangesOverlap($start, $end, $range['jam_mulai'], $range['jam_selesai'])) {
            $status = 'closed';
            $label = 'Tutup';
            $note = $range['alasan'] ?: 'Ditutup admin';
            break;
        }
    }

    if ($status === 'available') {
        foreach ($booked_ranges as $range) {
            if (rangesOverlap($start, $end, $range['jam_mulai'], $range['jam_selesai'])) {
                $status = 'booked';
                $label = 'Booked';
                $note = ($range['booking_source'] ?? 'online') === 'offline' ? 'Booking langsung/offline' : 'Booking online';
                break;
            }
        }
    }

    $timeline[] = [
        'start' => $start,
        'end' => $end,
        'status' => $status,
        'label' => $label,
        'note' => $note,
    ];
}

$busy_ranges = [];
foreach ($booked_ranges as $range) {
    $customer = $range['nama_pelanggan'] ?: $range['username'];
    $busy_ranges[] = [
        'type' => 'booked',
        'start' => formatJam($range['jam_mulai']),
        'end' => formatJam($range['jam_selesai']),
        'label' => (($range['booking_source'] ?? 'online') === 'offline' ? 'Booking offline' : 'Booking online') . ' - ' . $customer,
    ];
}
foreach ($closed_ranges as $range) {
    $busy_ranges[] = [
        'type' => 'closed',
        'start' => formatJam($range['jam_mulai']),
        'end' => formatJam($range['jam_selesai']),
        'label' => 'Ditutup admin' . ($range['alasan'] ? ' - ' . $range['alasan'] : ''),
    ];
}
usort($busy_ranges, function($a, $b) {
    return strcmp($a['start'], $b['start']);
});

$busy_json = json_encode($busy_ranges, JSON_UNESCAPED_UNICODE);
$harga_per_jam = (float) $lapangan['harga_per_jam'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking - <?= htmlspecialchars($lapangan['nama_lapangan']) ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="top-header">
    <div class="promo-box"> Booking Lapangan <span>FLEKSIBEL</span></div>
    <div class="top-right">
        <div class="user-info">
            <i class="fa-regular fa-user"></i> <?= htmlspecialchars($_SESSION['username']) ?>
            <a href="logout.php" style="color:#ff003c;">Logout</a>
        </div>
    </div>
</div>
<?php renderNavbar(''); ?>

<div class="booking-page-wrap">
    <div class="booking-hero-card">
        <div class="booking-hero-image">
            <?php if($lapangan['foto']): ?>
                <img src="assets/uploads/<?= htmlspecialchars($lapangan['foto']) ?>" alt="<?= htmlspecialchars($lapangan['nama_lapangan']) ?>">
            <?php else: ?>
                <i class="fa-solid fa-futbol"></i>
            <?php endif; ?>
        </div>
        <div class="booking-hero-info">
            <span class="mini-badge"><?= htmlspecialchars($lapangan['jenis_olahraga']) ?></span>
            <h1><?= htmlspecialchars($lapangan['nama_lapangan']) ?></h1>
            <p><?= nl2br(htmlspecialchars($lapangan['deskripsi'] ?: 'Belum ada deskripsi.')) ?></p>
            <div class="booking-info-grid">
                <div><i class="fa-solid fa-money-bill-wave"></i><strong>Rp <?= number_format($lapangan['harga_per_jam'], 0, ',', '.') ?></strong><span>/ jam, dihitung per menit</span></div>
                <div><i class="fa-solid fa-layer-group"></i><strong><?= $jumlah_lapangan ?></strong><span>unit lapangan</span></div>
                <div><i class="fa-solid fa-clock"></i><strong><?= formatJam($jam_buka) ?> - <?= formatJam($jam_tutup) ?></strong><span>jam operasional</span></div>
            </div>
            <a href="detail-lapangan.php?id=<?= $lapangan['id'] ?>" class="btn-secondary"><i class="fa-solid fa-circle-info"></i> Lihat Detail Lapangan</a>
        </div>
    </div>

    <?php if(isset($error)): ?>
        <div class="alert-error wide-alert"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="booking-board">
        <div class="booking-board-head">
            <div>
                <h2>Pilih Jadwal Fleksibel</h2>
                <p>Jam mulai dan selesai bisa bebas sampai menit, contoh 07:30, 07:43, 09:23, atau 10:15.</p>
            </div>
            <div class="legend-wrap">
                <span><b class="legend-dot available"></b> Tersedia</span>
                <span><b class="legend-dot booked"></b> Dibooking</span>
                <span><b class="legend-dot closed"></b> Ditutup</span>
            </div>
        </div>

        <form method="GET" class="schedule-filter-form">
            <input type="hidden" name="id" value="<?= $lapangan['id'] ?>">
            <div class="form-group">
                <label>Pilih Nomor Lapangan</label>
                <select name="nomor_lapangan" required>
                    <?php for($i = 1; $i <= $jumlah_lapangan; $i++): ?>
                        <option value="<?= $i ?>" <?= $selected_nomor === $i ? 'selected' : '' ?>>Lapangan <?= $i ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Tanggal Main</label>
                <input type="date" name="tanggal" required min="<?= date('Y-m-d') ?>" value="<?= htmlspecialchars($selected_date) ?>">
            </div>
            <button type="submit" class="btn-primary filter-btn"><i class="fa-solid fa-rotate"></i> Tampilkan Jadwal</button>
        </form>

        <div class="slot-date-title">
            <i class="fa-solid fa-calendar-day"></i>
            Jadwal <?= date('d/m/Y', strtotime($selected_date)) ?> - Lapangan <?= $selected_nomor ?>
        </div>

        <div class="timeline-grid-flex">
            <?php foreach($timeline as $item): ?>
                <button type="button"
                        class="timeline-chip <?= $item['status'] ?>"
                        data-start="<?= formatJam($item['start']) ?>"
                        title="<?= htmlspecialchars(formatJam($item['start']) . ' - ' . formatJam($item['end']) . ' | ' . $item['note']) ?>"
                        <?= $item['status'] !== 'available' ? 'disabled' : '' ?>>
                    <strong><?= formatJam($item['start']) ?></strong>
                    <span><?= $item['label'] ?></span>
                </button>
            <?php endforeach; ?>
        </div>

        <div class="blocked-list-box">
            <h3>Jadwal yang tidak bisa dibooking</h3>
            <?php if(count($busy_ranges) > 0): ?>
                <div class="blocked-list">
                    <?php foreach($busy_ranges as $range): ?>
                        <div class="blocked-item <?= $range['type'] ?>">
                            <strong><?= htmlspecialchars($range['start']) ?> - <?= htmlspecialchars($range['end']) ?></strong>
                            <span><?= htmlspecialchars($range['label']) ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p class="helper-text">Belum ada booking atau jadwal tutup pada tanggal dan lapangan ini.</p>
            <?php endif; ?>
        </div>

        <form method="POST" id="bookingForm" class="manual-time-panel">
            <input type="hidden" name="buat_booking" value="1">
            <input type="hidden" name="lapangan_id" value="<?= $lapangan['id'] ?>">
            <input type="hidden" name="nomor_lapangan" value="<?= $selected_nomor ?>">
            <input type="hidden" name="tanggal" value="<?= htmlspecialchars($selected_date) ?>">

            <div class="time-input-grid">
                <div class="form-group">
                    <label>Jam Mulai</label>
                    <input type="time" name="jam_mulai" id="jamMulai" min="06:00" max="22:59" step="60" required>
                    <small>Bisa isi bebas, contoh 07:43</small>
                </div>
                <div class="form-group">
                    <label>Jam Selesai</label>
                    <input type="time" name="jam_selesai" id="jamSelesai" min="06:01" max="23:00" step="60" required>
                    <small>Contoh 08:43 atau 10:23</small>
                </div>
                <div class="form-group">
                    <label>Durasi Cepat</label>
                    <div class="quick-duration-wrap">
                        <button type="button" data-minutes="30">+30 menit</button>
                        <button type="button" data-minutes="60">+1 jam</button>
                        <button type="button" data-minutes="90">+1,5 jam</button>
                        <button type="button" data-minutes="120">+2 jam</button>
                    </div>
                </div>
            </div>

            <div class="booking-summary-box flexible-summary" id="bookingSummary">
                <div>
                    <small>Jadwal Dipilih</small>
                    <strong id="summaryJam">Belum memilih jam</strong>
                </div>
                <div>
                    <small>Durasi</small>
                    <strong id="summaryDurasi">0 menit</strong>
                </div>
                <div>
                    <small>Total Harga</small>
                    <strong id="summaryHarga">Rp 0</strong>
                </div>
                <button type="submit" class="btn-primary" id="submitBooking" disabled>Lanjutkan ke Pembayaran</button>
            </div>
            <div class="alert-error" id="clientError" style="display:none; margin-top:14px;"></div>
        </form>
    </div>
</div>

<script>
const busyRanges = <?= $busy_json ?: '[]' ?>;
const hargaPerJam = <?= json_encode($harga_per_jam) ?>;
const jamBuka = 6 * 60;
const jamTutup = 23 * 60;
const startInput = document.getElementById('jamMulai');
const endInput = document.getElementById('jamSelesai');
const submitBooking = document.getElementById('submitBooking');
const summaryJam = document.getElementById('summaryJam');
const summaryDurasi = document.getElementById('summaryDurasi');
const summaryHarga = document.getElementById('summaryHarga');
const clientError = document.getElementById('clientError');

function rupiah(value) {
    return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(value);
}

function timeToMinutesClient(time) {
    if (!time || !time.includes(':')) return NaN;
    const [h, m] = time.split(':').map(Number);
    return h * 60 + m;
}

function minutesToTimeClient(minutes) {
    const h = Math.floor(minutes / 60).toString().padStart(2, '0');
    const m = (minutes % 60).toString().padStart(2, '0');
    return `${h}:${m}`;
}

function overlaps(startA, endA, startB, endB) {
    return startA < endB && endA > startB;
}

function showError(message) {
    clientError.style.display = 'block';
    clientError.textContent = message;
    submitBooking.disabled = true;
}

function clearError() {
    clientError.style.display = 'none';
    clientError.textContent = '';
}

function updateSummary() {
    const start = timeToMinutesClient(startInput.value);
    const end = timeToMinutesClient(endInput.value);
    submitBooking.disabled = true;
    summaryJam.textContent = 'Belum memilih jam';
    summaryDurasi.textContent = '0 menit';
    summaryHarga.textContent = 'Rp 0';
    clearError();

    if (Number.isNaN(start) || Number.isNaN(end)) return;
    if (end <= start) {
        showError('Jam selesai harus lebih besar dari jam mulai.');
        return;
    }
    if (start < jamBuka || end > jamTutup) {
        showError('Jam harus berada di jam operasional 06:00 - 23:00.');
        return;
    }
    const durasi = end - start;
    if (durasi < 15) {
        showError('Durasi minimal booking adalah 15 menit.');
        return;
    }

    for (const range of busyRanges) {
        const busyStart = timeToMinutesClient(range.start);
        const busyEnd = timeToMinutesClient(range.end);
        if (overlaps(start, end, busyStart, busyEnd)) {
            const jenis = range.type === 'closed' ? 'ditutup admin' : 'sudah dibooking';
            showError(`Jam yang dipilih bertabrakan dengan jadwal ${jenis}: ${range.start} - ${range.end}.`);
            return;
        }
    }

    const harga = Math.ceil((hargaPerJam / 60) * durasi);
    summaryJam.textContent = `${startInput.value} - ${endInput.value}`;
    summaryDurasi.textContent = durasi >= 60 ? `${Math.floor(durasi / 60)} jam ${durasi % 60 ? (durasi % 60) + ' menit' : ''}` : `${durasi} menit`;
    summaryHarga.textContent = rupiah(harga);
    submitBooking.disabled = false;
}

startInput.addEventListener('input', updateSummary);
endInput.addEventListener('input', updateSummary);

for (const btn of document.querySelectorAll('.quick-duration-wrap button')) {
    btn.addEventListener('click', () => {
        const start = timeToMinutesClient(startInput.value);
        if (Number.isNaN(start)) {
            showError('Isi jam mulai dulu, baru pilih durasi cepat.');
            return;
        }
        const end = start + Number(btn.dataset.minutes);
        endInput.value = minutesToTimeClient(end);
        updateSummary();
    });
}

for (const chip of document.querySelectorAll('.timeline-chip.available')) {
    chip.addEventListener('click', () => {
        startInput.value = chip.dataset.start;
        if (!endInput.value || timeToMinutesClient(endInput.value) <= timeToMinutesClient(startInput.value)) {
            endInput.value = minutesToTimeClient(timeToMinutesClient(startInput.value) + 60);
        }
        updateSummary();
        document.querySelectorAll('.timeline-chip').forEach(c => c.classList.remove('selected'));
        chip.classList.add('selected');
    });
}

document.getElementById('bookingForm').addEventListener('submit', function(e) {
    updateSummary();
    if (submitBooking.disabled) {
        e.preventDefault();
    }
});
</script>
</body>
</html>
