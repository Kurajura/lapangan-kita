<?php
include 'config/database.php';
$searchQuery = trim($_GET['q'] ?? '');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Lapangan - LapanganKita</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="top-header">
    <div class="promo-box"> Booking Lapangan Olahraga <span>PREMIUM</span></div>
    <div class="top-right">
        <?php if(isLoggedIn()): ?>
            <div class="user-info">
                <i class="fa-regular fa-user"></i> <?= htmlspecialchars($_SESSION['username']) ?>
                <a href="logout.php" style="color:#ff003c; margin-left:10px;">Logout</a>
            </div>
        <?php else: ?>
            <a href="login.php" class="login-btn"><div class="login-icon"><i class="fa-regular fa-user"></i></div> Login</a>
            <a href="register.php" class="plan-btn">Daftar</a>
        <?php endif; ?>
    </div>
</div>
<?php renderNavbar(''); ?>

<div class="page-header">
    <h1>Booking Lapangan</h1>
    <?php if($searchQuery !== ''): ?>
        <p>Hasil pencarian untuk: <strong><?= e($searchQuery) ?></strong></p>
    <?php else: ?>
        <p>Pilih lapangan sesuai kebutuhanmu</p>
    <?php endif; ?>
</div>

<div class="card-grid">
    <?php
    if ($searchQuery !== '') {
        $keyword = '%' . $searchQuery . '%';
        $stmt = $pdo->prepare("SELECT l.*, u.full_name as admin_name 
                               FROM lapangan l 
                               JOIN users u ON l.admin_id = u.id 
                               WHERE l.status = 'aktif' 
                               AND (l.nama_lapangan LIKE ? OR l.jenis_olahraga LIKE ? OR l.alamat LIKE ? OR l.wilayah LIKE ? OR l.kabupaten LIKE ? OR l.deskripsi LIKE ?)
                               ORDER BY 
                                 CASE WHEN l.nama_lapangan LIKE ? THEN 0 ELSE 1 END,
                                 l.created_at DESC");
        $stmt->execute([$keyword, $keyword, $keyword, $keyword, $keyword, $keyword, $keyword]);
        $lapangan = $stmt->fetchAll();
    } else {
        $stmt = $pdo->query("SELECT l.*, u.full_name as admin_name FROM lapangan l JOIN users u ON l.admin_id = u.id WHERE l.status = 'aktif' ORDER BY l.created_at DESC");
        $lapangan = $stmt->fetchAll();
    }
    
    if (count($lapangan) > 0):
        foreach($lapangan as $lap):
    ?>
    <div class="card field-card">
        <div class="card-image">
            <?php if($lap['foto']): ?>
                <img src="assets/uploads/<?= htmlspecialchars($lap['foto']) ?>" alt="<?= htmlspecialchars($lap['nama_lapangan']) ?>">
            <?php else: ?>
                <i class="fa-solid fa-futbol"></i>
            <?php endif; ?>
        </div>
        <h3><?= htmlspecialchars($lap['nama_lapangan']) ?></h3>
        <p><i class="fa-regular fa-building"></i> <?= htmlspecialchars($lap['jenis_olahraga']) ?></p>
        <p><i class="fa-solid fa-user-tie"></i> Pemilik: <?= htmlspecialchars($lap['admin_name'] ?: '-') ?></p>
        <p><i class="fa-solid fa-layer-group"></i> <?= (int) $lap['jumlah_lapangan'] ?> unit lapangan tersedia</p>
        <p><i class="fa-solid fa-location-dot"></i> <?= htmlspecialchars($lap['alamat'] ?: '-') ?></p>
        <p><small><?= htmlspecialchars(substr($lap['deskripsi'] ?: 'Belum ada deskripsi', 0, 110)) ?>...</small></p>
        <div class="price">Rp <?= number_format($lap['harga_per_jam'], 0, ',', '.') ?> / jam</div>
        <div class="card-actions">
            <a href="detail-lapangan.php?id=<?= $lap['id'] ?>" class="btn-secondary"><i class="fa-solid fa-circle-info"></i> Detail</a>
            <a href="<?= isLoggedIn() ? 'booking-process.php?id=' . $lap['id'] : 'login.php?error=Silakan login dulu untuk booking lapangan' ?>" class="btn-book">Booking Sekarang</a>
        </div>
    </div>
    <?php 
        endforeach;
    else:
    ?>
    <div class="card" style="text-align: center;">
        <?php if($searchQuery !== ''): ?>
            <p>Tidak ada lapangan yang cocok dengan pencarian <strong><?= e($searchQuery) ?></strong>.</p>
            <p style="margin-top:10px;"><a href="booking.php" class="btn-secondary">Lihat Semua Lapangan</a></p>
        <?php else: ?>
            <p>Belum ada lapangan tersedia</p>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>

</body>
</html>
