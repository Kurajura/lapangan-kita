<?php 
include 'config/database.php';
if (!isLoggedIn()) {
    header("Location: login.php?error=Silakan login terlebih dahulu");
    exit();
}

$transaction_id = $_GET['transaction_id'] ?? 0;
$booking_id = $_GET['booking_id'] ?? 0;

if ($transaction_id > 0) {
    $stmt = $pdo->prepare("SELECT t.*, b.booking_code, b.nomor_lapangan, b.tanggal, b.jam_mulai, b.jam_selesai, b.total_harga, b.booking_source, b.nama_pelanggan, b.telepon_pelanggan, l.nama_lapangan, u.username, COALESCE(NULLIF(b.nama_pelanggan, ''), u.username) AS nama_customer 
                           FROM transactions t 
                           JOIN bookings b ON t.booking_id = b.id 
                           JOIN lapangan l ON b.lapangan_id = l.id 
                           JOIN users u ON b.user_id = u.id 
                           WHERE t.id = ?");
    $stmt->execute([$transaction_id]);
} else {
    $stmt = $pdo->prepare("SELECT b.*, l.nama_lapangan, u.username, COALESCE(NULLIF(b.nama_pelanggan, ''), u.username) AS nama_customer 
                           FROM bookings b 
                           JOIN lapangan l ON b.lapangan_id = l.id 
                           JOIN users u ON b.user_id = u.id 
                           WHERE b.id = ?");
    $stmt->execute([$booking_id]);
}

$data = $stmt->fetch();

if (!$data) {
    die("Data tidak ditemukan");
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Struk Pembayaran - LapanganKita</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Courier New', monospace;
            background: #f0f0f0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }
        .struk {
            max-width: 400px;
            width: 100%;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.2);
        }
        .header {
            text-align: center;
            border-bottom: 2px dashed #333;
            padding-bottom: 10px;
            margin-bottom: 15px;
        }
        .header h1 {
            font-size: 20px;
            color: #00b894;
        }
        .header p {
            font-size: 12px;
            color: #666;
        }
        .info-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            font-size: 12px;
        }
        .info-row .label {
            font-weight: bold;
        }
        .divider {
            border-top: 1px dashed #ccc;
            margin: 15px 0;
        }
        .total {
            font-size: 16px;
            font-weight: bold;
            margin: 10px 0;
            text-align: right;
        }
        .footer {
            text-align: center;
            margin-top: 20px;
            font-size: 10px;
            color: #666;
            border-top: 1px dashed #ccc;
            padding-top: 10px;
        }
        .print-btn {
            display: block;
            width: 100%;
            padding: 12px;
            margin-top: 20px;
            background: #00b894;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
        }
        @media print {
            .print-btn {
                display: none;
            }
            body {
                background: white;
                padding: 0;
            }
        }
    </style>
</head>
<body>
<div class="struk">
    <div class="header">
        <h1>LAPANGANKITA</h1>
        <p>Booking Lapangan Olahraga</p>
        <p><?= date('d/m/Y H:i:s') ?></p>
    </div>
    
    <div class="info-row">
        <span class="label">Kode Booking:</span>
        <span><?= $data['booking_code'] ?? '-' ?></span>
    </div>
    <div class="info-row">
        <span class="label">Nama Customer:</span>
        <span><?= htmlspecialchars($data['nama_customer']) ?></span>
    </div>

    <div class="info-row">
        <span class="label">Sumber Booking:</span>
        <span><?= ($data['booking_source'] ?? 'online') === 'offline' ? 'Booking Langsung/Offline' : 'Booking Online' ?></span>
    </div>
    <?php if(($data['booking_source'] ?? 'online') === 'offline' && !empty($data['telepon_pelanggan'])): ?>
    <div class="info-row">
        <span class="label">No. HP:</span>
        <span><?= htmlspecialchars($data['telepon_pelanggan']) ?></span>
    </div>
    <?php endif; ?>
    <div class="info-row">
        <span class="label">Lapangan:</span>
        <span><?= htmlspecialchars($data['nama_lapangan']) ?></span>
    </div>
    <div class="info-row">
        <span class="label">No. Lapangan:</span>
        <span>Lapangan <?= (int) $data['nomor_lapangan'] ?></span>
    </div>
    <div class="info-row">
        <span class="label">Tanggal:</span>
        <span><?= date('d/m/Y', strtotime($data['tanggal'])) ?></span>
    </div>
    <div class="info-row">
        <span class="label">Jam:</span>
        <span><?= substr($data['jam_mulai'], 0, 5) ?> - <?= substr($data['jam_selesai'], 0, 5) ?></span>
    </div>
    
    <div class="divider"></div>
    
    <div class="total">
        Total Pembayaran: Rp <?= number_format($data['total_harga'], 0, ',', '.') ?>
    </div>
    
    <?php if(isset($data['payment_method'])): ?>
    <div class="info-row">
        <span class="label">Metode Bayar:</span>
        <span><?= strtoupper($data['payment_method']) ?> - <?= $data['payment_channel'] ?></span>
    </div>
    <div class="info-row">
        <span class="label">Kode Transaksi:</span>
        <span><?= $data['transaction_code'] ?></span>
    </div>
    <div class="info-row">
        <span class="label">Status:</span>
        <span style="color: green;">LUNAS</span>
    </div>
    <?php endif; ?>
    
    <div class="footer">
        <p>Terima kasih telah menggunakan layanan kami!</p>
        <p>Booking online di LapanganKita.com</p>
    </div>
    
    <button class="print-btn" onclick="window.print()">🖨️ Cetak Struk</button>
</div>
</body>
</html>