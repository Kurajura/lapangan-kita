<?php
include 'config/database.php';
header('Content-Type: application/json');
if (!isLoggedIn() || getUserRole() !== 'user') { echo json_encode([]); exit(); }
$peer_id = (int)($_GET['user_id'] ?? 0);
if ($peer_id <= 0 || $peer_id === getUserId()) { echo json_encode([]); exit(); }
$stmt = $pdo->prepare("SELECT id FROM users WHERE id=? AND role='user'");
$stmt->execute([$peer_id]);
if (!$stmt->fetch()) { echo json_encode([]); exit(); }
$pdo->prepare("UPDATE chat_messages SET is_read=1 WHERE sender_id=? AND receiver_id=?")->execute([$peer_id, getUserId()]);
$stmt = $pdo->prepare("SELECT * FROM chat_messages WHERE (sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?) ORDER BY created_at ASC, id ASC LIMIT 200");
$stmt->execute([getUserId(), $peer_id, $peer_id, getUserId()]);
$out=[];
foreach($stmt->fetchAll() as $m){
    $out[] = ['id'=>(int)$m['id'], 'mine'=>(int)$m['sender_id']===getUserId(), 'message'=>$m['message'], 'time'=>date('d/m H:i', strtotime($m['created_at']))];
}
echo json_encode($out);
