<?php
include 'config/database.php';
header('Content-Type: application/json');
if (!isLoggedIn() || getUserRole() !== 'user') { echo json_encode(['ok'=>false,'error'=>'Login dulu']); exit(); }
$receiver_id = (int)($_POST['receiver_id'] ?? 0);
$message = trim($_POST['message'] ?? '');
if ($receiver_id <= 0 || $receiver_id === getUserId()) { echo json_encode(['ok'=>false,'error'=>'Penerima tidak valid']); exit(); }
if ($message === '') { echo json_encode(['ok'=>false,'error'=>'Pesan kosong']); exit(); }
if (mb_strlen($message) > 1000) { echo json_encode(['ok'=>false,'error'=>'Pesan terlalu panjang']); exit(); }
$stmt = $pdo->prepare("SELECT id FROM users WHERE id=? AND role='user'");
$stmt->execute([$receiver_id]);
if (!$stmt->fetch()) { echo json_encode(['ok'=>false,'error'=>'User tidak ditemukan']); exit(); }
$stmt = $pdo->prepare("INSERT INTO chat_messages (sender_id, receiver_id, message) VALUES (?, ?, ?)");
$stmt->execute([getUserId(), $receiver_id, $message]);
createNotification($pdo, $receiver_id, 'Pesan chat baru', $_SESSION['username'] . ' mengirim pesan chat.', 'chat.php?user_id=' . getUserId());
echo json_encode(['ok'=>true]);
