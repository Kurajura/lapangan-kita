<?php
include 'config/database.php';
if (!isLoggedIn() || getUserRole() !== 'user') {
    header('Location: login.php?error=Silakan login sebagai user terlebih dahulu');
    exit();
}
$peer_id = (int)($_GET['user_id'] ?? 0);
$peer = null;
if ($peer_id > 0 && $peer_id !== getUserId()) {
    $stmt = $pdo->prepare("SELECT id, username, player_code, full_name, display_name, profile_photo, bio FROM users WHERE id = ? AND role='user'");
    $stmt->execute([$peer_id]);
    $peer = $stmt->fetch();
}
$q = trim($_GET['q'] ?? '');
if ($q !== '') {
    $like = '%' . $q . '%';
    $stmt = $pdo->prepare("SELECT id, username, player_code, full_name, display_name, profile_photo FROM users WHERE role='user' AND id<>? AND (username LIKE ? OR player_code LIKE ? OR full_name LIKE ? OR display_name LIKE ?) ORDER BY username ASC LIMIT 20");
    $stmt->execute([getUserId(), $like, $like, $like, $like]);
} else {
    $stmt = $pdo->prepare("SELECT u.id, u.username, u.player_code, u.full_name, u.display_name, u.profile_photo,
                                  MAX(cm.created_at) AS last_chat
                           FROM users u
                           LEFT JOIN chat_messages cm ON (cm.sender_id=u.id AND cm.receiver_id=?) OR (cm.sender_id=? AND cm.receiver_id=u.id)
                           WHERE u.role='user' AND u.id<>?
                           GROUP BY u.id
                           ORDER BY last_chat DESC, u.username ASC LIMIT 20");
    $stmt->execute([getUserId(), getUserId(), getUserId()]);
}
$users = $stmt->fetchAll();
?>
<!DOCTYPE html><html lang="id"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Chat User - LapanganKita</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"><link rel="stylesheet" href="assets/css/style.css">
</head><body>
<div class="top-header"><div class="promo-box">Chat Pemain <span>REAL TIME</span></div><div class="top-right"><div class="user-info"><i class="fa-regular fa-user"></i> <?= e($_SESSION['username']) ?> <a href="logout.php" style="color:#ff003c;">Logout</a></div></div></div>
<?php renderNavbar(''); ?>
<div class="public-page-wrap chat-wrap">
    <div class="chat-layout">
        <aside class="chat-sidebar form-card">
            <h2>Daftar Pemain</h2>
            <form method="GET" class="chat-search"><input type="text" name="q" value="<?= e($q) ?>" placeholder="Cari nama / username / ID"><button class="btn-primary small-btn">Cari</button></form>
            <div class="chat-user-list">
                <?php foreach($users as $u): $name = getPlayerPublicName($u); ?>
                    <a class="chat-user-item <?= $peer_id===(int)$u['id']?'active':'' ?>" href="chat.php?user_id=<?= (int)$u['id'] ?>">
                        <div class="chat-avatar"><?= $u['profile_photo'] ? '<img src="assets/profiles/'.e($u['profile_photo']).'" alt="">' : '<i class="fa-solid fa-user"></i>' ?></div>
                        <div><strong><?= e($name) ?></strong><small>ID <?= e($u['player_code']) ?> | @<?= e($u['username']) ?></small></div>
                    </a>
                <?php endforeach; ?>
            </div>
        </aside>
        <main class="chat-main form-card">
            <?php if($peer): ?>
                <div class="chat-head"><div><h2><?= e(getPlayerPublicName($peer)) ?></h2><p>ID <?= e($peer['player_code']) ?> | @<?= e($peer['username']) ?></p></div><a class="btn-secondary small-btn" href="profile.php?id=<?= (int)$peer['id'] ?>">Profil</a></div>
                <div id="chatMessages" class="chat-messages"><div class="helper-text">Memuat chat...</div></div>
                <form id="chatForm" class="chat-form"><input type="hidden" name="receiver_id" value="<?= (int)$peer['id'] ?>"><textarea name="message" placeholder="Tulis pesan untuk atur jadwal tanding..." autocomplete="off" required></textarea><button class="btn-primary"><i class="fa-solid fa-paper-plane"></i> Kirim</button></form>
            <?php else: ?>
                <div class="empty-chat"><i class="fa-solid fa-comments"></i><h2>Pilih pemain untuk mulai chat</h2><p>Gunakan fitur ini untuk komunikasi sebelum tanding dan atur jam ketemu.</p></div>
            <?php endif; ?>
        </main>
    </div>
</div>
<?php if($peer): ?>
<script>
const box = document.getElementById('chatMessages');
const form = document.getElementById('chatForm');
const peerId = <?= (int)$peer['id'] ?>;
let firstLoad = true;
function esc(text){ const div=document.createElement('div'); div.textContent=text; return div.innerHTML; }
function loadMessages(){
    fetch('chat-fetch.php?user_id=' + peerId).then(r=>r.json()).then(rows=>{
        box.innerHTML = rows.map(m => `<div class="chat-bubble ${m.mine ? 'mine' : 'theirs'}"><div>${esc(m.message)}</div><small>${m.time}</small></div>`).join('') || '<div class="helper-text">Belum ada pesan. Mulai chat sekarang.</div>';
        if(firstLoad){ box.scrollTop = box.scrollHeight; firstLoad=false; }
    });
}
form.addEventListener('submit', e => {
    e.preventDefault();
    const data = new FormData(form);
    fetch('chat-send.php', {method:'POST', body:data}).then(r=>r.json()).then(res=>{
        if(res.ok){ form.message.value=''; loadMessages(); setTimeout(()=>box.scrollTop=box.scrollHeight,100); }
        else alert(res.error || 'Gagal kirim pesan');
    });
});
loadMessages();
setInterval(loadMessages, 2500);
</script>
<?php endif; ?>
</body></html>
