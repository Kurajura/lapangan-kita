<?php
$host = 'localhost';
$dbname = 'oolahragabooking_baru';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Koneksi database gagal: " . $e->getMessage());
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function isLoggedIn() { return isset($_SESSION['user_id']); }
function isAdmin() { return isset($_SESSION['role']) && $_SESSION['role'] == 'admin'; }
function isSuperAdmin() { return isset($_SESSION['role']) && $_SESSION['role'] == 'super_admin'; }
function getUserRole() { return $_SESSION['role'] ?? null; }
function getUserId() { return $_SESSION['user_id'] ?? null; }
function e($value) { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }

function columnExists($pdo, $table, $column) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?");
    $stmt->execute([$table, $column]);
    return (int) $stmt->fetchColumn() > 0;
}

function tableExists($pdo, $table) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?");
    $stmt->execute([$table]);
    return (int) $stmt->fetchColumn() > 0;
}

function indexExists($pdo, $table, $index) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ?");
    $stmt->execute([$table, $index]);
    return (int) $stmt->fetchColumn() > 0;
}

function addColumnIfMissing($pdo, $table, $column, $definition) {
    if (!columnExists($pdo, $table, $column)) {
        $pdo->exec("ALTER TABLE `$table` ADD COLUMN $definition");
    }
}

function execSafe($pdo, $sql) {
    try { $pdo->exec($sql); } catch (Exception $e) { /* aman untuk import berulang */ }
}

function ensureAppUpgradeSchema($pdo) {
    static $done = false;
    if ($done) return;
    $done = true;

    try {
        addColumnIfMissing($pdo, 'bookings', 'match_enabled', "`match_enabled` TINYINT(1) NOT NULL DEFAULT 0 AFTER `mode_main`");
        addColumnIfMissing($pdo, 'bookings', 'match_type', "`match_type` ENUM('solo','team') NOT NULL DEFAULT 'solo' AFTER `match_enabled`");
        addColumnIfMissing($pdo, 'bookings', 'match_status', "`match_status` ENUM('inactive','team_setup','team_ready','pending_opponent_team','pending_approval','approved','waiting_score','rejected','completed','cancelled') NOT NULL DEFAULT 'inactive' AFTER `match_type`");
        addColumnIfMissing($pdo, 'bookings', 'match_requested_at', "`match_requested_at` TIMESTAMP NULL DEFAULT NULL AFTER `match_status`");
        addColumnIfMissing($pdo, 'bookings', 'match_opponent_name', "`match_opponent_name` VARCHAR(100) DEFAULT NULL AFTER `match_requested_at`");
        addColumnIfMissing($pdo, 'bookings', 'match_rejected_reason', "`match_rejected_reason` VARCHAR(255) DEFAULT NULL AFTER `match_opponent_name`");
        addColumnIfMissing($pdo, 'bookings', 'requester_team_id', "`requester_team_id` INT(11) DEFAULT NULL AFTER `match_rejected_reason`");
        addColumnIfMissing($pdo, 'bookings', 'opponent_team_id', "`opponent_team_id` INT(11) DEFAULT NULL AFTER `requester_team_id`");
        addColumnIfMissing($pdo, 'bookings', 'team_match_request_id', "`team_match_request_id` INT(11) DEFAULT NULL AFTER `opponent_team_id`");
        addColumnIfMissing($pdo, 'bookings', 'vip_discount_percent', "`vip_discount_percent` DECIMAL(5,2) NOT NULL DEFAULT 0.00 AFTER `total_harga`");
        addColumnIfMissing($pdo, 'bookings', 'vip_discount_amount', "`vip_discount_amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER `vip_discount_percent`");
        addColumnIfMissing($pdo, 'bookings', 'platform_fee', "`platform_fee` DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER `vip_discount_amount`");
        addColumnIfMissing($pdo, 'bookings', 'owner_amount', "`owner_amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER `platform_fee`");
        execSafe($pdo, "ALTER TABLE `bookings` MODIFY `match_status` ENUM('inactive','team_setup','team_ready','pending_opponent_team','pending_approval','approved','waiting_score','rejected','completed','cancelled') NOT NULL DEFAULT 'inactive'");
        execSafe($pdo, "ALTER TABLE `bookings` MODIFY `match_type` ENUM('solo','team') NOT NULL DEFAULT 'solo'");

        addColumnIfMissing($pdo, 'users', 'player_code', "`player_code` VARCHAR(6) DEFAULT NULL AFTER `id`");
        addColumnIfMissing($pdo, 'users', 'display_name', "`display_name` VARCHAR(100) DEFAULT NULL AFTER `full_name`");
        addColumnIfMissing($pdo, 'users', 'bio', "`bio` TEXT DEFAULT NULL AFTER `phone`");
        addColumnIfMissing($pdo, 'users', 'profile_photo', "`profile_photo` VARCHAR(255) DEFAULT NULL AFTER `bio`");
        addColumnIfMissing($pdo, 'users', 'show_rank_badges', "`show_rank_badges` TINYINT(1) NOT NULL DEFAULT 1 AFTER `profile_photo`");
        addColumnIfMissing($pdo, 'users', 'vip_until', "`vip_until` DATE DEFAULT NULL AFTER `show_rank_badges`");
        addColumnIfMissing($pdo, 'users', 'vip_discount_percent', "`vip_discount_percent` DECIMAL(5,2) NOT NULL DEFAULT 10.00 AFTER `vip_until`");
        $pdo->exec("UPDATE users SET player_code = LPAD(301900 + id, 6, '0') WHERE player_code IS NULL OR player_code = ''");
        $pdo->exec("UPDATE users SET display_name = full_name WHERE (display_name IS NULL OR display_name = '') AND full_name IS NOT NULL AND full_name <> ''");
        if (!indexExists($pdo, 'users', 'uniq_player_code')) execSafe($pdo, "ALTER TABLE `users` ADD UNIQUE KEY `uniq_player_code` (`player_code`)");

        addColumnIfMissing($pdo, 'lapangan_tutup', 'tipe_tutup', "`tipe_tutup` ENUM('manual','seharian') NOT NULL DEFAULT 'manual' AFTER `tanggal`");

        $pdo->exec("CREATE TABLE IF NOT EXISTS `match_participants` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `booking_id` INT(11) NOT NULL,
            `user_id` INT(11) NOT NULL,
            `team` ENUM('challenger','opponent') NOT NULL DEFAULT 'challenger',
            `status` ENUM('pending','accepted','rejected') NOT NULL DEFAULT 'pending',
            `is_captain` TINYINT(1) NOT NULL DEFAULT 0,
            `invited_by` INT(11) DEFAULT NULL,
            `responded_at` TIMESTAMP NULL DEFAULT NULL,
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uniq_booking_user` (`booking_id`,`user_id`),
            KEY `idx_match_participants_user` (`user_id`,`status`),
            KEY `idx_match_participants_booking` (`booking_id`,`team`,`status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

        $pdo->exec("CREATE TABLE IF NOT EXISTS `notifications` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `user_id` INT(11) NOT NULL,
            `title` VARCHAR(150) NOT NULL,
            `message` TEXT NOT NULL,
            `link` VARCHAR(255) DEFAULT NULL,
            `is_read` TINYINT(1) NOT NULL DEFAULT 0,
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `idx_notifications_user` (`user_id`,`is_read`,`created_at`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

        $pdo->exec("CREATE TABLE IF NOT EXISTS `password_resets` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `user_id` INT(11) NOT NULL,
            `email` VARCHAR(100) NOT NULL,
            `reset_code` VARCHAR(10) NOT NULL,
            `expires_at` DATETIME NOT NULL,
            `used` TINYINT(1) NOT NULL DEFAULT 0,
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `idx_password_resets_code` (`reset_code`,`used`),
            KEY `idx_password_resets_user` (`user_id`,`used`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

        $pdo->exec("CREATE TABLE IF NOT EXISTS `teams` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `team_code` VARCHAR(12) NOT NULL,
            `team_name` VARCHAR(100) NOT NULL,
            `captain_id` INT(11) NOT NULL,
            `jenis_olahraga` VARCHAR(50) DEFAULT NULL,
            `status` ENUM('pending','active','rejected','inactive') NOT NULL DEFAULT 'pending',
            `created_by_booking_id` INT(11) DEFAULT NULL,
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uniq_team_code` (`team_code`),
            KEY `idx_team_name` (`team_name`),
            KEY `idx_team_captain` (`captain_id`,`status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

        $pdo->exec("CREATE TABLE IF NOT EXISTS `team_members` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `team_id` INT(11) NOT NULL,
            `user_id` INT(11) NOT NULL,
            `status` ENUM('pending','accepted','rejected') NOT NULL DEFAULT 'pending',
            `is_captain` TINYINT(1) NOT NULL DEFAULT 0,
            `invited_by` INT(11) DEFAULT NULL,
            `responded_at` TIMESTAMP NULL DEFAULT NULL,
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uniq_team_member` (`team_id`,`user_id`),
            KEY `idx_team_member_user` (`user_id`,`status`),
            KEY `idx_team_member_team` (`team_id`,`status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

        $pdo->exec("CREATE TABLE IF NOT EXISTS `team_match_requests` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `booking_id` INT(11) NOT NULL,
            `requester_user_id` INT(11) NOT NULL,
            `requester_team_id` INT(11) NOT NULL,
            `opponent_team_id` INT(11) NOT NULL,
            `status` ENUM('pending','accepted','rejected','completed','cancelled') NOT NULL DEFAULT 'pending',
            `message` VARCHAR(255) DEFAULT NULL,
            `responded_by` INT(11) DEFAULT NULL,
            `responded_at` TIMESTAMP NULL DEFAULT NULL,
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `idx_team_match_booking` (`booking_id`,`status`),
            KEY `idx_team_match_opp` (`opponent_team_id`,`status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

        $pdo->exec("CREATE TABLE IF NOT EXISTS `chat_messages` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `sender_id` INT(11) NOT NULL,
            `receiver_id` INT(11) NOT NULL,
            `message` TEXT NOT NULL,
            `is_read` TINYINT(1) NOT NULL DEFAULT 0,
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `idx_chat_pair` (`sender_id`,`receiver_id`,`created_at`),
            KEY `idx_chat_receiver` (`receiver_id`,`is_read`,`created_at`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

        $pdo->exec("CREATE TABLE IF NOT EXISTS `vip_orders` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `user_id` INT(11) NOT NULL,
            `amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            `duration_days` INT(11) NOT NULL DEFAULT 30,
            `discount_percent` DECIMAL(5,2) NOT NULL DEFAULT 10.00,
            `payment_method` VARCHAR(50) DEFAULT NULL,
            `payment_channel` VARCHAR(50) DEFAULT NULL,
            `qr_code` TEXT DEFAULT NULL,
            `transaction_code` VARCHAR(50) NOT NULL,
            `status` ENUM('pending','success','failed','cancelled') NOT NULL DEFAULT 'pending',
            `payment_date` TIMESTAMP NULL DEFAULT NULL,
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uniq_vip_transaction` (`transaction_code`),
            KEY `idx_vip_user` (`user_id`,`status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");


        $pdo->exec("CREATE TABLE IF NOT EXISTS `products` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `seller_id` INT(11) NOT NULL,
            `product_name` VARCHAR(150) NOT NULL,
            `category` VARCHAR(80) DEFAULT NULL,
            `description` TEXT DEFAULT NULL,
            `price` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
            `stock` INT(11) NOT NULL DEFAULT 1,
            `photo` VARCHAR(255) DEFAULT NULL,
            `status` ENUM('active','inactive','sold_out') NOT NULL DEFAULT 'active',
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `idx_products_seller` (`seller_id`,`status`),
            KEY `idx_products_search` (`product_name`,`category`,`status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

        $pdo->exec("CREATE TABLE IF NOT EXISTS `product_reviews` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `product_id` INT(11) NOT NULL,
            `user_id` INT(11) NOT NULL,
            `rating` TINYINT(1) NOT NULL,
            `message` TEXT DEFAULT NULL,
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `idx_product_reviews_product` (`product_id`,`created_at`),
            KEY `idx_product_reviews_user` (`user_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

        $pdo->exec("CREATE TABLE IF NOT EXISTS `product_orders` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `product_id` INT(11) NOT NULL,
            `buyer_id` INT(11) NOT NULL,
            `seller_id` INT(11) NOT NULL,
            `quantity` INT(11) NOT NULL DEFAULT 1,
            `price` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
            `total_amount` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
            `platform_fee` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
            `seller_amount` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
            `payment_method` VARCHAR(50) DEFAULT NULL,
            `payment_channel` VARCHAR(50) DEFAULT NULL,
            `qr_code` TEXT DEFAULT NULL,
            `transaction_code` VARCHAR(50) NOT NULL,
            `status` ENUM('pending','success','failed','cancelled') NOT NULL DEFAULT 'pending',
            `payment_date` TIMESTAMP NULL DEFAULT NULL,
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uniq_product_order_code` (`transaction_code`),
            KEY `idx_product_orders_product` (`product_id`,`status`),
            KEY `idx_product_orders_buyer` (`buyer_id`,`status`),
            KEY `idx_product_orders_seller` (`seller_id`,`status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

        $pdo->exec("CREATE TABLE IF NOT EXISTS `lapangan_reviews` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `lapangan_id` INT(11) NOT NULL,
            `user_id` INT(11) NOT NULL,
            `booking_id` INT(11) DEFAULT NULL,
            `rating` TINYINT(1) NOT NULL,
            `message` TEXT DEFAULT NULL,
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `idx_lapangan_reviews_lapangan` (`lapangan_id`,`created_at`),
            KEY `idx_lapangan_reviews_user` (`user_id`),
            KEY `idx_lapangan_reviews_booking` (`booking_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");


        $pdo->exec("CREATE TABLE IF NOT EXISTS `admin_booking_hidden` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `admin_id` INT(11) NOT NULL,
            `booking_id` INT(11) NOT NULL,
            `hidden_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uniq_admin_booking_hidden` (`admin_id`,`booking_id`),
            KEY `idx_admin_booking_hidden_booking` (`booking_id`),
            KEY `idx_admin_booking_hidden_admin` (`admin_id`,`hidden_at`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

        if (tableExists($pdo, 'transactions')) {
            execSafe($pdo, "ALTER TABLE `transactions` MODIFY `status` ENUM('pending','success','failed','cancelled') DEFAULT 'pending'");
        }

        if (tableExists($pdo, 'match_results')) {
            if (!indexExists($pdo, 'match_results', 'uniq_booking_user_result')) execSafe($pdo, "ALTER TABLE `match_results` ADD UNIQUE KEY `uniq_booking_user_result` (`booking_id`,`user_id`)");
            if (indexExists($pdo, 'match_results', 'booking_id')) execSafe($pdo, "ALTER TABLE `match_results` DROP INDEX `booking_id`");
        }
    } catch (Exception $e) {
        // Jangan matikan aplikasi jika user database tidak punya izin ALTER.
    }
}

ensureAppUpgradeSchema($pdo);

function getNextPlayerCode($pdo) {
    $max = (int) $pdo->query("SELECT COALESCE(MAX(CAST(player_code AS UNSIGNED)), 301900) FROM users WHERE player_code REGEXP '^[0-9]{6}$'")->fetchColumn();
    $next = max(301901, $max + 1);
    while (true) {
        $code = sprintf('%06d', $next);
        $stmt = $pdo->prepare("SELECT id FROM users WHERE player_code = ? LIMIT 1");
        $stmt->execute([$code]);
        if (!$stmt->fetch()) return $code;
        $next++;
    }
}

function getNextTeamCode($pdo) {
    $max = 801000;
    if (tableExists($pdo, 'teams')) {
        $q = $pdo->query("SELECT team_code FROM teams WHERE team_code REGEXP '^TM[0-9]{6}$'");
        foreach ($q->fetchAll(PDO::FETCH_COLUMN) as $code) {
            $num = (int)substr($code, 2);
            if ($num > $max) $max = $num;
        }
    }
    $next = $max + 1;
    while (true) {
        $code = 'TM' . sprintf('%06d', $next);
        $stmt = $pdo->prepare("SELECT id FROM teams WHERE team_code = ? LIMIT 1");
        $stmt->execute([$code]);
        if (!$stmt->fetch()) return $code;
        $next++;
    }
}

function createNotification($pdo, $user_id, $title, $message, $link = null) {
    if (!$user_id) return;
    try {
        $stmt = $pdo->prepare("INSERT INTO notifications (user_id, title, message, link) VALUES (?, ?, ?, ?)");
        $stmt->execute([(int)$user_id, $title, $message, $link]);
    } catch (Exception $e) {}
}

function unreadNotificationCount($pdo, $user_id = null) {
    $user_id = $user_id ?: getUserId();
    if (!$user_id || !tableExists($pdo, 'notifications')) return 0;
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
    $stmt->execute([$user_id]);
    return (int)$stmt->fetchColumn();
}

function pendingInvitationCount($pdo, $user_id = null) {
    $user_id = $user_id ?: getUserId();
    if (!$user_id) return 0;
    $total = 0;
    if (tableExists($pdo, 'match_participants')) {
        // Solo invite lama menyimpan lawan sebagai is_captain=1, jadi jangan filter is_captain.
        // Yang penting undangan yang muncul adalah pemain sisi opponent yang belum menerima/menolak.
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM match_participants mp JOIN bookings b ON mp.booking_id = b.id WHERE mp.user_id = ? AND mp.status = 'pending' AND mp.team = 'opponent' AND b.match_type = 'solo'");
        $stmt->execute([(int)$user_id]);
        $total += (int)$stmt->fetchColumn();
    }
    if (tableExists($pdo, 'team_members')) {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM team_members WHERE user_id = ? AND status = 'pending' AND is_captain = 0");
        $stmt->execute([(int)$user_id]);
        $total += (int)$stmt->fetchColumn();
    }
    if (tableExists($pdo, 'team_match_requests')) {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM team_match_requests tr JOIN teams t ON tr.opponent_team_id = t.id WHERE t.captain_id = ? AND tr.status = 'pending'");
        $stmt->execute([(int)$user_id]);
        $total += (int)$stmt->fetchColumn();
    }
    return $total;
}

function syncBookingFromTransactionStatus($pdo, $transaction_id, $status) {
    $allowed = ['pending','success','failed','cancelled'];
    if (!in_array($status, $allowed, true)) return false;

    $stmt = $pdo->prepare("SELECT t.*, b.id AS booking_id, b.user_id AS booking_user_id FROM transactions t JOIN bookings b ON t.booking_id = b.id WHERE t.id = ?");
    $stmt->execute([(int)$transaction_id]);
    $row = $stmt->fetch();
    if (!$row) return false;

    if ($status === 'success') {
        $pdo->prepare("UPDATE transactions SET status = 'success', payment_date = COALESCE(payment_date, NOW()) WHERE id = ?")->execute([(int)$transaction_id]);
        $pdo->prepare("UPDATE bookings SET status = 'confirmed', payment_status = 'paid' WHERE id = ?")->execute([(int)$row['booking_id']]);
    } elseif ($status === 'pending') {
        $pdo->prepare("UPDATE transactions SET status = 'pending', payment_date = NULL WHERE id = ?")->execute([(int)$transaction_id]);
        $pdo->prepare("UPDATE bookings SET status = 'pending', payment_status = 'unpaid' WHERE id = ? AND status <> 'cancelled'")->execute([(int)$row['booking_id']]);
    } elseif ($status === 'cancelled') {
        $pdo->prepare("UPDATE transactions SET status = 'cancelled', payment_date = NULL WHERE id = ?")->execute([(int)$transaction_id]);
        $pdo->prepare("UPDATE bookings SET status = 'cancelled', payment_status = 'unpaid', match_status = 'cancelled' WHERE id = ?")->execute([(int)$row['booking_id']]);
        createNotification($pdo, (int)$row['booking_user_id'], 'Transaksi dibatalkan', 'Transaksi booking kamu dibatalkan admin. Jadwal tersebut sudah dilepas kembali.', 'riwayat.php');
    } else {
        $pdo->prepare("UPDATE transactions SET status = 'failed', payment_date = NULL WHERE id = ?")->execute([(int)$transaction_id]);
        $pdo->prepare("UPDATE bookings SET payment_status = 'unpaid' WHERE id = ? AND status <> 'cancelled'")->execute([(int)$row['booking_id']]);
    }
    return true;
}

function syncTransactionFromBookingStatus($pdo, $booking_id, $status) {
    $allowed = ['pending','paid','confirmed','cancelled'];
    if (!in_array($status, $allowed, true)) return false;

    if ($status === 'cancelled') {
        $pdo->prepare("UPDATE bookings SET status = 'cancelled', payment_status = 'unpaid', match_status = 'cancelled' WHERE id = ?")->execute([(int)$booking_id]);
        $pdo->prepare("UPDATE transactions SET status = 'cancelled', payment_date = NULL WHERE booking_id = ? AND status <> 'cancelled'")->execute([(int)$booking_id]);
    } elseif (in_array($status, ['paid','confirmed'], true)) {
        $pdo->prepare("UPDATE bookings SET status = ?, payment_status = 'paid' WHERE id = ?")->execute([$status, (int)$booking_id]);
        $pdo->prepare("UPDATE transactions SET status = 'success', payment_date = COALESCE(payment_date, NOW()) WHERE booking_id = ?")->execute([(int)$booking_id]);
    } else {
        $pdo->prepare("UPDATE bookings SET status = 'pending', payment_status = 'unpaid' WHERE id = ?")->execute([(int)$booking_id]);
        $pdo->prepare("UPDATE transactions SET status = 'pending', payment_date = NULL WHERE booking_id = ?")->execute([(int)$booking_id]);
    }
    return true;
}

function userHasActiveVip($pdo, $user_id = null) {
    $user_id = $user_id ?: getUserId();
    if (!$user_id || !columnExists($pdo, 'users', 'vip_until')) return false;
    $stmt = $pdo->prepare("SELECT vip_until FROM users WHERE id = ?");
    $stmt->execute([(int)$user_id]);
    $until = $stmt->fetchColumn();
    return $until && $until >= date('Y-m-d');
}

function getVipDiscountPercent($pdo, $user_id = null) {
    $user_id = $user_id ?: getUserId();
    if (!userHasActiveVip($pdo, $user_id)) return 0.0;
    $stmt = $pdo->prepare("SELECT vip_discount_percent FROM users WHERE id = ?");
    $stmt->execute([(int)$user_id]);
    return max(0, (float)$stmt->fetchColumn());
}

function findPlayerByKeyword($pdo, $keyword, $excludeIds = []) {
    $keyword = trim((string)$keyword);
    if ($keyword === '') return null;
    $excludeIds = array_map('intval', $excludeIds);
    $excludeSql = '';
    $params = [];
    if ($excludeIds) {
        $excludeSql = " AND id NOT IN (" . implode(',', array_fill(0, count($excludeIds), '?')) . ")";
        $params = array_merge($params, $excludeIds);
    }
    $exactSql = "SELECT id, player_code, username, email, full_name, display_name FROM users
                 WHERE role = 'user' AND (player_code = ? OR username = ? OR email = ?) $excludeSql LIMIT 1";
    $stmt = $pdo->prepare($exactSql);
    $stmt->execute(array_merge([$keyword, $keyword, $keyword], $params));
    $row = $stmt->fetch();
    if ($row) return $row;
    $like = '%' . $keyword . '%';
    $likeSql = "SELECT id, player_code, username, email, full_name, display_name FROM users
                WHERE role = 'user' AND (username LIKE ? OR full_name LIKE ? OR display_name LIKE ? OR player_code LIKE ?) $excludeSql
                ORDER BY username ASC LIMIT 1";
    $stmt = $pdo->prepare($likeSql);
    $stmt->execute(array_merge([$like, $like, $like, $like], $params));
    return $stmt->fetch() ?: null;
}

function parsePlayerList($pdo, $raw, $excludeIds = []) {
    $tokens = preg_split('/[\r\n,;]+/', (string)$raw);
    $players = [];
    $missing = [];
    $seen = array_fill_keys(array_map('intval', $excludeIds), true);
    foreach ($tokens as $token) {
        $token = trim($token);
        if ($token === '') continue;
        $player = findPlayerByKeyword($pdo, $token, array_keys($seen));
        if ($player) {
            $pid = (int)$player['id'];
            if (!isset($seen[$pid])) {
                $players[] = $player;
                $seen[$pid] = true;
            }
        } else {
            $missing[] = $token;
        }
    }
    return ['players' => $players, 'missing' => $missing];
}

function getPlayerPublicName($row) {
    return $row['display_name'] ?: ($row['full_name'] ?: $row['username']);
}

function findTeamByKeyword($pdo, $keyword, $excludeTeamIds = []) {
    $keyword = trim((string)$keyword);
    if ($keyword === '') return null;
    $excludeTeamIds = array_map('intval', $excludeTeamIds);
    $excludeSql = '';
    $params = [];
    if ($excludeTeamIds) {
        $excludeSql = " AND t.id NOT IN (" . implode(',', array_fill(0, count($excludeTeamIds), '?')) . ")";
        $params = array_merge($params, $excludeTeamIds);
    }
    $stmt = $pdo->prepare("SELECT t.*, COALESCE(NULLIF(u.display_name,''), NULLIF(u.full_name,''), u.username) AS captain_name, u.username AS captain_username
                           FROM teams t JOIN users u ON t.captain_id = u.id
                           WHERE t.status = 'active' AND (t.team_code = ? OR t.team_name = ?) $excludeSql LIMIT 1");
    $stmt->execute(array_merge([$keyword, $keyword], $params));
    $team = $stmt->fetch();
    if ($team) return $team;
    $like = '%' . $keyword . '%';
    $stmt = $pdo->prepare("SELECT t.*, COALESCE(NULLIF(u.display_name,''), NULLIF(u.full_name,''), u.username) AS captain_name, u.username AS captain_username
                           FROM teams t JOIN users u ON t.captain_id = u.id
                           WHERE t.status = 'active' AND (t.team_code LIKE ? OR t.team_name LIKE ?) $excludeSql
                           ORDER BY t.created_at DESC LIMIT 1");
    $stmt->execute(array_merge([$like, $like], $params));
    return $stmt->fetch() ?: null;
}

function getTeamMembers($pdo, $team_id, $onlyAccepted = false) {
    $sql = "SELECT tm.*, u.username, u.player_code, COALESCE(NULLIF(u.display_name,''), NULLIF(u.full_name,''), u.username) AS player_name
            FROM team_members tm JOIN users u ON tm.user_id = u.id WHERE tm.team_id = ?";
    if ($onlyAccepted) $sql .= " AND tm.status = 'accepted'";
    $sql .= " ORDER BY tm.is_captain DESC, u.username ASC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([(int)$team_id]);
    return $stmt->fetchAll();
}

function evaluateTeamApproval($pdo, $team_id) {
    $stmt = $pdo->prepare("SELECT t.*, COALESCE(NULLIF(u.display_name,''), NULLIF(u.full_name,''), u.username) AS captain_name FROM teams t JOIN users u ON t.captain_id = u.id WHERE t.id = ?");
    $stmt->execute([(int)$team_id]);
    $team = $stmt->fetch();
    if (!$team) return;
    $members = getTeamMembers($pdo, $team_id, false);
    foreach ($members as $m) {
        if ($m['status'] === 'rejected') {
            $pdo->prepare("UPDATE teams SET status = 'rejected' WHERE id = ?")->execute([(int)$team_id]);
            createNotification($pdo, $team['captain_id'], 'Pembuatan team ditolak', $m['player_name'] . ' menolak bergabung ke team ' . $team['team_name'] . '. Buat ulang team dengan pemain lain.', 'team-tanding.php?booking_id=' . (int)$team['created_by_booking_id']);
            return;
        }
    }
    foreach ($members as $m) {
        if ($m['status'] !== 'accepted') return;
    }
    $pdo->prepare("UPDATE teams SET status = 'active' WHERE id = ?")->execute([(int)$team_id]);
    createNotification($pdo, $team['captain_id'], 'Team aktif', 'Team ' . $team['team_name'] . ' sudah aktif. ID Team: ' . $team['team_code'] . '.', 'team-tanding.php?booking_id=' . (int)$team['created_by_booking_id']);
    if (!empty($team['created_by_booking_id'])) {
        $pdo->prepare("UPDATE bookings SET match_status = 'team_ready' WHERE id = ? AND match_status IN ('team_setup','rejected')")->execute([(int)$team['created_by_booking_id']]);
    }
}

function populateMatchParticipantsFromTeams($pdo, $booking_id, $team1_id, $team2_id, $invitedBy) {
    $pdo->prepare("DELETE FROM match_participants WHERE booking_id = ?")->execute([(int)$booking_id]);
    $insert = $pdo->prepare("INSERT INTO match_participants (booking_id, user_id, team, status, is_captain, invited_by, responded_at) VALUES (?, ?, ?, 'accepted', ?, ?, NOW())");
    foreach (getTeamMembers($pdo, $team1_id, true) as $m) {
        $insert->execute([(int)$booking_id, (int)$m['user_id'], 'challenger', (int)$m['is_captain'], (int)$invitedBy]);
    }
    foreach (getTeamMembers($pdo, $team2_id, true) as $m) {
        $insert->execute([(int)$booking_id, (int)$m['user_id'], 'opponent', (int)$m['is_captain'], (int)$invitedBy]);
    }
}

function evaluateMatchApproval($pdo, $booking_id) {
    $stmt = $pdo->prepare("SELECT b.*, l.nama_lapangan, l.admin_id, u.username AS owner_username, COALESCE(NULLIF(u.display_name,''), NULLIF(u.full_name,''), u.username) AS owner_name
                           FROM bookings b JOIN lapangan l ON b.lapangan_id = l.id JOIN users u ON b.user_id = u.id WHERE b.id = ?");
    $stmt->execute([(int)$booking_id]);
    $booking = $stmt->fetch();
    if (!$booking || (int)($booking['match_enabled'] ?? 0) !== 1) return;
    $stmt = $pdo->prepare("SELECT mp.*, COALESCE(NULLIF(u.display_name,''), NULLIF(u.full_name,''), u.username) AS player_name FROM match_participants mp JOIN users u ON mp.user_id = u.id WHERE mp.booking_id = ?");
    $stmt->execute([(int)$booking_id]);
    $participants = $stmt->fetchAll();
    if (!$participants) return;
    foreach ($participants as $p) {
        if ($p['status'] === 'rejected') {
            $reason = $p['player_name'] . ' menolak permintaan tanding. Silakan ajukan ulang dan masukkan pemain lain.';
            $pdo->prepare("UPDATE bookings SET match_status = 'rejected', match_rejected_reason = ? WHERE id = ?")->execute([$reason, (int)$booking_id]);
            createNotification($pdo, $booking['user_id'], 'Permintaan tanding ditolak', $reason, 'riwayat.php');
            return;
        }
    }
    foreach ($participants as $p) {
        if ($p['status'] !== 'accepted') {
            $pdo->prepare("UPDATE bookings SET match_status = 'pending_approval' WHERE id = ?")->execute([(int)$booking_id]);
            return;
        }
    }
    $pdo->prepare("UPDATE bookings SET match_status = 'waiting_score', match_rejected_reason = NULL WHERE id = ?")->execute([(int)$booking_id]);
    createNotification($pdo, $booking['admin_id'], 'Mode tanding siap dicatat', 'Semua pemain sudah menyetujui pertandingan di ' . $booking['nama_lapangan'] . '. Silakan input skor akhir.', 'admin/bookings.php');
    createNotification($pdo, $booking['user_id'], 'Mode tanding disetujui', 'Semua pemain sudah setuju. Pertandingan siap dimainkan dan admin akan input skor akhir.', 'riwayat.php');
}

function generateQrSvg($payload, $size = 280) {
    $payload = (string)$payload;
    $cells = 29;
    $cell = $size / $cells;
    $hash = hash('sha256', $payload);
    $bits = '';
    for ($i = 0; $i < strlen($hash); $i++) $bits .= str_pad(base_convert($hash[$i], 16, 2), 4, '0', STR_PAD_LEFT);
    $svg = '<svg xmlns="http://www.w3.org/2000/svg" width="'.$size.'" height="'.$size.'" viewBox="0 0 '.$size.' '.$size.'" role="img" aria-label="QR Code">';
    $svg .= '<rect width="100%" height="100%" fill="#fff"/>';
    $finder = function($x,$y) use (&$svg,$cell) {
        $svg .= '<rect x="'.($x*$cell).'" y="'.($y*$cell).'" width="'.(7*$cell).'" height="'.(7*$cell).'" fill="#000"/>';
        $svg .= '<rect x="'.(($x+1)*$cell).'" y="'.(($y+1)*$cell).'" width="'.(5*$cell).'" height="'.(5*$cell).'" fill="#fff"/>';
        $svg .= '<rect x="'.(($x+2)*$cell).'" y="'.(($y+2)*$cell).'" width="'.(3*$cell).'" height="'.(3*$cell).'" fill="#000"/>';
    };
    $finder(1,1); $finder(21,1); $finder(1,21);
    $idx = 0;
    for ($y=0; $y<$cells; $y++) {
        for ($x=0; $x<$cells; $x++) {
            $inFinder = (($x>=1&&$x<=7&&$y>=1&&$y<=7)||($x>=21&&$x<=27&&$y>=1&&$y<=7)||($x>=1&&$x<=7&&$y>=21&&$y<=27));
            if ($inFinder) continue;
            $bit = $bits[$idx % strlen($bits)] ?? '0';
            $mix = (($x*$y + $idx + ord($payload[$idx % max(1, strlen($payload))])) % 5) === 0;
            if ($bit === '1' || $mix) {
                $svg .= '<rect x="'.($x*$cell).'" y="'.($y*$cell).'" width="'.ceil($cell).'" height="'.ceil($cell).'" fill="#000"/>';
            }
            $idx++;
        }
    }
    $svg .= '</svg>';
    return $svg;
}

function starRatingHtml($rating) {
    $rating = (float)$rating;
    $out = '<span class="star-rating">';
    for ($i = 1; $i <= 5; $i++) {
        $out .= $i <= round($rating) ? '<i class="fa-solid fa-star"></i>' : '<i class="fa-regular fa-star"></i>';
    }
    $out .= '</span>';
    return $out;
}

function uploadImageFile($fieldName, $targetDir, $prefix = 'img') {
    if (empty($_FILES[$fieldName]['name']) || !isset($_FILES[$fieldName]['tmp_name'])) return null;
    if (!is_uploaded_file($_FILES[$fieldName]['tmp_name'])) return null;
    $allowed = ['jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp','gif'=>'image/gif'];
    $ext = strtolower(pathinfo($_FILES[$fieldName]['name'], PATHINFO_EXTENSION));
    if (!isset($allowed[$ext])) throw new Exception('Format foto harus JPG, PNG, WEBP, atau GIF');
    if (($_FILES[$fieldName]['size'] ?? 0) > 3 * 1024 * 1024) throw new Exception('Ukuran foto maksimal 3MB');
    if (!is_dir($targetDir)) mkdir($targetDir, 0775, true);
    $filename = $prefix . '_' . time() . '_' . bin2hex(random_bytes(6)) . '.' . $ext;
    $dest = rtrim($targetDir, '/\\') . DIRECTORY_SEPARATOR . $filename;
    if (!move_uploaded_file($_FILES[$fieldName]['tmp_name'], $dest)) throw new Exception('Gagal upload foto');
    return $filename;
}


function getPlatformFeePercent() {
    return 5.0; // keuntungan super admin dari booking dan penjualan barang
}

function calculatePlatformFee($amount, $percent = null) {
    $percent = $percent === null ? getPlatformFeePercent() : (float)$percent;
    return (int) floor(max(0, (float)$amount) * ($percent / 100));
}

function canSellProduct($pdo, $user_id = null, $role = null) {
    $user_id = $user_id ?: getUserId();
    $role = $role ?: getUserRole();
    if (!$user_id || !$role) return false;
    if ($role === 'admin' || $role === 'super_admin') return true;
    return userHasActiveVip($pdo, $user_id);
}

function productOrderStatusLabel($status) {
    $map = ['pending'=>'Pending','success'=>'Sukses','failed'=>'Gagal','cancelled'=>'Cancel'];
    return $map[$status] ?? $status;
}


function renderNavbar($base = '', $forcedRole = null) {
    $base = (string)$base;
    $role = $forcedRole ?: getUserRole();
    $profileId = (int) getUserId();
    $dashboardUrl = $base . 'login.php';

    if ($role === 'admin') {
        $dashboardUrl = $base . 'admin/dashboard.php';
        $menus = [
            ['HOME', $base . 'index.php'],
            ['LAPANGAN', $base . 'booking.php'],
            ['LEADERBOARD', $base . 'leaderboard.php'],
            ['PEMAIN', $base . 'players.php'],
            ['MARKET', $base . 'marketplace.php'],
            ['RIWAYAT', $base . 'riwayat.php'],
            ['PROFIL', $base . 'profile.php?id=' . $profileId],
            ['DASHBOARD', $dashboardUrl],
        ];
    } elseif ($role === 'super_admin') {
        $dashboardUrl = $base . 'superadmin/dashboard.php';
        $menus = [
            ['HOME', $base . 'index.php'],
            ['LAPANGAN', $base . 'booking.php'],
            ['LEADERBOARD', $base . 'leaderboard.php'],
            ['PEMAIN', $base . 'players.php'],
            ['MARKET', $base . 'marketplace.php'],
            ['RIWAYAT', $base . 'riwayat.php'],
            ['PROFIL', $base . 'profile.php?id=' . $profileId],
            ['DASHBOARD', $dashboardUrl],
        ];
    } elseif ($role === 'user') {
        $dashboardUrl = $base . 'user/dashboard.php';
        $menus = [
            ['HOME', $base . 'index.php'],
            ['BOOKING', $base . 'booking.php'],
            ['RIWAYAT', $base . 'riwayat.php'],
            ['LEADERBOARD', $base . 'leaderboard.php'],
            ['PEMAIN', $base . 'players.php'],
            ['PROFIL', $base . 'profile.php?id=' . $profileId],
            ['DASHBOARD', $dashboardUrl],
        ];
    } else {
        $menus = [
            ['HOME', $base . 'index.php'],
            ['BOOKING', $base . 'booking.php'],
            ['LEADERBOARD', $base . 'leaderboard.php'],
            ['PEMAIN', $base . 'players.php'],
            ['MARKET', $base . 'marketplace.php'],
        ];
    }

    $logoSrc = $base . 'assets/img/lapangankita-navbar-logo.png';
    $baseJs = json_encode($base, JSON_UNESCAPED_SLASHES);
    echo '<style>
        nav.lk-navbar{width:100%;height:85px;position:fixed;top:72px;left:0;z-index:2500;background:#f5f5f5;display:flex;justify-content:space-between;align-items:center;padding:0 4%;border-bottom:5px solid #00ffb3;gap:18px;box-shadow:0 8px 28px rgba(0,0,0,.10)}
        .lk-navbar .lk-logo{display:flex;align-items:center;justify-content:center;text-decoration:none;flex:0 0 300px;height:68px;overflow:hidden;border-radius:16px;background:#061926;box-shadow:0 8px 22px rgba(0,0,0,.18);padding:0 10px}
        .lk-navbar .lk-logo img{width:100%;height:100%;object-fit:contain;display:block;transform:none}
        .lk-navbar ul{display:flex;align-items:center;justify-content:center;gap:24px;list-style:none;margin:0;padding:0;flex:1;min-width:0;white-space:nowrap}
        .lk-navbar ul li a{text-decoration:none;color:#07111f;font-family:"Teko",sans-serif;font-size:22px;font-weight:700;letter-spacing:.3px;transition:.25s;position:relative}
        .lk-navbar ul li a:hover{color:#00a878}
        .lk-navbar ul li a:after{content:"";position:absolute;left:0;bottom:-8px;width:0;height:3px;background:#00ffb3;border-radius:99px;transition:.25s}
        .lk-navbar ul li a:hover:after{width:100%}
        .lk-navbar .search-icon{color:#07111f;font-size:27px;cursor:pointer;min-width:40px;text-align:center;transition:.25s}
        .lk-navbar .search-icon:hover{color:#00a878;transform:scale(1.08)}
        .lk-search-backdrop{position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:4990;display:none;backdrop-filter:blur(5px)}
        .lk-search-panel{position:fixed;top:50%;left:50%;transform:translate(-50%,-45%) scale(.96);width:min(720px,92vw);max-height:82vh;overflow:auto;background:linear-gradient(135deg,#07111f,#0d2238);border:1px solid rgba(0,255,179,.28);box-shadow:0 24px 70px rgba(0,0,0,.42);border-radius:28px;padding:26px;z-index:5000;display:none;opacity:0;transition:.25s;color:#fff}
        .lk-search-panel.active{display:block;opacity:1;transform:translate(-50%,-50%) scale(1)}
        .lk-search-backdrop.active{display:block}
        .lk-search-head{display:flex;justify-content:space-between;align-items:center;gap:14px;margin-bottom:16px}
        .lk-search-head h3{font-family:"Anton",sans-serif;font-size:26px;color:#00ffb3;margin:0;letter-spacing:.5px}
        .lk-search-close{border:0;background:rgba(255,255,255,.08);color:#fff;width:38px;height:38px;border-radius:50%;cursor:pointer;font-size:18px}
        .lk-search-row{display:grid;grid-template-columns:1fr auto;gap:10px;margin-bottom:14px}
        .lk-search-row input{width:100%;padding:15px 18px;border-radius:18px;border:1px solid rgba(255,255,255,.15);background:rgba(255,255,255,.08);color:#fff;font-family:Poppins,sans-serif;outline:none}
        .lk-search-row input:focus{border-color:#00ffb3;box-shadow:0 0 0 4px rgba(0,255,179,.10)}
        .lk-search-row button{padding:0 22px;border:0;border-radius:18px;background:linear-gradient(135deg,#00ffb3,#00c3ff);color:#07111f;font-weight:800;cursor:pointer}
        .lk-search-hint{color:rgba(255,255,255,.70);font-size:13px;margin-bottom:12px}
        .lk-search-results{display:grid;gap:10px}
        .lk-result-item{display:grid;grid-template-columns:72px 1fr auto;gap:14px;align-items:center;padding:12px;border-radius:18px;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.10);text-decoration:none;color:#fff;transition:.25s}
        .lk-result-item:hover{border-color:#00ffb3;transform:translateY(-2px);background:rgba(0,255,179,.08)}
        .lk-result-img{width:72px;height:58px;border-radius:14px;overflow:hidden;background:rgba(0,255,179,.12);display:flex;align-items:center;justify-content:center;color:#00ffb3;font-size:22px}
        .lk-result-img img{width:100%;height:100%;object-fit:cover}
        .lk-result-title{font-weight:800;font-size:15px;margin-bottom:3px}
        .lk-result-meta{font-size:12px;color:rgba(255,255,255,.68);line-height:1.45}
        .lk-result-price{font-weight:800;color:#00ffb3;text-align:right;white-space:nowrap;font-size:13px}
        .lk-search-empty{padding:18px;border-radius:18px;background:rgba(255,255,255,.06);color:rgba(255,255,255,.75);text-align:center}
        @media(max-width:1150px){nav.lk-navbar{padding:0 3%;gap:10px}.lk-navbar .lk-logo{flex-basis:235px;height:62px}.lk-navbar ul{gap:13px}.lk-navbar ul li a{font-size:18px}}
        @media(max-width:860px){nav.lk-navbar{padding:0 5%}.lk-navbar ul{display:none}.lk-navbar .lk-logo{flex-basis:260px;height:62px}.lk-result-item{grid-template-columns:58px 1fr}.lk-result-price{grid-column:2;text-align:left}.lk-result-img{width:58px;height:52px}.lk-search-row{grid-template-columns:1fr}}
    </style>';
    echo '<nav class="lk-navbar">';
    echo '<a class="lk-logo" href="' . e($base . 'index.php') . '"><img src="' . e($logoSrc) . '" alt="LapanganKita"></a>';
    echo '<ul>';
    foreach ($menus as $menu) {
        echo '<li><a href="' . e($menu[1]) . '">' . e($menu[0]) . '</a></li>';
    }
    echo '</ul>';
    echo '<div class="search-icon lk-open-search" title="Cari lapangan"><i class="fa-solid fa-magnifying-glass"></i></div>';
    echo '</nav>';
    echo '<div class="lk-search-backdrop" id="lkSearchBackdrop"></div>
    <div class="lk-search-panel" id="lkSearchPanel">
        <div class="lk-search-head">
            <h3><i class="fa-solid fa-magnifying-glass"></i> Cari Lapangan</h3>
            <button type="button" class="lk-search-close" id="lkSearchClose"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <div class="lk-search-row">
            <input type="text" id="lkSearchInput" placeholder="Ketik nama lapangan, jenis olahraga, wilayah, atau alamat...">
            <button type="button" id="lkSearchGo">Cari</button>
        </div>
        <div class="lk-search-hint">Pencarian cerdas bisa mencari nama lapangan, futsal/badminton/tennis, alamat, wilayah, dan kabupaten.</div>
        <div class="lk-search-results" id="lkSearchResults"><div class="lk-search-empty">Klik ikon pencarian, lalu ketik nama lapangan yang ingin dicari.</div></div>
    </div>';
    echo '<script>
    (function(){
        const base = ' . $baseJs . ';
        const panel = document.getElementById("lkSearchPanel");
        const backdrop = document.getElementById("lkSearchBackdrop");
        const closeBtn = document.getElementById("lkSearchClose");
        const input = document.getElementById("lkSearchInput");
        const goBtn = document.getElementById("lkSearchGo");
        const resultBox = document.getElementById("lkSearchResults");
        let timer = null;
        function openSearch(){ panel.classList.add("active"); backdrop.classList.add("active"); setTimeout(()=>input.focus(),80); }
        function closeSearch(){ panel.classList.remove("active"); backdrop.classList.remove("active"); }
        document.querySelectorAll(".lk-open-search").forEach(btn => btn.addEventListener("click", openSearch));
        closeBtn.addEventListener("click", closeSearch);
        backdrop.addEventListener("click", closeSearch);
        document.addEventListener("keydown", function(e){ if(e.key === "Escape") closeSearch(); });
        function rupiah(value){ return "Rp " + Number(value || 0).toLocaleString("id-ID") + " / jam"; }
        function escapeHtml(text){ return String(text || "").replace(/[&<>\x22\x27]/g, function(m){ const map = {"&":"&amp;","<":"&lt;",">":"&gt;"}; map[String.fromCharCode(34)]="&quot;"; map[String.fromCharCode(39)]="&#039;"; return map[m]; }); }
        function render(rows, q){
            if(!q){ resultBox.innerHTML = "<div class=\"lk-search-empty\">Ketik minimal 2 huruf untuk mencari lapangan.</div>"; return; }
            if(!rows || rows.length === 0){ resultBox.innerHTML = "<div class=\"lk-search-empty\">Lapangan tidak ditemukan. Coba kata lain seperti jenis olahraga atau wilayah.</div>"; return; }
            resultBox.innerHTML = rows.map(function(r){
                const img = r.foto ? `<img src="${base}assets/uploads/${escapeHtml(r.foto)}" alt="${escapeHtml(r.nama_lapangan)}">` : `<i class="fa-solid fa-futbol"></i>`;
                return `<a class="lk-result-item" href="${base}detail-lapangan.php?id=${encodeURIComponent(r.id)}">
                    <div class="lk-result-img">${img}</div>
                    <div><div class="lk-result-title">${escapeHtml(r.nama_lapangan)}</div><div class="lk-result-meta">${escapeHtml(r.jenis_olahraga)} • ${escapeHtml(r.alamat || r.wilayah || r.kabupaten || "Alamat belum diisi")}</div></div>
                    <div class="lk-result-price">${rupiah(r.harga_per_jam)}</div>
                </a>`;
            }).join("");
        }
        function doSearch(){
            const q = input.value.trim();
            if(q.length < 2){ render([], q); return; }
            resultBox.innerHTML = "<div class=\"lk-search-empty\">Mencari lapangan...</div>";
            fetch(base + "search-lapangan.php?q=" + encodeURIComponent(q))
                .then(res => res.json())
                .then(rows => render(rows, q))
                .catch(() => { resultBox.innerHTML = "<div class=\"lk-search-empty\">Pencarian gagal. Cek koneksi atau file search-lapangan.php.</div>"; });
        }
        input.addEventListener("input", function(){ clearTimeout(timer); timer = setTimeout(doSearch, 280); });
        input.addEventListener("keydown", function(e){ if(e.key === "Enter"){ e.preventDefault(); const q=input.value.trim(); if(q) window.location.href = base + "booking.php?q=" + encodeURIComponent(q); }});
        goBtn.addEventListener("click", function(){ const q=input.value.trim(); if(q) window.location.href = base + "booking.php?q=" + encodeURIComponent(q); });
    })();
    </script>';
}

?>
