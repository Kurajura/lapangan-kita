<?php
include 'config/database.php';

$jenis_list = ['futsal','badminton','basket','voli','football','tennis','mini soccer','lainnya'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $full_name = trim($_POST['full_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    $nama_lapangan = trim($_POST['nama_lapangan'] ?? '');
    $jenis_olahraga = trim($_POST['jenis_olahraga'] ?? '');
    $deskripsi = trim($_POST['deskripsi'] ?? '');
    $harga_per_jam = (float)($_POST['harga_per_jam'] ?? 0);
    $jumlah_lapangan = max(1, (int)($_POST['jumlah_lapangan'] ?? 1));
    $alamat = trim($_POST['alamat'] ?? '');
    $wilayah = trim($_POST['wilayah'] ?? '');
    $kabupaten = trim($_POST['kabupaten'] ?? '');

    if ($username === '' || $email === '' || $password === '' || $nama_lapangan === '' || $jenis_olahraga === '' || $harga_per_jam <= 0) {
        header('Location: daftar-admin.php?error=' . urlencode('Data akun dan data lapangan wajib dilengkapi'));
        exit();
    }
    if ($password !== $confirm_password) {
        header('Location: daftar-admin.php?error=' . urlencode('Password tidak cocok'));
        exit();
    }
    if (strlen($password) < 6) {
        header('Location: daftar-admin.php?error=' . urlencode('Password minimal 6 karakter'));
        exit();
    }

    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
    $stmt->execute([$username, $email]);
    if ($stmt->fetch()) {
        header('Location: daftar-admin.php?error=' . urlencode('Username atau email sudah terdaftar'));
        exit();
    }

    $foto = null;
    if (!empty($_FILES['foto']['name'])) {
        $target_dir = 'assets/uploads/';
        if (!is_dir($target_dir)) mkdir($target_dir, 0777, true);
        $ext = strtolower(pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg','jpeg','png','webp'];
        if (!in_array($ext, $allowed, true)) {
            header('Location: daftar-admin.php?error=' . urlencode('Foto lapangan harus JPG, PNG, atau WEBP'));
            exit();
        }
        if ((int)$_FILES['foto']['size'] > 3 * 1024 * 1024) {
            header('Location: daftar-admin.php?error=' . urlencode('Ukuran foto maksimal 3MB'));
            exit();
        }
        $foto = time() . '_' . bin2hex(random_bytes(8)) . '.' . $ext;
        move_uploaded_file($_FILES['foto']['tmp_name'], $target_dir . $foto);
    }

    try {
        $pdo->beginTransaction();
        $player_code = getNextPlayerCode($pdo);
        $display_name = $full_name !== '' ? $full_name : $username;
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (player_code, username, email, password, full_name, display_name, phone, role) VALUES (?, ?, ?, ?, ?, ?, ?, 'admin')");
        $stmt->execute([$player_code, $username, $email, $hashed_password, $full_name, $display_name, $phone]);
        $admin_id = $pdo->lastInsertId();

        $stmt = $pdo->prepare("INSERT INTO lapangan (admin_id, nama_lapangan, jenis_olahraga, deskripsi, harga_per_jam, jumlah_lapangan, foto, alamat, wilayah, kabupaten, status)
                               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'aktif')");
        $stmt->execute([$admin_id, $nama_lapangan, $jenis_olahraga, $deskripsi, $harga_per_jam, $jumlah_lapangan, $foto, $alamat, $wilayah, $kabupaten]);
        $pdo->commit();
        header('Location: login.php?success=' . urlencode("Admin lapangan berhasil dibuat. ID akun kamu: $player_code. Silakan login sebagai admin."));
        exit();
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        header('Location: daftar-admin.php?error=' . urlencode('Gagal daftar admin: ' . $e->getMessage()));
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Admin Lapangan - LapanganKita</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="auth-page-wrap register-container">
    <div class="auth-card-wide admin-register-card">
        <h1>Daftar Admin Lapangan</h1>
        <p>Buat akun admin sekaligus daftarkan lapangan pertama kamu.</p>
        <?php if(isset($_GET['error'])): ?><div class="alert-error"><?= e($_GET['error']) ?></div><?php endif; ?>
        <form method="POST" enctype="multipart/form-data" class="clean-form admin-register-grid">
            <div class="form-section-title">Data Akun Admin</div>
            <div class="form-group"><label>Username</label><input type="text" name="username" required></div>
            <div class="form-group"><label>Email</label><input type="email" name="email" required></div>
            <div class="form-group"><label>Nama Pemilik/Admin</label><input type="text" name="full_name"></div>
            <div class="form-group"><label>No. Telepon</label><input type="text" name="phone"></div>
            <div class="form-group"><label>Password</label><input type="password" name="password" minlength="6" required></div>
            <div class="form-group"><label>Konfirmasi Password</label><input type="password" name="confirm_password" minlength="6" required></div>

            <div class="form-section-title">Data Lapangan</div>
            <div class="form-group"><label>Nama Lapangan</label><input type="text" name="nama_lapangan" required></div>
            <div class="form-group"><label>Jenis Olahraga</label>
                <select name="jenis_olahraga" required>
                    <option value="">Pilih olahraga</option>
                    <?php foreach($jenis_list as $jenis): ?><option value="<?= e($jenis) ?>"><?= e(ucwords($jenis)) ?></option><?php endforeach; ?>
                </select>
            </div>
            <div class="form-group"><label>Harga per Jam</label><input type="number" name="harga_per_jam" min="1000" step="500" required></div>
            <div class="form-group"><label>Jumlah Unit Lapangan</label><input type="number" name="jumlah_lapangan" min="1" value="1" required></div>
            <div class="form-group full-span"><label>Alamat</label><textarea name="alamat" rows="2"></textarea></div>
            <div class="form-group"><label>Wilayah</label><input type="text" name="wilayah"></div>
            <div class="form-group"><label>Kabupaten/Kota</label><input type="text" name="kabupaten"></div>
            <div class="form-group full-span"><label>Deskripsi</label><textarea name="deskripsi" rows="3"></textarea></div>
            <div class="form-group full-span"><label>Foto Lapangan</label><input type="file" name="foto" accept="image/jpeg,image/png,image/webp"></div>
            <button type="submit" class="btn-primary full-span">Daftar Admin + Lapangan</button>
        </form>
        <div class="auth-links"><p>Sudah punya akun? <a href="login.php">Login</a></p></div>
    </div>
</div>
</body>
</html>
