-- Update tambahan untuk fitur booking fleksibel + booking langsung/offline
-- Jalankan file ini kalau database lama sudah terlanjur ada.
USE `olahragabooking`;

ALTER TABLE `bookings`
  ADD COLUMN IF NOT EXISTS `booking_source` ENUM('online','offline') NOT NULL DEFAULT 'online' AFTER `booking_code`,
  ADD COLUMN IF NOT EXISTS `nama_pelanggan` VARCHAR(100) NULL AFTER `booking_source`,
  ADD COLUMN IF NOT EXISTS `telepon_pelanggan` VARCHAR(20) NULL AFTER `nama_pelanggan`,
  ADD COLUMN IF NOT EXISTS `catatan` TEXT NULL AFTER `telepon_pelanggan`;
