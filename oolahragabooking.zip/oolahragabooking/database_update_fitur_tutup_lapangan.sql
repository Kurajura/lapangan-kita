USE `olahragabooking`;

CREATE TABLE IF NOT EXISTS `lapangan_tutup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lapangan_id` int(11) NOT NULL,
  `nomor_lapangan` int(11) NOT NULL DEFAULT 1,
  `tanggal` date NOT NULL,
  `jam_mulai` time NOT NULL,
  `jam_selesai` time NOT NULL,
  `alasan` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `lapangan_id` (`lapangan_id`),
  KEY `idx_tutup_cek_jadwal` (`lapangan_id`,`nomor_lapangan`,`tanggal`,`jam_mulai`,`jam_selesai`),
  CONSTRAINT `lapangan_tutup_ibfk_1` FOREIGN KEY (`lapangan_id`) REFERENCES `lapangan` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Update tambahan untuk fitur booking fleksibel + booking langsung/offline
-- Jalankan file ini kalau database lama sudah terlanjur ada.
USE `olahragabooking`;

ALTER TABLE `bookings`
  ADD COLUMN IF NOT EXISTS `booking_source` ENUM('online','offline') NOT NULL DEFAULT 'online' AFTER `booking_code`,
  ADD COLUMN IF NOT EXISTS `nama_pelanggan` VARCHAR(100) NULL AFTER `booking_source`,
  ADD COLUMN IF NOT EXISTS `telepon_pelanggan` VARCHAR(20) NULL AFTER `nama_pelanggan`,
  ADD COLUMN IF NOT EXISTS `catatan` TEXT NULL AFTER `telepon_pelanggan`;

