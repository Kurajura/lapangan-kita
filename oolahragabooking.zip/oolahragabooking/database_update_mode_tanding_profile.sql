-- ==========================================================
-- UPDATE FITUR: MODE TANDING + LEADERBOARD + PROFIL USER
-- Import file ini kalau database lama sudah pernah dibuat.
-- Kalau import full oolahragabooking.sql terbaru, file ini tidak wajib.
-- ==========================================================

ALTER TABLE `bookings`
  ADD COLUMN IF NOT EXISTS `match_enabled` TINYINT(1) NOT NULL DEFAULT 0 AFTER `mode_main`,
  ADD COLUMN IF NOT EXISTS `match_status` ENUM('inactive','waiting_score','completed','cancelled') NOT NULL DEFAULT 'inactive' AFTER `match_enabled`,
  ADD COLUMN IF NOT EXISTS `match_requested_at` TIMESTAMP NULL DEFAULT NULL AFTER `match_status`,
  ADD COLUMN IF NOT EXISTS `match_opponent_name` VARCHAR(100) DEFAULT NULL AFTER `match_requested_at`;

ALTER TABLE `users`
  ADD COLUMN IF NOT EXISTS `display_name` VARCHAR(100) DEFAULT NULL AFTER `full_name`,
  ADD COLUMN IF NOT EXISTS `bio` TEXT DEFAULT NULL AFTER `phone`,
  ADD COLUMN IF NOT EXISTS `profile_photo` VARCHAR(255) DEFAULT NULL AFTER `bio`,
  ADD COLUMN IF NOT EXISTS `show_rank_badges` TINYINT(1) NOT NULL DEFAULT 1 AFTER `profile_photo`;

UPDATE `users`
SET `display_name` = `full_name`
WHERE (`display_name` IS NULL OR `display_name` = '')
  AND `full_name` IS NOT NULL
  AND `full_name` <> '';
