-- UPDATE ONLY - aman diimport berkali-kali
-- Revisi navbar, logo, dan pencarian tidak membutuhkan perubahan tabel baru.
-- SQL ini hanya memastikan tabel hide booking dari revisi sebelumnya tetap tersedia.

USE `oolahragabooking`;

CREATE TABLE IF NOT EXISTS `admin_booking_hidden` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `admin_id` INT(11) NOT NULL,
  `booking_id` INT(11) NOT NULL,
  `hidden_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_admin_booking_hidden` (`admin_id`,`booking_id`),
  KEY `idx_admin_booking_hidden_booking` (`booking_id`),
  KEY `idx_admin_booking_hidden_admin` (`admin_id`,`hidden_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
