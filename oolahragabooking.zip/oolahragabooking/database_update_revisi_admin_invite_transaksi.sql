-- =========================================================
-- UPDATE REVISI: UNDANGAN TANDING TERLIHAT + ADMIN EDIT BOOKING/TRANSAKSI
-- Import ke database `oolahragabooking` setelah replace file project.
-- =========================================================

-- Tambahkan status cancelled pada transaksi agar admin bisa membatalkan transaksi.
ALTER TABLE `transactions`
  MODIFY `status` ENUM('pending','success','failed','cancelled') DEFAULT 'pending';

-- Pastikan tabel notifikasi/undangan dari revisi sebelumnya tetap ada.
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL,
  `title` VARCHAR(150) NOT NULL,
  `message` TEXT NOT NULL,
  `link` VARCHAR(255) DEFAULT NULL,
  `is_read` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_notifications_user` (`user_id`,`is_read`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Pastikan tipe tutup lapangan ada untuk opsi seharian/manual.
ALTER TABLE `lapangan_tutup`
  ADD COLUMN IF NOT EXISTS `tipe_tutup` ENUM('manual','seharian') NOT NULL DEFAULT 'manual' AFTER `tanggal`;

-- Sinkronisasi data lama: transaksi cancel membuat booking cancel.
UPDATE `bookings` b
JOIN `transactions` t ON t.booking_id = b.id
SET b.status = 'cancelled', b.payment_status = 'unpaid', b.match_status = 'cancelled'
WHERE t.status = 'cancelled';
