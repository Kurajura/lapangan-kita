-- =========================================================
-- UPDATE REVISI BARU: QR, MODE SOLO/TEAM, CHAT, TUTUP SEHARIAN, VIP
-- Import ke database oolahragabooking jika database lama sudah dipakai.
-- Aman dijalankan di MariaDB/XAMPP modern karena memakai IF NOT EXISTS.
-- =========================================================

ALTER TABLE `bookings`
  ADD COLUMN IF NOT EXISTS `match_enabled` TINYINT(1) NOT NULL DEFAULT 0 AFTER `mode_main`,
  ADD COLUMN IF NOT EXISTS `match_type` ENUM('solo','team') NOT NULL DEFAULT 'solo' AFTER `match_enabled`,
  ADD COLUMN IF NOT EXISTS `match_status` ENUM('inactive','team_setup','team_ready','pending_opponent_team','pending_approval','approved','waiting_score','rejected','completed','cancelled') NOT NULL DEFAULT 'inactive' AFTER `match_type`,
  ADD COLUMN IF NOT EXISTS `match_requested_at` TIMESTAMP NULL DEFAULT NULL AFTER `match_status`,
  ADD COLUMN IF NOT EXISTS `match_opponent_name` VARCHAR(100) DEFAULT NULL AFTER `match_requested_at`,
  ADD COLUMN IF NOT EXISTS `match_rejected_reason` VARCHAR(255) DEFAULT NULL AFTER `match_opponent_name`,
  ADD COLUMN IF NOT EXISTS `requester_team_id` INT(11) DEFAULT NULL AFTER `match_rejected_reason`,
  ADD COLUMN IF NOT EXISTS `opponent_team_id` INT(11) DEFAULT NULL AFTER `requester_team_id`,
  ADD COLUMN IF NOT EXISTS `team_match_request_id` INT(11) DEFAULT NULL AFTER `opponent_team_id`,
  ADD COLUMN IF NOT EXISTS `vip_discount_percent` DECIMAL(5,2) NOT NULL DEFAULT 0.00 AFTER `total_harga`,
  ADD COLUMN IF NOT EXISTS `vip_discount_amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER `vip_discount_percent`;

ALTER TABLE `bookings`
  MODIFY `match_status` ENUM('inactive','team_setup','team_ready','pending_opponent_team','pending_approval','approved','waiting_score','rejected','completed','cancelled') NOT NULL DEFAULT 'inactive',
  MODIFY `match_type` ENUM('solo','team') NOT NULL DEFAULT 'solo';

ALTER TABLE `users`
  ADD COLUMN IF NOT EXISTS `player_code` VARCHAR(6) DEFAULT NULL AFTER `id`,
  ADD COLUMN IF NOT EXISTS `display_name` VARCHAR(100) DEFAULT NULL AFTER `full_name`,
  ADD COLUMN IF NOT EXISTS `bio` TEXT DEFAULT NULL AFTER `phone`,
  ADD COLUMN IF NOT EXISTS `profile_photo` VARCHAR(255) DEFAULT NULL AFTER `bio`,
  ADD COLUMN IF NOT EXISTS `show_rank_badges` TINYINT(1) NOT NULL DEFAULT 1 AFTER `profile_photo`,
  ADD COLUMN IF NOT EXISTS `vip_until` DATE DEFAULT NULL AFTER `show_rank_badges`,
  ADD COLUMN IF NOT EXISTS `vip_discount_percent` DECIMAL(5,2) NOT NULL DEFAULT 10.00 AFTER `vip_until`;

UPDATE `users` SET `player_code` = LPAD(301900 + id, 6, '0') WHERE `player_code` IS NULL OR `player_code` = '';
UPDATE `users` SET `display_name` = `full_name` WHERE (`display_name` IS NULL OR `display_name` = '') AND `full_name` IS NOT NULL AND `full_name` <> '';

ALTER TABLE `lapangan_tutup`
  ADD COLUMN IF NOT EXISTS `tipe_tutup` ENUM('manual','seharian') NOT NULL DEFAULT 'manual' AFTER `tanggal`;

CREATE TABLE IF NOT EXISTS `match_participants` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `booking_id` INT(11) NOT NULL,
  `user_id` INT(11) NOT NULL,
  `team` ENUM('challenger','opponent') NOT NULL DEFAULT 'challenger',
  `status` ENUM('pending','accepted','rejected') NOT NULL DEFAULT 'pending',
  `is_captain` TINYINT(1) NOT NULL DEFAULT 0,
  `invited_by` INT(11) DEFAULT NULL,
  `responded_at` TIMESTAMP NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_booking_user` (`booking_id`,`user_id`),
  KEY `idx_match_participants_user` (`user_id`,`status`),
  KEY `idx_match_participants_booking` (`booking_id`,`team`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `teams` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `team_code` VARCHAR(12) NOT NULL,
  `team_name` VARCHAR(100) NOT NULL,
  `captain_id` INT(11) NOT NULL,
  `jenis_olahraga` VARCHAR(50) DEFAULT NULL,
  `status` ENUM('pending','active','rejected','inactive') NOT NULL DEFAULT 'pending',
  `created_by_booking_id` INT(11) DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_team_code` (`team_code`),
  KEY `idx_team_name` (`team_name`),
  KEY `idx_team_captain` (`captain_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `team_members` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `team_id` INT(11) NOT NULL,
  `user_id` INT(11) NOT NULL,
  `status` ENUM('pending','accepted','rejected') NOT NULL DEFAULT 'pending',
  `is_captain` TINYINT(1) NOT NULL DEFAULT 0,
  `invited_by` INT(11) DEFAULT NULL,
  `responded_at` TIMESTAMP NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_team_member` (`team_id`,`user_id`),
  KEY `idx_team_member_user` (`user_id`,`status`),
  KEY `idx_team_member_team` (`team_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `team_match_requests` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `booking_id` INT(11) NOT NULL,
  `requester_user_id` INT(11) NOT NULL,
  `requester_team_id` INT(11) NOT NULL,
  `opponent_team_id` INT(11) NOT NULL,
  `status` ENUM('pending','accepted','rejected','completed','cancelled') NOT NULL DEFAULT 'pending',
  `message` VARCHAR(255) DEFAULT NULL,
  `responded_by` INT(11) DEFAULT NULL,
  `responded_at` TIMESTAMP NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_team_match_booking` (`booking_id`,`status`),
  KEY `idx_team_match_opp` (`opponent_team_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `chat_messages` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `sender_id` INT(11) NOT NULL,
  `receiver_id` INT(11) NOT NULL,
  `message` TEXT NOT NULL,
  `is_read` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_chat_pair` (`sender_id`,`receiver_id`,`created_at`),
  KEY `idx_chat_receiver` (`receiver_id`,`is_read`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `vip_orders` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL,
  `amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `duration_days` INT(11) NOT NULL DEFAULT 30,
  `discount_percent` DECIMAL(5,2) NOT NULL DEFAULT 10.00,
  `payment_method` VARCHAR(50) DEFAULT NULL,
  `payment_channel` VARCHAR(50) DEFAULT NULL,
  `qr_code` TEXT DEFAULT NULL,
  `transaction_code` VARCHAR(50) NOT NULL,
  `status` ENUM('pending','success','failed','cancelled') NOT NULL DEFAULT 'pending',
  `payment_date` TIMESTAMP NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_vip_transaction` (`transaction_code`),
  KEY `idx_vip_user` (`user_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
