-- =====================================================
-- UPDATE REVISI: CHAT, MARKET, KEUNTUNGAN SUPER ADMIN
-- Aman dijalankan berulang di MariaDB/XAMPP.
-- =====================================================

ALTER TABLE `bookings`
  ADD COLUMN IF NOT EXISTS `platform_fee` DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER `vip_discount_amount`,
  ADD COLUMN IF NOT EXISTS `owner_amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER `platform_fee`;

-- Isi fee untuk data booking lama yang masih 0.
-- Fee sistem 5%, bagian admin lapangan 95%.
UPDATE `bookings`
SET `platform_fee` = FLOOR(`total_harga` * 0.05),
    `owner_amount` = GREATEST(0, `total_harga` - FLOOR(`total_harga` * 0.05))
WHERE (`platform_fee` IS NULL OR `platform_fee` = 0)
  AND (`owner_amount` IS NULL OR `owner_amount` = 0)
  AND `status` <> 'cancelled';

CREATE TABLE IF NOT EXISTS `product_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `buyer_id` int(11) NOT NULL,
  `seller_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `price` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `platform_fee` decimal(12,2) NOT NULL DEFAULT 0.00,
  `seller_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `payment_method` varchar(50) DEFAULT NULL,
  `payment_channel` varchar(50) DEFAULT NULL,
  `qr_code` text DEFAULT NULL,
  `transaction_code` varchar(50) NOT NULL,
  `status` enum('pending','success','failed','cancelled') NOT NULL DEFAULT 'pending',
  `payment_date` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_product_order_code` (`transaction_code`),
  KEY `idx_product_orders_product` (`product_id`,`status`),
  KEY `idx_product_orders_buyer` (`buyer_id`,`status`),
  KEY `idx_product_orders_seller` (`seller_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
