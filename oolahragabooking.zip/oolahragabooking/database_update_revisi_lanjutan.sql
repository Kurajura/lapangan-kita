-- =========================================================
-- UPDATE REVISI LANJUTAN LAPANGANKITA / OOLAHRAGABOOKING
-- Fitur:
-- 1. ID pemain 6 angka format 301901, 301902, dst.
-- 2. Daftar admin lapangan.
-- 3. Lupa/reset password pakai kode.
-- 4. Mode tanding approval solo/team.
-- 5. Pencarian cerdas pemain.
-- 6. Leaderboard multi pemain/team.
-- =========================================================

ALTER TABLE `users`
  ADD COLUMN IF NOT EXISTS `player_code` VARCHAR(6) DEFAULT NULL AFTER `id`,
  ADD COLUMN IF NOT EXISTS `display_name` VARCHAR(100) DEFAULT NULL AFTER `full_name`,
  ADD COLUMN IF NOT EXISTS `bio` TEXT DEFAULT NULL AFTER `phone`,
  ADD COLUMN IF NOT EXISTS `profile_photo` VARCHAR(255) DEFAULT NULL AFTER `bio`,
  ADD COLUMN IF NOT EXISTS `show_rank_badges` TINYINT(1) NOT NULL DEFAULT 1 AFTER `profile_photo`;

UPDATE `users`
SET `player_code` = LPAD(301900 + `id`, 6, '0')
WHERE `player_code` IS NULL OR `player_code` = '';

UPDATE `users`
SET `display_name` = `full_name`
WHERE (`display_name` IS NULL OR `display_name` = '')
AND `full_name` IS NOT NULL AND `full_name` <> '';

CREATE UNIQUE INDEX IF NOT EXISTS `uniq_player_code` ON `users` (`player_code`);

ALTER TABLE `bookings`
  ADD COLUMN IF NOT EXISTS `match_enabled` TINYINT(1) NOT NULL DEFAULT 0 AFTER `mode_main`,
  ADD COLUMN IF NOT EXISTS `match_type` ENUM('solo','team') NOT NULL DEFAULT 'solo' AFTER `match_enabled`,
  ADD COLUMN IF NOT EXISTS `match_status` ENUM('inactive','pending_approval','approved','waiting_score','rejected','completed','cancelled') NOT NULL DEFAULT 'inactive' AFTER `match_type`,
  ADD COLUMN IF NOT EXISTS `match_requested_at` TIMESTAMP NULL DEFAULT NULL AFTER `match_status`,
  ADD COLUMN IF NOT EXISTS `match_opponent_name` VARCHAR(100) DEFAULT NULL AFTER `match_requested_at`,
  ADD COLUMN IF NOT EXISTS `match_rejected_reason` VARCHAR(255) DEFAULT NULL AFTER `match_opponent_name`;

ALTER TABLE `bookings`
  MODIFY `match_status` ENUM('inactive','pending_approval','approved','waiting_score','rejected','completed','cancelled') NOT NULL DEFAULT 'inactive';

CREATE TABLE IF NOT EXISTS `match_participants` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `booking_id` INT(11) NOT NULL,
  `user_id` INT(11) NOT NULL,
  `team` ENUM('challenger','opponent') NOT NULL DEFAULT 'challenger',
  `status` ENUM('pending','accepted','rejected') NOT NULL DEFAULT 'pending',
  `is_captain` TINYINT(1) NOT NULL DEFAULT 0,
  `invited_by` INT(11) DEFAULT NULL,
  `responded_at` TIMESTAMP NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_booking_user` (`booking_id`,`user_id`),
  KEY `idx_match_participants_user` (`user_id`,`status`),
  KEY `idx_match_participants_booking` (`booking_id`,`team`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `notifications` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL,
  `title` VARCHAR(150) NOT NULL,
  `message` TEXT NOT NULL,
  `link` VARCHAR(255) DEFAULT NULL,
  `is_read` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_notifications_user` (`user_id`,`is_read`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `password_resets` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `reset_code` VARCHAR(10) NOT NULL,
  `expires_at` DATETIME NOT NULL,
  `used` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_password_resets_code` (`reset_code`,`used`),
  KEY `idx_password_resets_user` (`user_id`,`used`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Buat index composite dulu agar foreign key tetap aman, lalu hapus unique lama booking_id.
CREATE UNIQUE INDEX IF NOT EXISTS `uniq_booking_user_result` ON `match_results` (`booking_id`,`user_id`);

SET @old_booking_unique := (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'match_results'
  AND INDEX_NAME = 'booking_id'
);
SET @drop_sql := IF(@old_booking_unique > 0, 'ALTER TABLE `match_results` DROP INDEX `booking_id`', 'SELECT 1');
PREPARE stmt_drop_old_idx FROM @drop_sql;
EXECUTE stmt_drop_old_idx;
DEALLOCATE PREPARE stmt_drop_old_idx;
