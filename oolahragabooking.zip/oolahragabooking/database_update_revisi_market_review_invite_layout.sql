-- Update revisi: perbaikan undangan tanding, market barang olahraga, review lapangan/barang
-- Aman di-import berulang ke database oolahragabooking
USE `oolahragabooking`;

CREATE TABLE IF NOT EXISTS `products` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `seller_id` INT(11) NOT NULL,
  `product_name` VARCHAR(150) NOT NULL,
  `category` VARCHAR(80) DEFAULT NULL,
  `description` TEXT DEFAULT NULL,
  `price` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `stock` INT(11) NOT NULL DEFAULT 1,
  `photo` VARCHAR(255) DEFAULT NULL,
  `status` ENUM('active','inactive','sold_out') NOT NULL DEFAULT 'active',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_products_seller` (`seller_id`,`status`),
  KEY `idx_products_search` (`product_name`,`category`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `product_reviews` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `product_id` INT(11) NOT NULL,
  `user_id` INT(11) NOT NULL,
  `rating` TINYINT(1) NOT NULL,
  `message` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_product_reviews_product` (`product_id`,`created_at`),
  KEY `idx_product_reviews_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `lapangan_reviews` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `lapangan_id` INT(11) NOT NULL,
  `user_id` INT(11) NOT NULL,
  `booking_id` INT(11) DEFAULT NULL,
  `rating` TINYINT(1) NOT NULL,
  `message` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_lapangan_reviews_lapangan` (`lapangan_id`,`created_at`),
  KEY `idx_lapangan_reviews_user` (`user_id`),
  KEY `idx_lapangan_reviews_booking` (`booking_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Catatan penting bug undangan solo:
-- Data lama tidak perlu diubah. Bug-nya ada di query PHP yang dulu memfilter is_captain=0,
-- sementara lawan solo tersimpan sebagai team='opponent' dan is_captain=1.
-- Di versi kode ini query sudah diperbaiki agar membaca team='opponent'.
