<?php
include 'config/database.php';

$lapangan_id = (int) ($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT l.*, u.full_name AS admin_name, u.phone AS admin_phone FROM lapangan l JOIN users u ON l.admin_id = u.id WHERE l.id = ? AND l.status = 'aktif'");
$stmt->execute([$lapangan_id]);
$lapangan = $stmt->fetch();

if (!$lapangan) {
    header("Location: booking.php?error=Lapangan tidak ditemukan");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_lapangan_review'])) {
    if (!isLoggedIn()) {
        header('Location: login.php?error=' . urlencode('Login dulu untuk memberi review lapangan'));
        exit();
    }
    $rating = (int)($_POST['rating'] ?? 0);
    $message = trim($_POST['message'] ?? '');
    if ($rating < 1 || $rating > 5) {
        header('Location: detail-lapangan.php?id=' . $lapangan_id . '&error=' . urlencode('Rating harus 1 sampai 5'));
        exit();
    }
    $booking_id_review = null;
    $stmtBk = $pdo->prepare("SELECT id FROM bookings WHERE lapangan_id = ? AND user_id = ? AND status <> 'cancelled' ORDER BY tanggal DESC, created_at DESC LIMIT 1");
    $stmtBk->execute([$lapangan_id, getUserId()]);
    $booking_id_review = $stmtBk->fetchColumn() ?: null;
    $stmtReview = $pdo->prepare("INSERT INTO lapangan_reviews (lapangan_id, user_id, booking_id, rating, message) VALUES (?, ?, ?, ?, ?)");
    $stmtReview->execute([$lapangan_id, getUserId(), $booking_id_review, $rating, $message]);
    header('Location: detail-lapangan.php?id=' . $lapangan_id . '&success=' . urlencode('Review lapangan berhasil disimpan'));
    exit();
}

$jumlah_lapangan = max(1, (int) ($lapangan['jumlah_lapangan'] ?? 1));
$selected_nomor = (int) ($_GET['nomor_lapangan'] ?? 1);
if ($selected_nomor < 1 || $selected_nomor > $jumlah_lapangan) {
    $selected_nomor = 1;
}

$jam_buka_min = 6 * 60;
$jam_tutup_min = 23 * 60;
$interval_timeline = 15;
$today = date('Y-m-d');
$days = [];
for ($i = 0; $i < 7; $i++) {
    $days[] = date('Y-m-d', strtotime("+$i day"));
}

function timeToMinutesDetail($time) {
    $parts = explode(':', $time);
    return ((int) $parts[0] * 60) + (int) $parts[1];
}

function minutesToTimeDetail($minutes) {
    $hour = floor($minutes / 60);
    $minute = $minutes % 60;
    return sprintf('%02d:%02d:00', $hour, $minute);
}

function formatJamDetail($time) {
    return substr($time, 0, 5);
}

function rangesOverlapDetail($startA, $endA, $startB, $endB) {
    return timeToMinutesDetail($startA) < timeToMinutesDetail($endB) && timeToMinutesDetail($endA) > timeToMinutesDetail($startB);
}

function getBookedRangesDetail($pdo, $lapangan_id, $nomor_lapangan, $tanggal) {
    $stmt = $pdo->prepare("SELECT b.jam_mulai, b.jam_selesai, b.booking_code, b.booking_source, b.nama_pelanggan, u.username
                           FROM bookings b
                           JOIN users u ON b.user_id = u.id
                           WHERE b.lapangan_id = ? AND b.nomor_lapangan = ? AND b.tanggal = ?
                           AND b.status <> 'cancelled'
                           ORDER BY b.jam_mulai ASC");
    $stmt->execute([$lapangan_id, $nomor_lapangan, $tanggal]);
    return $stmt->fetchAll();
}

function getClosedRangesDetail($pdo, $lapangan_id, $nomor_lapangan, $tanggal) {
    $stmt = $pdo->prepare("SELECT jam_mulai, jam_selesai, alasan
                           FROM lapangan_tutup
                           WHERE lapangan_id = ? AND nomor_lapangan = ? AND tanggal = ?
                           ORDER BY jam_mulai ASC");
    $stmt->execute([$lapangan_id, $nomor_lapangan, $tanggal]);
    return $stmt->fetchAll();
}

function statusForMiniRange($start, $end, $booked_ranges, $closed_ranges) {
    foreach ($closed_ranges as $range) {
        if (rangesOverlapDetail($start, $end, $range['jam_mulai'], $range['jam_selesai'])) {
            return ['status' => 'closed', 'label' => 'Tutup', 'note' => $range['alasan'] ?: 'Ditutup admin'];
        }
    }

    foreach ($booked_ranges as $range) {
        if (rangesOverlapDetail($start, $end, $range['jam_mulai'], $range['jam_selesai'])) {
            return ['status' => 'booked', 'label' => 'Booked', 'note' => ($range['booking_source'] ?? 'online') === 'offline' ? 'Booking offline' : 'Booking online'];
        }
    }

    return ['status' => 'available', 'label' => 'Tersedia', 'note' => 'Bisa dibooking'];
}

$stmtLeaderboard = $pdo->prepare("SELECT mr.user_id,
                                      COALESCE(NULLIF(u.display_name, ''), NULLIF(u.full_name, ''), u.username) AS player_name,
                                      u.profile_photo, u.player_code,
                                      COUNT(*) AS total_match,
                                      SUM(CASE WHEN mr.winner = 'user' THEN 1 ELSE 0 END) AS menang,
                                      SUM(CASE WHEN mr.winner = 'draw' THEN 1 ELSE 0 END) AS seri,
                                      SUM(CASE WHEN mr.winner = 'opponent' THEN 1 ELSE 0 END) AS kalah,
                                      SUM(mr.points) AS total_points,
                                      SUM(mr.score_diff) AS total_diff
                               FROM match_results mr
                               JOIN users u ON mr.user_id = u.id
                               WHERE mr.lapangan_id = ?
                               GROUP BY mr.user_id, player_name, u.profile_photo, u.player_code
                               ORDER BY total_points DESC, menang DESC, total_diff DESC, total_match DESC, player_name ASC
                               LIMIT 10");
$stmtLeaderboard->execute([$lapangan['id']]);
$leaderboard_rows = $stmtLeaderboard->fetchAll();

$stmtReviewSummary = $pdo->prepare("SELECT COALESCE(AVG(rating),0) AS avg_rating, COUNT(*) AS total_review FROM lapangan_reviews WHERE lapangan_id = ?");
$stmtReviewSummary->execute([$lapangan['id']]);
$lapangan_review_summary = $stmtReviewSummary->fetch();

$stmtReviews = $pdo->prepare("SELECT lr.*, COALESCE(NULLIF(u.display_name,''), NULLIF(u.full_name,''), u.username) AS reviewer_name, u.player_code
                              FROM lapangan_reviews lr
                              JOIN users u ON lr.user_id = u.id
                              WHERE lr.lapangan_id = ?
                              ORDER BY lr.created_at DESC LIMIT 20");
$stmtReviews->execute([$lapangan['id']]);
$lapangan_reviews = $stmtReviews->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Lapangan - <?= htmlspecialchars($lapangan['nama_lapangan']) ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="top-header">
    <div class="promo-box"> Detail Lapangan <span>JADWAL FLEKSIBEL</span></div>
    <div class="top-right">
        <?php if(isLoggedIn()): ?>
            <div class="user-info">
                <i class="fa-regular fa-user"></i> <?= htmlspecialchars($_SESSION['username']) ?>
                <a href="logout.php" style="color:#ff003c;">Logout</a>
            </div>
        <?php else: ?>
            <a href="login.php" class="login-btn"><div class="login-icon"><i class="fa-regular fa-user"></i></div> Login</a>
            <a href="register.php" class="plan-btn">Daftar</a>
        <?php endif; ?>
    </div>
</div>
<?php renderNavbar(''); ?>

<div class="booking-page-wrap">
    <div class="booking-hero-card detail-layout-card">
        <div class="booking-hero-image detail-main-image">
            <?php if($lapangan['foto']): ?>
                <img src="assets/uploads/<?= htmlspecialchars($lapangan['foto']) ?>" alt="<?= htmlspecialchars($lapangan['nama_lapangan']) ?>">
            <?php else: ?>
                <i class="fa-solid fa-futbol"></i>
            <?php endif; ?>
        </div>
        <div class="booking-hero-info">
            <span class="mini-badge"><?= htmlspecialchars($lapangan['jenis_olahraga']) ?></span>
            <h1><?= htmlspecialchars($lapangan['nama_lapangan']) ?></h1>
            <p><?= nl2br(htmlspecialchars($lapangan['deskripsi'] ?: 'Belum ada deskripsi lapangan.')) ?></p>
            <div class="booking-info-grid">
                <div><i class="fa-solid fa-money-bill-wave"></i><strong>Rp <?= number_format($lapangan['harga_per_jam'], 0, ',', '.') ?></strong><span>/ jam, bisa per menit</span></div>
                <div><i class="fa-solid fa-layer-group"></i><strong><?= $jumlah_lapangan ?></strong><span>unit lapangan</span></div>
                <div><i class="fa-solid fa-user-tie"></i><strong><?= htmlspecialchars($lapangan['admin_name'] ?: '-') ?></strong><span>pemilik</span></div>
            </div>
            <div class="detail-info-list">
                <p><i class="fa-solid fa-location-dot"></i> <?= htmlspecialchars($lapangan['alamat'] ?: '-') ?></p>
                <p><i class="fa-solid fa-phone"></i> <?= htmlspecialchars($lapangan['admin_phone'] ?: '-') ?></p>
                <p><i class="fa-solid fa-clock"></i> Jadwal tampil per 15 menit, tetapi booking bisa isi menit bebas seperti 07:43 - 08:43.</p>
            </div>
            <a href="<?= isLoggedIn() ? 'booking-process.php?id=' . $lapangan['id'] . '&nomor_lapangan=' . $selected_nomor : 'login.php?error=Silakan login dulu untuk booking lapangan' ?>" class="btn-book">Booking Lapangan Ini</a>
        </div>
    </div>

    <div class="form-card leaderboard-card detail-leaderboard-card">
        <div class="booking-board-head">
            <div>
                <h2>Leaderboard Lapangan Ini</h2>
                <p>Peringkat berdasarkan hasil mode tanding yang sudah dicatat admin lapangan.</p>
            </div>
            <a href="leaderboard.php?lapangan_id=<?= $lapangan['id'] ?>" class="btn-secondary">Lihat Full Leaderboard</a>
        </div>
        <div class="table-responsive">
            <table class="data-table leaderboard-table">
                <thead>
                    <tr>
                        <th>Rank</th>
                        <th>Pemain</th>
                        <th>Main</th>
                        <th>Menang</th>
                        <th>Seri</th>
                        <th>Kalah</th>
                        <th>Selisih</th>
                        <th>Poin</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($leaderboard_rows as $i => $row): ?>
                    <tr>
                        <td><span class="rank-pill rank-<?= $i + 1 <= 3 ? $i + 1 : 'other' ?>">#<?= $i + 1 ?></span></td>
                        <td><a class="player-cell" href="profile.php?id=<?= $row['user_id'] ?>"><?= e($row['player_name']) ?> <small class="small-muted">ID <?= e($row['player_code'] ?? '-') ?></small></a></td>
                        <td><?= (int)$row['total_match'] ?></td>
                        <td><?= (int)$row['menang'] ?></td>
                        <td><?= (int)$row['seri'] ?></td>
                        <td><?= (int)$row['kalah'] ?></td>
                        <td><?= (int)$row['total_diff'] ?></td>
                        <td><strong><?= (int)$row['total_points'] ?></strong></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if(count($leaderboard_rows) === 0): ?>
                    <tr><td colspan="8" style="text-align:center;">Belum ada hasil pertandingan di lapangan ini.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>


    <div class="form-card rating-summary-card">
        <div class="booking-board-head">
            <div>
                <h2>Review Lapangan</h2>
                <p>Penilaian pengguna berdasarkan kepuasan bermain di lapangan ini.</p>
            </div>
            <div class="rating-row">
                <?= starRatingHtml($lapangan_review_summary['avg_rating']) ?>
                <strong><?= number_format((float)$lapangan_review_summary['avg_rating'], 1) ?>/5</strong>
                <span><?= (int)$lapangan_review_summary['total_review'] ?> review</span>
            </div>
        </div>
        <?php if(isset($_GET['success'])): ?><div class="alert-success"><?= e($_GET['success']) ?></div><?php endif; ?>
        <?php if(isset($_GET['error'])): ?><div class="alert-error"><?= e($_GET['error']) ?></div><?php endif; ?>
        <?php if(isLoggedIn()): ?>
        <form method="POST" class="review-form-grid">
            <div><label>Bintang</label><select name="rating" required><option value="5">5 - Sangat puas</option><option value="4">4 - Puas</option><option value="3">3 - Cukup</option><option value="2">2 - Kurang</option><option value="1">1 - Tidak puas</option></select></div>
            <div><label>Pesan Review</label><textarea name="message" placeholder="Tulis pengalaman kamu bermain di lapangan ini"></textarea></div>
            <button class="btn-primary" name="add_lapangan_review" value="1">Kirim Review</button>
        </form>
        <?php else: ?>
        <p class="helper-text">Login dulu untuk memberi review lapangan.</p>
        <?php endif; ?>
        <div class="review-list">
            <?php foreach($lapangan_reviews as $review): ?>
                <div class="review-card"><strong><?= e($review['reviewer_name']) ?> <small>ID <?= e($review['player_code']) ?></small></strong><div><?= starRatingHtml($review['rating']) ?> <small><?= date('d/m/Y H:i', strtotime($review['created_at'])) ?></small></div><p><?= nl2br(e($review['message'] ?: '-')) ?></p></div>
            <?php endforeach; ?>
            <?php if(!$lapangan_reviews): ?><p class="helper-text">Belum ada review untuk lapangan ini.</p><?php endif; ?>
        </div>
    </div>


    <div class="booking-board">
        <div class="booking-board-head">
            <div>
                <h2>Jadwal Booking & Tutup Lapangan</h2>
                <p>Warna merah/abu-abu berarti waktu itu tidak bisa dipilih. Daftar di bawah menampilkan jam tepat sampai menit.</p>
            </div>
            <div class="legend-wrap">
                <span><b class="legend-dot available"></b> Tersedia</span>
                <span><b class="legend-dot booked"></b> Dibooking</span>
                <span><b class="legend-dot closed"></b> Ditutup</span>
            </div>
        </div>

        <form method="GET" class="schedule-filter-form">
            <input type="hidden" name="id" value="<?= $lapangan['id'] ?>">
            <div class="form-group">
                <label>Pilih Nomor Lapangan</label>
                <select name="nomor_lapangan" required>
                    <?php for($i = 1; $i <= $jumlah_lapangan; $i++): ?>
                        <option value="<?= $i ?>" <?= $selected_nomor === $i ? 'selected' : '' ?>>Lapangan <?= $i ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <button type="submit" class="btn-primary filter-btn"><i class="fa-solid fa-eye"></i> Lihat Jadwal</button>
        </form>

        <div class="schedule-days-wrap">
            <?php foreach($days as $day): ?>
                <?php
                    $booked_ranges = getBookedRangesDetail($pdo, $lapangan['id'], $selected_nomor, $day);
                    $closed_ranges = getClosedRangesDetail($pdo, $lapangan['id'], $selected_nomor, $day);
                    $busy_list = [];
                    foreach ($booked_ranges as $range) {
                        $customer = $range['nama_pelanggan'] ?: $range['username'];
                        $busy_list[] = [
                            'type' => 'booked',
                            'start' => formatJamDetail($range['jam_mulai']),
                            'end' => formatJamDetail($range['jam_selesai']),
                            'label' => (($range['booking_source'] ?? 'online') === 'offline' ? 'Booking offline' : 'Booking online') . ' - ' . $customer,
                        ];
                    }
                    foreach ($closed_ranges as $range) {
                        $busy_list[] = [
                            'type' => 'closed',
                            'start' => formatJamDetail($range['jam_mulai']),
                            'end' => formatJamDetail($range['jam_selesai']),
                            'label' => 'Ditutup admin' . ($range['alasan'] ? ' - ' . $range['alasan'] : ''),
                        ];
                    }
                    usort($busy_list, fn($a, $b) => strcmp($a['start'], $b['start']));
                ?>
                <div class="schedule-day-card">
                    <h3><?= date('d/m/Y', strtotime($day)) ?> <span><?= $day === $today ? 'Hari ini' : date('l', strtotime($day)) ?></span></h3>
                    <div class="mini-slot-grid flexible-mini-grid">
                        <?php for($minute = $jam_buka_min; $minute < $jam_tutup_min; $minute += $interval_timeline): ?>
                            <?php
                                $start = minutesToTimeDetail($minute);
                                $end = minutesToTimeDetail(min($minute + $interval_timeline, $jam_tutup_min));
                                $status = statusForMiniRange($start, $end, $booked_ranges, $closed_ranges);
                            ?>
                            <div class="mini-slot <?= $status['status'] ?>" title="<?= htmlspecialchars(formatJamDetail($start) . ' - ' . formatJamDetail($end) . ' | ' . $status['note']) ?>">
                                <strong><?= formatJamDetail($start) ?></strong>
                            </div>
                        <?php endfor; ?>
                    </div>

                    <div class="blocked-list-box compact-blocked-list">
                        <h4>Jam terisi / tutup</h4>
                        <?php if(count($busy_list) > 0): ?>
                            <div class="blocked-list">
                                <?php foreach($busy_list as $item): ?>
                                    <div class="blocked-item <?= $item['type'] ?>">
                                        <strong><?= htmlspecialchars($item['start']) ?> - <?= htmlspecialchars($item['end']) ?></strong>
                                        <span><?= htmlspecialchars($item['label']) ?></span>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <p class="helper-text">Belum ada booking atau jadwal tutup.</p>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
</body>
</html>
