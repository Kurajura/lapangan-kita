<?php
include 'config/database.php';
if (!isLoggedIn() || getUserRole() !== 'user') {
    header("Location: login.php?error=Silakan login sebagai user terlebih dahulu");
    exit();
}

$user_id = getUserId();
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $display_name = trim($_POST['display_name'] ?? '');
    $bio = trim($_POST['bio'] ?? '');
    $show_rank_badges = isset($_POST['show_rank_badges']) ? 1 : 0;
    $profile_photo = null;

    if ($display_name === '') {
        $error = 'Nama profil tidak boleh kosong';
    } else {
        if (!empty($_FILES['profile_photo']['name']) && $_FILES['profile_photo']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = __DIR__ . '/assets/profiles/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }

            $tmp = $_FILES['profile_photo']['tmp_name'];
            $size = (int) $_FILES['profile_photo']['size'];
            $ext = strtolower(pathinfo($_FILES['profile_photo']['name'], PATHINFO_EXTENSION));
            $allowed = ['jpg', 'jpeg', 'png', 'webp'];
            if (!in_array($ext, $allowed, true)) {
                $error = 'Foto profil hanya boleh JPG, JPEG, PNG, atau WEBP';
            } elseif ($size > 3 * 1024 * 1024) {
                $error = 'Ukuran foto maksimal 3MB';
            } else {
                $profile_photo = time() . '_' . bin2hex(random_bytes(8)) . '.' . $ext;
                move_uploaded_file($tmp, $uploadDir . $profile_photo);
            }
        }

        if ($error === '') {
            if ($profile_photo) {
                $stmt = $pdo->prepare("UPDATE users SET display_name = ?, bio = ?, show_rank_badges = ?, profile_photo = ? WHERE id = ?");
                $stmt->execute([$display_name, $bio, $show_rank_badges, $profile_photo, $user_id]);
            } else {
                $stmt = $pdo->prepare("UPDATE users SET display_name = ?, bio = ?, show_rank_badges = ? WHERE id = ?");
                $stmt->execute([$display_name, $bio, $show_rank_badges, $user_id]);
            }
            $_SESSION['full_name'] = $display_name;
            $success = 'Profil berhasil diperbarui';
        }
    }
}

$stmt = $pdo->prepare("SELECT username, full_name, display_name, bio, profile_photo, show_rank_badges FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();
$display_name_value = $user['display_name'] ?: ($user['full_name'] ?: $user['username']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profil - LapanganKita</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="top-header">
    <div class="promo-box"> Edit Profil <span>PLAYER</span></div>
    <div class="top-right"><div class="user-info"><i class="fa-regular fa-user"></i> <?= htmlspecialchars($_SESSION['username']) ?> <a href="logout.php" style="color:#ff003c;">Logout</a></div></div>
</div>
<?php renderNavbar(''); ?>

<div class="profile-page-wrap">
    <div class="form-card edit-profile-card">
        <h2>Edit Profil Kamu</h2>
        <?php if($error): ?><div class="alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
        <?php if($success): ?><div class="alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>

        <form method="POST" enctype="multipart/form-data" class="profile-edit-form">
            <div class="current-avatar-preview">
                <?php if($user['profile_photo']): ?>
                    <img src="assets/profiles/<?= htmlspecialchars($user['profile_photo']) ?>" alt="Foto Profil">
                <?php else: ?>
                    <i class="fa-regular fa-user"></i>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label>Foto Profil</label>
                <input type="file" name="profile_photo" accept="image/png,image/jpeg,image/webp">
                <small class="small-muted">Maksimal 3MB. Format JPG, PNG, WEBP.</small>
            </div>
            <div class="form-group">
                <label>Nama Profil</label>
                <input type="text" name="display_name" value="<?= htmlspecialchars($display_name_value) ?>" maxlength="100" required>
            </div>
            <div class="form-group">
                <label>Bio</label>
                <textarea name="bio" rows="4" maxlength="500" placeholder="Contoh: Top badminton, suka sparing malam minggu..."><?= htmlspecialchars($user['bio'] ?? '') ?></textarea>
            </div>
            <label class="checkbox-row">
                <input type="checkbox" name="show_rank_badges" value="1" <?= (int)$user['show_rank_badges'] === 1 ? 'checked' : '' ?>>
                Tampilkan lencana Top 10 leaderboard di profil publik
            </label>
            <button type="submit" class="btn-primary"><i class="fa-solid fa-save"></i> Simpan Profil</button>
            <a href="profile.php?id=<?= getUserId() ?>" class="btn-secondary">Lihat Profil Publik</a>
        </form>
    </div>
</div>
</body>
</html>
