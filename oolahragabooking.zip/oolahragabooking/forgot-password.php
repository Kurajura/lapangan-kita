<?php
include 'config/database.php';
$generated_code = '';
$target_email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identity = trim($_POST['identity'] ?? '');
    if ($identity === '') {
        header('Location: forgot-password.php?error=' . urlencode('Masukkan email, username, atau ID pemain'));
        exit();
    }
    $stmt = $pdo->prepare("SELECT id, email, username, player_code FROM users WHERE email = ? OR username = ? OR player_code = ? LIMIT 1");
    $stmt->execute([$identity, $identity, $identity]);
    $user = $stmt->fetch();
    if (!$user) {
        header('Location: forgot-password.php?error=' . urlencode('Akun tidak ditemukan'));
        exit();
    }

    $generated_code = (string)random_int(100000, 999999);
    $target_email = $user['email'];
    $pdo->prepare("UPDATE password_resets SET used = 1 WHERE user_id = ? AND used = 0")->execute([$user['id']]);
    $stmt = $pdo->prepare("INSERT INTO password_resets (user_id, email, reset_code, expires_at) VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL 15 MINUTE))");
    $stmt->execute([$user['id'], $user['email'], $generated_code]);

    $subject = 'Kode Reset Password LapanganKita';
    $message = "Kode reset password kamu: $generated_code. Kode berlaku 15 menit.";
    @mail($user['email'], $subject, $message);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lupa Password - LapanganKita</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="auth-page-wrap login-container">
    <div class="auth-card-wide login-box">
        <h1>Lupa Password</h1>
        <p>Masukkan email, username, atau ID pemain. Sistem akan membuat kode reset 6 angka.</p>
        <?php if(isset($_GET['error'])): ?><div class="alert-error"><?= e($_GET['error']) ?></div><?php endif; ?>
        <?php if($generated_code): ?>
            <div class="alert-success">
                Kode reset untuk <?= e($target_email) ?> adalah <strong><?= e($generated_code) ?></strong>.<br>
                Mode localhost: kode ditampilkan di layar. Kalau server sudah support mail, kode juga dicoba dikirim ke email.
            </div>
            <a href="reset-password.php" class="btn-primary" style="display:inline-flex;margin-bottom:18px;">Input Kode Reset</a>
        <?php endif; ?>
        <form method="POST" class="clean-form">
            <div class="form-group"><label>Email / Username / ID Pemain</label><input type="text" name="identity" required></div>
            <button type="submit" class="btn-primary" style="width:100%;">Buat Kode Reset</button>
        </form>
        <div class="auth-links"><p><a href="login.php">Kembali ke Login</a></p></div>
    </div>
</div>
</body>
</html>
