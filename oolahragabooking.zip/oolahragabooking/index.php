<?php include 'config/database.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>LapanganKita - Sport Modern</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="top-header">
  <div class="promo-box"> Booking Lapangan Olahraga <span>PREMIUM MEMBER</span></div>
  <div class="top-right">
    <?php if(isLoggedIn()): ?>
      <div class="user-info">
        <i class="fa-regular fa-user"></i> <?= $_SESSION['username'] ?>
        <?php if(isSuperAdmin()): ?>
          <span style="background:#ff003c; padding:2px 8px; border-radius:20px; font-size:12px;">Super Admin</span>
        <?php elseif(isAdmin()): ?>
          <span style="background:#00ffb3; padding:2px 8px; border-radius:20px; font-size:12px; color:#000;">Admin</span>
        <?php endif; ?>
        <a href="logout.php" style="color:#ff003c; margin-left:10px;">Logout</a>
      </div>
    <?php else: ?>
      <a href="login.php" class="login-btn"><div class="login-icon"><i class="fa-regular fa-user"></i></div> Login</a>
      <a href="register.php" class="plan-btn">Daftar</a>
    <?php endif; ?>
  </div>
</div>
<?php renderNavbar(''); ?>

<section class="showcase">
  <div class="showcase-bg"></div>
  <div class="showcase-content">
    <h1>Cari Lapangan<br><span>Tracking</span><br>Kemenanganmu</h1>
    <p>PLATFORM BOOKING OLAHRAGA</p>
  </div>
</section>

<section class="intro-layer">
  <div class="intro-bg"></div>
  <div class="intro-overlay"></div>
  <div class="intro-content">
    <div class="intro-badge"> Booking Lapangan Sport Premium</div>
    <h1>Arena Olahraga <span>Modern</span><br>Untuk Semua Pecinta Sport</h1>
    <p>Booking lapangan dengan mudah, berbagai pilihan pembayaran QRIS, E-Wallet, M-Banking, dan tracking riwayat booking lengkap.</p>
    <div class="intro-buttons">
      <a href="booking.php" class="primary-btn">Lihat Lapangan</a>
      <a href="leaderboard.php" class="secondary-btn">Lihat Leaderboard</a>
    </div>
  </div>
</section>

<section class="feature-section">
  <h2>Layanan <span>Kami</span></h2>
  <div class="feature-grid">
    <div class="feature-card">
      <i class="fa-solid fa-calendar-check"></i>
      <h3>Booking Mudah</h3>
      <p>Booking lapangan berbagai olahraga</p>
    </div>
    <div class="feature-card">
      <i class="fa-solid fa-credit-card"></i>
      <h3>Multi Payment</h3>
      <p>QRIS, DANA, OVO, M-Banking</p>
    </div>
    <div class="feature-card">
      <i class="fa-solid fa-users"></i>
      <h3>3 Role User</h3>
      <p>User, Admin Lapangan, Super Admin</p>
    </div>
    <div class="feature-card">
      <i class="fa-solid fa-print"></i>
      <h3>Cetak Struk</h3>
      <p>Cetak bukti transaksi dengan mudah</p>
    </div>
  </div>
</section>
</body>
</html>