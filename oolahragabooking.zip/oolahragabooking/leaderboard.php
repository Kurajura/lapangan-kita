<?php
include 'config/database.php';

$lapangan_id = (int) ($_GET['lapangan_id'] ?? 0);
$lapangan_list = $pdo->query("SELECT id, nama_lapangan, jenis_olahraga, foto FROM lapangan WHERE status = 'aktif' ORDER BY nama_lapangan ASC")->fetchAll();

$selected_lapangan = null;
$leaderboard = [];
if ($lapangan_id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM lapangan WHERE id = ? AND status = 'aktif'");
    $stmt->execute([$lapangan_id]);
    $selected_lapangan = $stmt->fetch();

    if ($selected_lapangan) {
        $stmt = $pdo->prepare("SELECT mr.user_id,
                                      COALESCE(NULLIF(u.display_name, ''), NULLIF(u.full_name, ''), u.username) AS player_name,
                                      u.profile_photo, u.player_code,
                                      COUNT(*) AS total_match,
                                      SUM(CASE WHEN mr.winner = 'user' THEN 1 ELSE 0 END) AS menang,
                                      SUM(CASE WHEN mr.winner = 'draw' THEN 1 ELSE 0 END) AS seri,
                                      SUM(CASE WHEN mr.winner = 'opponent' THEN 1 ELSE 0 END) AS kalah,
                                      SUM(mr.points) AS total_points,
                                      SUM(mr.score_diff) AS total_diff
                               FROM match_results mr
                               JOIN users u ON mr.user_id = u.id
                               WHERE mr.lapangan_id = ?
                               GROUP BY mr.user_id, player_name, u.profile_photo, u.player_code
                               ORDER BY total_points DESC, menang DESC, total_diff DESC, total_match DESC, player_name ASC");
        $stmt->execute([$lapangan_id]);
        $leaderboard = $stmt->fetchAll();
    }
}

if (!$selected_lapangan && count($lapangan_list) > 0) {
    $selected_lapangan = null;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leaderboard - LapanganKita</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="top-header">
    <div class="promo-box"> Leaderboard <span>MODE TANDING</span></div>
    <div class="top-right">
        <?php if(isLoggedIn()): ?>
            <div class="user-info"><i class="fa-regular fa-user"></i> <?= htmlspecialchars($_SESSION['username']) ?> <a href="logout.php" style="color:#ff003c;">Logout</a></div>
        <?php else: ?>
            <a href="login.php" class="login-btn"><div class="login-icon"><i class="fa-regular fa-user"></i></div> Login</a>
            <a href="register.php" class="plan-btn">Daftar</a>
        <?php endif; ?>
    </div>
</div>
<?php renderNavbar(''); ?>

<div class="page-header">
    <h1>Leaderboard Lapangan</h1>
    <p>Peringkat dihitung dari hasil mode tanding yang sudah diinput admin lapangan.</p>
</div>

<div class="public-page-wrap">
    <div class="leaderboard-filter-grid">
        <?php foreach($lapangan_list as $lap): ?>
            <a class="leaderboard-field-card <?= $lapangan_id === (int)$lap['id'] ? 'active' : '' ?>" href="leaderboard.php?lapangan_id=<?= $lap['id'] ?>">
                <div class="leaderboard-field-thumb">
                    <?php if($lap['foto']): ?>
                        <img src="assets/uploads/<?= htmlspecialchars($lap['foto']) ?>" alt="<?= htmlspecialchars($lap['nama_lapangan']) ?>">
                    <?php else: ?>
                        <i class="fa-solid fa-futbol"></i>
                    <?php endif; ?>
                </div>
                <div>
                    <strong><?= htmlspecialchars($lap['nama_lapangan']) ?></strong>
                    <span><?= htmlspecialchars($lap['jenis_olahraga']) ?></span>
                </div>
            </a>
        <?php endforeach; ?>
    </div>

    <div class="form-card leaderboard-card">
        <?php if(!$selected_lapangan): ?>
            <h2>Pilih Lapangan</h2>
            <p class="helper-text">Klik salah satu lapangan di atas untuk melihat susunan leaderboard.</p>
        <?php else: ?>
            <h2>Leaderboard <?= htmlspecialchars($selected_lapangan['nama_lapangan']) ?></h2>
            <p class="helper-text">Urutan: poin tertinggi, jumlah menang, selisih skor, lalu total pertandingan.</p>
            <div class="table-responsive">
                <table class="data-table leaderboard-table">
                    <thead>
                        <tr>
                            <th>Rank</th>
                            <th>Pemain</th>
                            <th>Main</th>
                            <th>Menang</th>
                            <th>Seri</th>
                            <th>Kalah</th>
                            <th>Selisih</th>
                            <th>Poin</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($leaderboard as $i => $row): ?>
                        <tr>
                            <td><span class="rank-pill rank-<?= $i + 1 <= 3 ? $i + 1 : 'other' ?>">#<?= $i + 1 ?></span></td>
                            <td>
                                <a class="player-cell" href="profile.php?id=<?= $row['user_id'] ?>">
                                    <span class="profile-mini-avatar">
                                        <?php if($row['profile_photo']): ?>
                                            <img src="assets/profiles/<?= htmlspecialchars($row['profile_photo']) ?>" alt="Profil">
                                        <?php else: ?>
                                            <i class="fa-regular fa-user"></i>
                                        <?php endif; ?>
                                    </span>
                                    <?= e($row['player_name']) ?> <small class="small-muted">ID <?= e($row['player_code'] ?? '-') ?></small>
                                </a>
                            </td>
                            <td><?= (int)$row['total_match'] ?></td>
                            <td><?= (int)$row['menang'] ?></td>
                            <td><?= (int)$row['seri'] ?></td>
                            <td><?= (int)$row['kalah'] ?></td>
                            <td><?= (int)$row['total_diff'] ?></td>
                            <td><strong><?= (int)$row['total_points'] ?></strong></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(count($leaderboard) === 0): ?>
                        <tr><td colspan="8" style="text-align:center;">Belum ada hasil pertandingan untuk lapangan ini.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
