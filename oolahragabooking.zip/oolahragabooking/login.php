<?php
include 'config/database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? OR email = ? OR player_code = ?");
    $stmt->execute([$username, $username, $username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['full_name'] = $user['full_name'];
        $_SESSION['player_code'] = $user['player_code'] ?? '';

        if ($user['role'] == 'super_admin') {
            header("Location: superadmin/dashboard.php");
        } elseif ($user['role'] == 'admin') {
            header("Location: admin/dashboard.php");
        } else {
            header("Location: user/dashboard.php");
        }
        exit();
    } else {
        header("Location: login.php?error=Username, ID pemain, email, atau password salah");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - LapanganKita</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="login-container auth-page-wrap">
    <div class="login-box auth-card-wide">
        <h1>Login</h1>
        <p>Masuk pakai username, email, atau ID pemain 6 angka.</p>

        <?php if(isset($_GET['error'])): ?><div class="alert-error"><?= e($_GET['error']) ?></div><?php endif; ?>
        <?php if(isset($_GET['success'])): ?><div class="alert-success"><?= e($_GET['success']) ?></div><?php endif; ?>

        <form method="POST" action="" class="clean-form">
            <div class="form-group"><label>Username / Email / ID Pemain</label><input type="text" name="username" required></div>
            <div class="form-group"><label>Password</label><input type="password" name="password" required></div>
            <button type="submit" class="login-btn-submit">Login</button>
        </form>
        <div class="register-link auth-links">
            <p><a href="forgot-password.php">Lupa password?</a></p>
            <p>Belum punya akun? <a href="register.php">Daftar Pemain</a></p>
            <p>Punya lapangan? <a href="daftar-admin.php">Daftar Admin Lapangan</a></p>
        </div>
    </div>
</div>
</body>
</html>
