<?php
include 'config/database.php';
$q = trim($_GET['q'] ?? '');
$category = trim($_GET['category'] ?? '');
$where = ["p.status = 'active'"];
$params = [];
if ($q !== '') {
    $where[] = "(p.product_name LIKE ? OR p.description LIKE ? OR p.category LIKE ? OR u.username LIKE ? OR u.display_name LIKE ? OR u.full_name LIKE ?)";
    $like = '%' . $q . '%';
    array_push($params, $like, $like, $like, $like, $like, $like);
}
if ($category !== '') {
    $where[] = "p.category = ?";
    $params[] = $category;
}
$sql = "SELECT p.*, u.username, u.player_code, u.role,
               COALESCE(NULLIF(u.display_name,''), NULLIF(u.full_name,''), u.username) AS seller_name,
               COALESCE(AVG(pr.rating),0) AS avg_rating,
               COUNT(pr.id) AS review_count
        FROM products p
        JOIN users u ON p.seller_id = u.id
        LEFT JOIN product_reviews pr ON pr.product_id = p.id
        WHERE " . implode(' AND ', $where) . "
        GROUP BY p.id
        ORDER BY p.created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();
$categories = $pdo->query("SELECT DISTINCT category FROM products WHERE category IS NOT NULL AND category<>'' ORDER BY category ASC")->fetchAll(PDO::FETCH_COLUMN);
$canSell = isLoggedIn() && canSellProduct($pdo, getUserId(), getUserRole());
?>
<!DOCTYPE html><html lang="id"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Jual Beli Barang Olahraga - LapanganKita</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"><link rel="stylesheet" href="assets/css/style.css">
</head><body>
<div class="top-header"><div class="promo-box">Jual Beli Barang Olahraga <span>MARKET</span></div><div class="top-right"><?php if(isLoggedIn()): ?><div class="user-info"><i class="fa-regular fa-user"></i> <?= e($_SESSION['username']) ?> <a href="logout.php" style="color:#ff003c;">Logout</a></div><?php else: ?><a href="login.php" class="login-btn"><div class="login-icon"><i class="fa-regular fa-user"></i></div> Login</a><a href="register.php" class="plan-btn">Daftar</a><?php endif; ?></div></div>
<?php renderNavbar(''); ?>
<div class="public-page-wrap">
    <div class="form-card">
        <div class="booking-board-head"><div><h2>Market Barang Olahraga</h2><p>User bisa jualan kalau VIP. Admin lapangan boleh jualan tanpa VIP. Pembeli barang tidak wajib VIP.</p></div><div class="market-actions"><?php if($canSell): ?><a class="btn-primary" href="product-form.php"><i class="fa-solid fa-plus"></i> Jual Barang</a><a class="btn-secondary" href="my-products.php">Produk Saya</a><?php elseif(isLoggedIn()): ?><a class="btn-primary" href="vip.php">Aktifkan VIP untuk Jualan</a><?php else: ?><a class="btn-primary" href="login.php?error=Login dulu untuk jualan">Login untuk Jualan</a><?php endif; ?></div></div>
        <?php if(isset($_GET['success'])): ?><div class="alert-success"><?= e($_GET['success']) ?></div><?php endif; ?>
        <?php if(isset($_GET['error'])): ?><div class="alert-error"><?= e($_GET['error']) ?></div><?php endif; ?>
        <form class="market-filter" method="GET">
            <div><label>Cari barang / penjual</label><input type="text" name="q" value="<?= e($q) ?>" placeholder="Contoh: raket, sepatu futsal, bola"></div>
            <div><label>Kategori</label><select name="category"><option value="">Semua kategori</option><?php foreach($categories as $cat): ?><option value="<?= e($cat) ?>" <?= $category===$cat?'selected':'' ?>><?= e($cat) ?></option><?php endforeach; ?></select></div>
            <button class="btn-primary"><i class="fa-solid fa-magnifying-glass"></i> Cari</button>
        </form>
    </div>

    <div class="market-grid">
        <?php foreach($products as $p): ?>
        <div class="product-card">
            <?php if($p['photo']): ?><img src="assets/products/<?= e($p['photo']) ?>" alt="<?= e($p['product_name']) ?>"><?php else: ?><div class="product-empty-image"><i class="fa-solid fa-dumbbell"></i></div><?php endif; ?>
            <h3><?= e($p['product_name']) ?></h3>
            <div class="product-price">Rp <?= number_format($p['price'],0,',','.') ?></div>
            <div class="product-meta"><span><?= e($p['category'] ?: 'Umum') ?></span><span>Stok <?= (int)$p['stock'] ?></span><span><?= starRatingHtml($p['avg_rating']) ?> <?= number_format((float)$p['avg_rating'],1) ?> (<?= (int)$p['review_count'] ?>)</span></div>
            <p class="helper-text"><?= e(mb_substr($p['description'] ?: 'Belum ada deskripsi.',0,90)) ?><?= mb_strlen($p['description'] ?: '')>90?'...':'' ?></p>
            <div class="product-meta"><span>Penjual: <?= e($p['seller_name']) ?></span><?php if($p['role']==='admin'): ?><span class="badge-vip"><i class="fa-solid fa-crown"></i> Admin Lapangan</span><?php endif; ?></div>
            <div class="market-actions"><a class="btn-primary small-btn" href="product-detail.php?id=<?= (int)$p['id'] ?>">Detail</a></div>
        </div>
        <?php endforeach; ?>
        <?php if(!$products): ?><div class="form-card"><p class="helper-text">Belum ada barang yang cocok.</p></div><?php endif; ?>
    </div>
</div>
</body></html>
