<?php
include 'config/database.php';
if (!isLoggedIn() || getUserRole() !== 'user') {
    header('Location: login.php?error=Silakan login sebagai user terlebih dahulu');
    exit();
}
function goInv($message, $type='success') {
    header('Location: match-invitations.php?' . $type . '=' . urlencode($message));
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action_type = $_POST['action_type'] ?? 'solo_invite';
    $action = $_POST['action'] ?? '';
    if (!in_array($action, ['accepted','rejected'], true)) goInv('Aksi tidak valid', 'error');

    if ($action_type === 'solo_invite') {
        $participant_id = (int)($_POST['participant_id'] ?? 0);
        $stmt = $pdo->prepare("SELECT mp.*, b.user_id AS owner_id FROM match_participants mp JOIN bookings b ON mp.booking_id = b.id WHERE mp.id = ? AND mp.user_id = ? AND mp.status = 'pending'");
        $stmt->execute([$participant_id, getUserId()]);
        $participant = $stmt->fetch();
        if (!$participant) goInv('Undangan tidak ditemukan atau sudah diproses', 'error');
        $pdo->prepare("UPDATE match_participants SET status = ?, responded_at = NOW() WHERE id = ? AND user_id = ?")->execute([$action, $participant_id, getUserId()]);
        evaluateMatchApproval($pdo, $participant['booking_id']);
        goInv($action === 'accepted' ? 'Undangan tanding berhasil diterima' : 'Undangan tanding berhasil ditolak');
    }

    if ($action_type === 'team_member') {
        $member_id = (int)($_POST['member_id'] ?? 0);
        $stmt = $pdo->prepare("SELECT tm.*, t.team_name, t.captain_id FROM team_members tm JOIN teams t ON tm.team_id = t.id WHERE tm.id = ? AND tm.user_id = ? AND tm.status = 'pending'");
        $stmt->execute([$member_id, getUserId()]);
        $member = $stmt->fetch();
        if (!$member) goInv('Undangan team tidak ditemukan atau sudah diproses', 'error');
        $pdo->prepare("UPDATE team_members SET status = ?, responded_at = NOW() WHERE id = ? AND user_id = ?")->execute([$action, $member_id, getUserId()]);
        evaluateTeamApproval($pdo, $member['team_id']);
        createNotification($pdo, (int)$member['captain_id'], 'Respon anggota team', $_SESSION['username'] . ' ' . ($action === 'accepted' ? 'menerima' : 'menolak') . ' undangan team ' . $member['team_name'] . '.', 'team-tanding.php?booking_id=' . (int)($_POST['booking_id'] ?? 0));
        goInv($action === 'accepted' ? 'Undangan team berhasil diterima' : 'Undangan team berhasil ditolak');
    }

    if ($action_type === 'team_request') {
        $request_id = (int)($_POST['request_id'] ?? 0);
        $stmt = $pdo->prepare("SELECT tr.*, b.lapangan_id, b.nomor_lapangan, b.user_id AS booking_owner_id, b.booking_code, l.nama_lapangan, l.admin_id,
                                      t1.team_name AS team1_name, t2.team_name AS team2_name, t2.captain_id AS opponent_captain_id
                               FROM team_match_requests tr
                               JOIN bookings b ON tr.booking_id = b.id
                               JOIN lapangan l ON b.lapangan_id = l.id
                               JOIN teams t1 ON tr.requester_team_id = t1.id
                               JOIN teams t2 ON tr.opponent_team_id = t2.id
                               WHERE tr.id = ? AND tr.status = 'pending' AND t2.captain_id = ?");
        $stmt->execute([$request_id, getUserId()]);
        $req = $stmt->fetch();
        if (!$req) goInv('Tantangan team tidak ditemukan atau sudah diproses', 'error');
        try {
            $pdo->beginTransaction();
            $pdo->prepare("UPDATE team_match_requests SET status=?, responded_by=?, responded_at=NOW() WHERE id=?")->execute([$action, getUserId(), $request_id]);
            if ($action === 'accepted') {
                populateMatchParticipantsFromTeams($pdo, $req['booking_id'], $req['requester_team_id'], $req['opponent_team_id'], $req['requester_user_id']);
                $pdo->prepare("UPDATE bookings SET match_status='waiting_score', match_rejected_reason=NULL, match_opponent_name=? WHERE id=?")->execute([$req['team2_name'], $req['booking_id']]);
                createNotification($pdo, (int)$req['booking_owner_id'], 'Tantangan team diterima', 'Team ' . $req['team2_name'] . ' menerima tantangan. Pertandingan siap dimainkan.', 'riwayat.php');
                createNotification($pdo, (int)$req['admin_id'], 'Mode tanding team siap dicatat', 'Pertandingan ' . $req['team1_name'] . ' vs ' . $req['team2_name'] . ' di ' . $req['nama_lapangan'] . ' sudah disetujui. Input skor setelah pertandingan.', 'admin/bookings.php');
            } else {
                $reason = 'Team ' . $req['team2_name'] . ' menolak tantangan. Silakan pilih team lawan lain.';
                $pdo->prepare("UPDATE bookings SET match_status='rejected', match_rejected_reason=? WHERE id=?")->execute([$reason, $req['booking_id']]);
                createNotification($pdo, (int)$req['booking_owner_id'], 'Tantangan team ditolak', $reason, 'team-tanding.php?booking_id=' . (int)$req['booking_id']);
            }
            $pdo->commit();
            goInv($action === 'accepted' ? 'Tantangan team berhasil diterima' : 'Tantangan team berhasil ditolak');
        } catch (Exception $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            goInv('Gagal memproses tantangan team: ' . $e->getMessage(), 'error');
        }
    }
}

$stmt = $pdo->prepare("SELECT mp.*, b.booking_code, b.tanggal, b.jam_mulai, b.jam_selesai, b.match_type, b.match_status, l.nama_lapangan, l.jenis_olahraga,
                              owner.username AS owner_username, COALESCE(NULLIF(owner.display_name,''), NULLIF(owner.full_name,''), owner.username) AS owner_name
                       FROM match_participants mp
                       JOIN bookings b ON mp.booking_id = b.id
                       JOIN lapangan l ON b.lapangan_id = l.id
                       JOIN users owner ON b.user_id = owner.id
                       WHERE mp.user_id = ? AND mp.team = 'opponent' AND b.match_type = 'solo'
                       ORDER BY mp.status = 'pending' DESC, mp.created_at DESC");
$stmt->execute([getUserId()]);
$soloInvites = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT tm.*, t.team_name, t.team_code, t.created_by_booking_id, t.jenis_olahraga,
                              cap.username AS captain_username, COALESCE(NULLIF(cap.display_name,''), NULLIF(cap.full_name,''), cap.username) AS captain_name
                       FROM team_members tm
                       JOIN teams t ON tm.team_id = t.id
                       JOIN users cap ON t.captain_id = cap.id
                       WHERE tm.user_id = ? AND tm.is_captain = 0
                       ORDER BY tm.status = 'pending' DESC, tm.created_at DESC");
$stmt->execute([getUserId()]);
$teamInvites = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT tr.*, b.booking_code, b.tanggal, b.jam_mulai, b.jam_selesai, l.nama_lapangan, l.jenis_olahraga,
                              t1.team_name AS requester_team_name, t1.team_code AS requester_team_code,
                              t2.team_name AS opponent_team_name, t2.team_code AS opponent_team_code,
                              u.username AS requester_username, COALESCE(NULLIF(u.display_name,''), NULLIF(u.full_name,''), u.username) AS requester_name
                       FROM team_match_requests tr
                       JOIN bookings b ON tr.booking_id = b.id
                       JOIN lapangan l ON b.lapangan_id = l.id
                       JOIN teams t1 ON tr.requester_team_id = t1.id
                       JOIN teams t2 ON tr.opponent_team_id = t2.id
                       JOIN users u ON tr.requester_user_id = u.id
                       WHERE t2.captain_id = ?
                       ORDER BY tr.status = 'pending' DESC, tr.created_at DESC");
$stmt->execute([getUserId()]);
$teamRequests = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Undangan Tanding - LapanganKita</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"><link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="top-header"><div class="promo-box">Undangan Tanding <span>APPROVAL</span></div><div class="top-right"><div class="user-info"><i class="fa-regular fa-user"></i> <?= e($_SESSION['username']) ?> <a href="logout.php" style="color:#ff003c;">Logout</a></div></div></div>
<?php renderNavbar(''); ?>
<div class="public-page-wrap">
    <div class="form-card">
        <h2>Undangan Mode Tanding</h2>
        <p class="helper-text">Solo butuh persetujuan lawan. Team butuh persetujuan anggota team dan captain team lawan.</p>
        <?php if(isset($_GET['success'])): ?><div class="alert-success"><?= e($_GET['success']) ?></div><?php endif; ?>
        <?php if(isset($_GET['error'])): ?><div class="alert-error"><?= e($_GET['error']) ?></div><?php endif; ?>
    </div>

    <div class="form-card"><h2>Undangan Solo / Single</h2><div class="invite-list">
        <?php foreach($soloInvites as $invite): ?>
            <div class="invite-card"><div><span class="match-badge <?= $invite['status']==='pending'?'waiting':($invite['status']==='accepted'?'completed':'rejected') ?>"><?= e(ucfirst($invite['status'])) ?></span><h3><?= e($invite['nama_lapangan']) ?> - <?= e(ucwords($invite['jenis_olahraga'])) ?></h3><p>Diundang oleh <strong><?= e($invite['owner_name']) ?></strong> untuk mode <?= e($invite['match_type']) ?>.</p><small><?= date('d/m/Y', strtotime($invite['tanggal'])) ?>, <?= substr($invite['jam_mulai'],0,5) ?> - <?= substr($invite['jam_selesai'],0,5) ?> | Booking <?= e($invite['booking_code']) ?></small></div>
            <?php if($invite['status'] === 'pending'): ?><form method="POST" class="invite-actions"><input type="hidden" name="action_type" value="solo_invite"><input type="hidden" name="participant_id" value="<?= (int)$invite['id'] ?>"><button name="action" value="accepted" class="btn-primary small-btn">Terima</button><button name="action" value="rejected" class="btn-danger small-btn" onclick="return confirm('Tolak undangan tanding ini?')">Tolak</button></form><?php endif; ?></div>
        <?php endforeach; ?>
        <?php if(count($soloInvites)===0): ?><p class="helper-text">Belum ada undangan solo.</p><?php endif; ?>
    </div></div>

    <div class="form-card"><h2>Undangan Masuk Team</h2><div class="invite-list">
        <?php foreach($teamInvites as $invite): ?>
            <div class="invite-card"><div><span class="match-badge <?= $invite['status']==='pending'?'waiting':($invite['status']==='accepted'?'completed':'rejected') ?>"><?= e(ucfirst($invite['status'])) ?></span><h3><?= e($invite['team_name']) ?> <small><?= e($invite['team_code']) ?></small></h3><p>Captain: <strong><?= e($invite['captain_name']) ?></strong> | Olahraga: <?= e($invite['jenis_olahraga'] ?: '-') ?></p></div>
            <?php if($invite['status'] === 'pending'): ?><form method="POST" class="invite-actions"><input type="hidden" name="action_type" value="team_member"><input type="hidden" name="member_id" value="<?= (int)$invite['id'] ?>"><input type="hidden" name="booking_id" value="<?= (int)$invite['created_by_booking_id'] ?>"><button name="action" value="accepted" class="btn-primary small-btn">Terima</button><button name="action" value="rejected" class="btn-danger small-btn" onclick="return confirm('Tolak masuk team ini?')">Tolak</button></form><?php endif; ?></div>
        <?php endforeach; ?>
        <?php if(count($teamInvites)===0): ?><p class="helper-text">Belum ada undangan team.</p><?php endif; ?>
    </div></div>

    <div class="form-card"><h2>Tantangan Team Lawan</h2><div class="invite-list">
        <?php foreach($teamRequests as $req): ?>
            <div class="invite-card"><div><span class="match-badge <?= $req['status']==='pending'?'waiting':($req['status']==='accepted'?'completed':'rejected') ?>"><?= e(ucfirst($req['status'])) ?></span><h3><?= e($req['requester_team_name']) ?> vs <?= e($req['opponent_team_name']) ?></h3><p><strong><?= e($req['requester_name']) ?></strong> menantang team kamu di <?= e($req['nama_lapangan']) ?>.</p><small><?= date('d/m/Y', strtotime($req['tanggal'])) ?>, <?= substr($req['jam_mulai'],0,5) ?> - <?= substr($req['jam_selesai'],0,5) ?> | Booking <?= e($req['booking_code']) ?></small></div>
            <?php if($req['status'] === 'pending'): ?><form method="POST" class="invite-actions"><input type="hidden" name="action_type" value="team_request"><input type="hidden" name="request_id" value="<?= (int)$req['id'] ?>"><button name="action" value="accepted" class="btn-primary small-btn">Terima Tantangan</button><button name="action" value="rejected" class="btn-danger small-btn" onclick="return confirm('Tolak tantangan team ini?')">Tolak</button></form><?php endif; ?></div>
        <?php endforeach; ?>
        <?php if(count($teamRequests)===0): ?><p class="helper-text">Belum ada tantangan team.</p><?php endif; ?>
    </div></div>
</div>
</body></html>
