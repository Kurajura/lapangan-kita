<?php
include 'config/database.php';
if (!isLoggedIn()) { header('Location: login.php'); exit(); }
function backMine($msg,$type='success'){ header('Location: my-products.php?'.$type.'='.urlencode($msg)); exit(); }
if (isset($_POST['update_product'])) {
    $id=(int)$_POST['product_id']; $status=$_POST['status'] ?? 'active'; $stock=max(0,(int)($_POST['stock'] ?? 0));
    if(!in_array($status,['active','inactive','sold_out'],true)) backMine('Status tidak valid','error');
    $stmt=$pdo->prepare("UPDATE products SET status=?, stock=? WHERE id=? AND seller_id=?");
    $stmt->execute([$status,$stock,$id,getUserId()]);
    backMine('Produk berhasil diupdate');
}
if (isset($_GET['delete'])) {
    $stmt=$pdo->prepare("UPDATE products SET status='inactive' WHERE id=? AND seller_id=?");
    $stmt->execute([(int)$_GET['delete'],getUserId()]);
    backMine('Produk dinonaktifkan');
}
$stmt=$pdo->prepare("SELECT p.*, COALESCE(AVG(pr.rating),0) avg_rating, COUNT(pr.id) review_count FROM products p LEFT JOIN product_reviews pr ON pr.product_id=p.id WHERE p.seller_id=? GROUP BY p.id ORDER BY p.created_at DESC");
$stmt->execute([getUserId()]);
$products=$stmt->fetchAll();
?>
<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Produk Saya</title><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"><link rel="stylesheet" href="assets/css/style.css"></head><body>
<div class="top-header"><div class="promo-box">Produk Saya <span>MARKET</span></div><div class="top-right"><div class="user-info"><i class="fa-regular fa-user"></i> <?= e($_SESSION['username']) ?> <a href="logout.php" style="color:#ff003c;">Logout</a></div></div></div><?php renderNavbar(''); ?>
<div class="public-page-wrap"><div class="form-card"><h2>Kelola Produk Saya</h2><?php if(isset($_GET['success'])): ?><div class="alert-success"><?= e($_GET['success']) ?></div><?php endif; ?><?php if(isset($_GET['error'])): ?><div class="alert-error"><?= e($_GET['error']) ?></div><?php endif; ?><div class="market-actions"><a class="btn-primary" href="product-form.php">Tambah Produk</a><a class="btn-secondary" href="marketplace.php">Lihat Market</a></div></div>
<div class="form-card"><div class="table-responsive"><table class="data-table"><thead><tr><th>Barang</th><th>Kategori</th><th>Harga</th><th>Stok</th><th>Rating</th><th>Status</th><th>Aksi</th></tr></thead><tbody><?php foreach($products as $p): ?><tr><td><strong><?= e($p['product_name']) ?></strong><br><small><?= date('d/m/Y H:i',strtotime($p['created_at'])) ?></small></td><td><?= e($p['category'] ?: '-') ?></td><td>Rp <?= number_format($p['price'],0,',','.') ?></td><td><form method="POST" style="display:flex;gap:8px;flex-wrap:wrap"><input type="hidden" name="product_id" value="<?= (int)$p['id'] ?>"><input type="number" name="stock" value="<?= (int)$p['stock'] ?>" min="0" style="max-width:90px"></td><td><?= starRatingHtml($p['avg_rating']) ?> <?= number_format((float)$p['avg_rating'],1) ?> (<?= (int)$p['review_count'] ?>)</td><td><select name="status" class="status-select"><option value="active" <?= $p['status']==='active'?'selected':'' ?>>Aktif</option><option value="inactive" <?= $p['status']==='inactive'?'selected':'' ?>>Nonaktif</option><option value="sold_out" <?= $p['status']==='sold_out'?'selected':'' ?>>Sold Out</option></select></td><td class="action-cell"><button name="update_product" value="1" class="btn-primary small-btn">Update</button></form><a class="btn-secondary small-btn" href="product-detail.php?id=<?= (int)$p['id'] ?>">Detail</a><a class="btn-danger small-btn" href="?delete=<?= (int)$p['id'] ?>" onclick="return confirm('Nonaktifkan produk ini?')">Nonaktifkan</a></td></tr><?php endforeach; ?><?php if(!$products): ?><tr><td colspan="7" style="text-align:center">Belum ada produk.</td></tr><?php endif; ?></tbody></table></div></div></div></body></html>
