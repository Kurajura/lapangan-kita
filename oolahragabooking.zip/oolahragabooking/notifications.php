<?php
include 'config/database.php';
if (!isLoggedIn()) {
    header('Location: login.php?error=Silakan login terlebih dahulu');
    exit();
}

if (isset($_POST['mark_read'])) {
    $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?");
    $stmt->execute([getUserId()]);
    header('Location: notifications.php');
    exit();
}

$stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 100");
$stmt->execute([getUserId()]);
$notifications = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifikasi - LapanganKita</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="top-header"><div class="promo-box">Notifikasi <span>PLAYER</span></div><div class="top-right"><div class="user-info"><i class="fa-regular fa-user"></i> <?= e($_SESSION['username']) ?> <a href="logout.php" style="color:#ff003c;">Logout</a></div></div></div>
<?php renderNavbar(''); ?>
<div class="public-page-wrap">
    <div class="form-card">
        <div class="booking-board-head"><div><h2>Notifikasi Kamu</h2><p class="helper-text">Pesan sistem seperti undangan tanding, persetujuan, dan penolakan.</p></div><form method="POST"><button class="btn-secondary small-btn" name="mark_read" value="1">Tandai Semua Dibaca</button></form></div>
        <div class="notification-list">
            <?php foreach($notifications as $n): ?>
                <a class="notification-item <?= (int)$n['is_read'] === 0 ? 'unread' : '' ?>" href="<?= e($n['link'] ?: 'notifications.php') ?>">
                    <strong><?= e($n['title']) ?></strong>
                    <span><?= e($n['message']) ?></span>
                    <small><?= date('d/m/Y H:i', strtotime($n['created_at'])) ?></small>
                </a>
            <?php endforeach; ?>
            <?php if(count($notifications) === 0): ?><p class="helper-text">Belum ada notifikasi.</p><?php endif; ?>
        </div>
    </div>
</div>
</body>
</html>
