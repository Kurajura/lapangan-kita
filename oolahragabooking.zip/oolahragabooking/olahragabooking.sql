-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 02, 2026 at 11:28 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `olahragabooking`
--
CREATE DATABASE IF NOT EXISTS `olahragabooking` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `olahragabooking`;


-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `lapangan_id` int(11) NOT NULL,
  `nomor_lapangan` int(11) NOT NULL DEFAULT 1,
  `tanggal` date NOT NULL,
  `jam_mulai` time NOT NULL,
  `jam_selesai` time NOT NULL,
  `total_harga` decimal(10,2) NOT NULL,
  `status` enum('pending','paid','confirmed','cancelled') DEFAULT 'pending',
  `payment_method` varchar(50) DEFAULT NULL,
  `payment_status` enum('unpaid','paid') DEFAULT 'unpaid',
  `payment_proof` varchar(255) DEFAULT NULL,
  `booking_code` varchar(20) DEFAULT NULL,
  `booking_source` enum('online','offline') NOT NULL DEFAULT 'online',
  `nama_pelanggan` varchar(100) DEFAULT NULL,
  `telepon_pelanggan` varchar(20) DEFAULT NULL,
  `catatan` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `user_id`, `lapangan_id`, `nomor_lapangan`, `tanggal`, `jam_mulai`, `jam_selesai`, `total_harga`, `status`, `payment_method`, `payment_status`, `payment_proof`, `booking_code`, `booking_source`, `nama_pelanggan`, `telepon_pelanggan`, `catatan`, `created_at`) VALUES
(9, 8, 6, 1, '2026-06-03', '07:00:00', '08:00:00', 50000.00, 'confirmed', NULL, 'paid', NULL, 'BK202606024901', 'online', NULL, NULL, NULL, '2026-06-02 21:16:49'),
(10, 10, 6, 1, '2026-06-03', '06:00:00', '07:00:00', 50000.00, 'confirmed', NULL, 'paid', NULL, 'BK202606029367', 'online', NULL, NULL, NULL, '2026-06-02 21:17:45');

-- --------------------------------------------------------

--
-- Table structure for table `lapangan`
--

CREATE TABLE `lapangan` (
  `id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `nama_lapangan` varchar(100) NOT NULL,
  `jenis_olahraga` varchar(50) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `harga_per_jam` decimal(10,2) NOT NULL,
  `jumlah_lapangan` int(11) NOT NULL DEFAULT 1,
  `foto` varchar(255) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `status` enum('aktif','nonaktif') DEFAULT 'aktif',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lapangan`
--

INSERT INTO `lapangan` (`id`, `admin_id`, `nama_lapangan`, `jenis_olahraga`, `deskripsi`, `harga_per_jam`, `jumlah_lapangan`, `foto`, `alamat`, `status`, `created_at`) VALUES
(1, 4, 'lapangan futsal jaya', 'futsal', 'bermain futsal dengan kualitas mantap', 50000.00, 1, '1779231671_704747b12b4e21c03599a8429da2b8b4.jpg', 'jakarta', 'aktif', '2026-05-19 23:01:11'),
(3, 4, 'badminton indor senayan', 'badminton', 'badminton', 35000.00, 2, '1779238023_0cc0f6c8f3a0faa36ed7f941c70f9241.jpg', 'senayan', 'aktif', '2026-05-20 00:47:03'),
(5, 4, 'badminton', 'badminton', 'buka jam 08.00 - 03.00 am\r\nperalatan lengkap , fasilatak ok', 40000.00, 2, '1779240434_10116cc6bf87df122824d71db05391bd.jpg', 'jln.cendrawasih', 'aktif', '2026-05-20 01:27:14'),
(6, 9, 'tennis out door jln senayan', 'tennis', '', 50000.00, 1, '1779241345_fafa31b0eb6bff20650be9f5b301820c.jpg', 'jln senayan', 'aktif', '2026-05-20 01:42:25');

-- --------------------------------------------------------

--
-- Table structure for table `lapangan_tutup`
--

CREATE TABLE `lapangan_tutup` (
  `id` int(11) NOT NULL,
  `lapangan_id` int(11) NOT NULL,
  `nomor_lapangan` int(11) NOT NULL DEFAULT 1,
  `tanggal` date NOT NULL,
  `jam_mulai` time NOT NULL,
  `jam_selesai` time NOT NULL,
  `alasan` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lapangan_tutup`
--


-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `booking_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `payment_channel` varchar(50) DEFAULT NULL,
  `qr_code` text DEFAULT NULL,
  `transaction_code` varchar(50) DEFAULT NULL,
  `status` enum('pending','success','failed','cancelled') DEFAULT 'pending',
  `payment_date` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `booking_id`, `user_id`, `amount`, `payment_method`, `payment_channel`, `qr_code`, `transaction_code`, `status`, `payment_date`, `created_at`) VALUES
(10, 9, 8, 50000.00, 'qris', 'QRIS', '{\"transaction_code\":\"TRX20260602231652258\",\"amount\":\"50000.00\",\"method\":\"qris\",\"channel\":\"QRIS\"}', 'TRX20260602231652258', 'success', '2026-06-02 21:16:53', '2026-06-02 21:16:52'),
(11, 10, 10, 50000.00, 'qris', 'QRIS', '{\"transaction_code\":\"TRX20260602231748775\",\"amount\":\"50000.00\",\"method\":\"qris\",\"channel\":\"QRIS\"}', 'TRX20260602231748775', 'success', '2026-06-02 21:17:49', '2026-06-02 21:17:48');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `display_name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `profile_photo` varchar(255) DEFAULT NULL,
  `show_rank_badges` tinyint(1) NOT NULL DEFAULT 1,
  `role` enum('user','admin','super_admin') DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `full_name`, `phone`, `role`, `created_at`) VALUES
(1, 'superadmin', 'superadmin@lapangankita.com', '$2y$10$YourHashedPasswordHere', 'Super Admin', NULL, 'super_admin', '2026-05-19 22:04:19'),
(3, 'agif', 'yusufbro3030@gmail.com', '$2y$10$QIHP8p8vQUqsKe38mlo5PeOkFem1/sWTRXzn9fcxezoElpFaBPbOm', 'agif', '083161423128', 'user', '2026-05-19 22:22:15'),
(4, 'zero', 'kukukaki.3019@gmail.com', '$2y$10$EANhX5UKOQqHRa4oqkW0j.uKU3BAMN37i7AKNTKSlQKOZiIg4PuMy', 'ziro', '083161423128', 'admin', '2026-05-19 22:24:30'),
(5, 'axel', 'pirmando.2005@gmail.com', '$2y$10$mu9JBVJARhfk/M6i4zjbYOJYyk3QCl/Cev.RnyFCExlzhaMVSTkRa', 'Agif', '083161423128', 'user', '2026-05-19 23:21:08'),
(6, 'nana', 'nana@gmail.com', '$2y$10$WKICvhvHthvp1ZboJeeK0uhybxjmPlmjJV5ElUNfuMzSXGFIBsQtC', 'nana', '083161423128', 'super_admin', '2026-05-19 23:52:06'),
(7, 'sandy', 'sandy@gmail.com', '$2y$10$IRJ03nMcZy7A9Ktfa5C.a.Dbg77RnskTMaspfNmV0/9eDDCzWddGm', 'sandy', '083161423128', 'user', '2026-05-20 00:36:36'),
(8, 'syakir', 'syakir@gmail.com', '$2y$10$2HMD0D.mDH1...qfXMmGeOL1rt2x9CUhn2QWQmk1.ziRMpuN2VjjO', 'syakir', '083161423128', 'user', '2026-05-20 01:30:56'),
(9, 'hasan', 'hasan@gmail.com', '$2y$10$VGc7TAlfBtX2ImEeK77qiOapEKTKPRS.M3BW0Odj9j2hxNcGPaSm2', 'hasan', '083161423128', 'admin', '2026-05-20 01:39:34'),
(10, 'laptop', 'laptop@gmail.com', '$2y$10$WFPd6q8ZGsDMEcqkigCxMOg2ZcpBwV.2/Vv93N3uOe.UyqsgYe4hG', 'laptop', '083161423128', 'user', '2026-06-02 21:17:18'),
(11, 'ayu', 'ayu@gmail.com', '$2y$10$9tj9ikurfh3SLjlrXdAWTONM/ZdRajDrDsEjg8QA.tub993G/C7yq', 'ayu', '083161423128', 'user', '2026-06-02 21:18:48');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `booking_code` (`booking_code`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `lapangan_id` (`lapangan_id`),
  ADD KEY `idx_booking_cek_jadwal` (`lapangan_id`,`nomor_lapangan`,`tanggal`,`jam_mulai`,`jam_selesai`,`status`);

--
-- Indexes for table `lapangan`
--
ALTER TABLE `lapangan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- Indexes for table `lapangan_tutup`
--
ALTER TABLE `lapangan_tutup`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lapangan_id` (`lapangan_id`),
  ADD KEY `idx_tutup_cek_jadwal` (`lapangan_id`,`nomor_lapangan`,`tanggal`,`jam_mulai`,`jam_selesai`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `transaction_code` (`transaction_code`),
  ADD KEY `booking_id` (`booking_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `lapangan`
--
ALTER TABLE `lapangan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `lapangan_tutup`
--
ALTER TABLE `lapangan_tutup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`lapangan_id`) REFERENCES `lapangan` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `lapangan`
--
ALTER TABLE `lapangan`
  ADD CONSTRAINT `lapangan_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `lapangan_tutup`
--
ALTER TABLE `lapangan_tutup`
  ADD CONSTRAINT `lapangan_tutup_ibfk_1` FOREIGN KEY (`lapangan_id`) REFERENCES `lapangan` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `transactions_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
