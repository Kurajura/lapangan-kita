-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2026 at 09:15 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `oolahragabooking`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_booking_hidden`
--
-- Error reading structure for table oolahragabooking.admin_booking_hidden: #1932 - Table &#039;oolahragabooking.admin_booking_hidden&#039; doesn&#039;t exist in engine
-- Error reading data for table oolahragabooking.admin_booking_hidden: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `oolahragabooking`.`admin_booking_hidden`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--
-- Error reading structure for table oolahragabooking.bookings: #1932 - Table &#039;oolahragabooking.bookings&#039; doesn&#039;t exist in engine
-- Error reading data for table oolahragabooking.bookings: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `oolahragabooking`.`bookings`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `chat_messages`
--
-- Error reading structure for table oolahragabooking.chat_messages: #1932 - Table &#039;oolahragabooking.chat_messages&#039; doesn&#039;t exist in engine
-- Error reading data for table oolahragabooking.chat_messages: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `oolahragabooking`.`chat_messages`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `lapangan`
--
-- Error reading structure for table oolahragabooking.lapangan: #1932 - Table &#039;oolahragabooking.lapangan&#039; doesn&#039;t exist in engine
-- Error reading data for table oolahragabooking.lapangan: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `oolahragabooking`.`lapangan`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `lapangan_reviews`
--
-- Error reading structure for table oolahragabooking.lapangan_reviews: #1932 - Table &#039;oolahragabooking.lapangan_reviews&#039; doesn&#039;t exist in engine
-- Error reading data for table oolahragabooking.lapangan_reviews: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `oolahragabooking`.`lapangan_reviews`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `lapangan_tutup`
--
-- Error reading structure for table oolahragabooking.lapangan_tutup: #1932 - Table &#039;oolahragabooking.lapangan_tutup&#039; doesn&#039;t exist in engine
-- Error reading data for table oolahragabooking.lapangan_tutup: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `oolahragabooking`.`lapangan_tutup`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `match_participants`
--
-- Error reading structure for table oolahragabooking.match_participants: #1932 - Table &#039;oolahragabooking.match_participants&#039; doesn&#039;t exist in engine
-- Error reading data for table oolahragabooking.match_participants: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `oolahragabooking`.`match_participants`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `match_results`
--
-- Error reading structure for table oolahragabooking.match_results: #1932 - Table &#039;oolahragabooking.match_results&#039; doesn&#039;t exist in engine
-- Error reading data for table oolahragabooking.match_results: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `oolahragabooking`.`match_results`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--
-- Error reading structure for table oolahragabooking.notifications: #1932 - Table &#039;oolahragabooking.notifications&#039; doesn&#039;t exist in engine
-- Error reading data for table oolahragabooking.notifications: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `oolahragabooking`.`notifications`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--
-- Error reading structure for table oolahragabooking.password_resets: #1932 - Table &#039;oolahragabooking.password_resets&#039; doesn&#039;t exist in engine
-- Error reading data for table oolahragabooking.password_resets: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `oolahragabooking`.`password_resets`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `products`
--
-- Error reading structure for table oolahragabooking.products: #1932 - Table &#039;oolahragabooking.products&#039; doesn&#039;t exist in engine
-- Error reading data for table oolahragabooking.products: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `oolahragabooking`.`products`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `product_orders`
--
-- Error reading structure for table oolahragabooking.product_orders: #1932 - Table &#039;oolahragabooking.product_orders&#039; doesn&#039;t exist in engine
-- Error reading data for table oolahragabooking.product_orders: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `oolahragabooking`.`product_orders`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `product_reviews`
--
-- Error reading structure for table oolahragabooking.product_reviews: #1932 - Table &#039;oolahragabooking.product_reviews&#039; doesn&#039;t exist in engine
-- Error reading data for table oolahragabooking.product_reviews: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `oolahragabooking`.`product_reviews`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `subscription_orders`
--
-- Error reading structure for table oolahragabooking.subscription_orders: #1932 - Table &#039;oolahragabooking.subscription_orders&#039; doesn&#039;t exist in engine
-- Error reading data for table oolahragabooking.subscription_orders: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `oolahragabooking`.`subscription_orders`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `subscription_plans`
--
-- Error reading structure for table oolahragabooking.subscription_plans: #1932 - Table &#039;oolahragabooking.subscription_plans&#039; doesn&#039;t exist in engine
-- Error reading data for table oolahragabooking.subscription_plans: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `oolahragabooking`.`subscription_plans`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--
-- Error reading structure for table oolahragabooking.teams: #1932 - Table &#039;oolahragabooking.teams&#039; doesn&#039;t exist in engine
-- Error reading data for table oolahragabooking.teams: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `oolahragabooking`.`teams`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `team_match_requests`
--
-- Error reading structure for table oolahragabooking.team_match_requests: #1932 - Table &#039;oolahragabooking.team_match_requests&#039; doesn&#039;t exist in engine
-- Error reading data for table oolahragabooking.team_match_requests: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `oolahragabooking`.`team_match_requests`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `team_members`
--
-- Error reading structure for table oolahragabooking.team_members: #1932 - Table &#039;oolahragabooking.team_members&#039; doesn&#039;t exist in engine
-- Error reading data for table oolahragabooking.team_members: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `oolahragabooking`.`team_members`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--
-- Error reading structure for table oolahragabooking.transactions: #1932 - Table &#039;oolahragabooking.transactions&#039; doesn&#039;t exist in engine
-- Error reading data for table oolahragabooking.transactions: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `oolahragabooking`.`transactions`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `users`
--
-- Error reading structure for table oolahragabooking.users: #1932 - Table &#039;oolahragabooking.users&#039; doesn&#039;t exist in engine
-- Error reading data for table oolahragabooking.users: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `oolahragabooking`.`users`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `user_subscriptions`
--
-- Error reading structure for table oolahragabooking.user_subscriptions: #1932 - Table &#039;oolahragabooking.user_subscriptions&#039; doesn&#039;t exist in engine
-- Error reading data for table oolahragabooking.user_subscriptions: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `oolahragabooking`.`user_subscriptions`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `vip_orders`
--
-- Error reading structure for table oolahragabooking.vip_orders: #1932 - Table &#039;oolahragabooking.vip_orders&#039; doesn&#039;t exist in engine
-- Error reading data for table oolahragabooking.vip_orders: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `oolahragabooking`.`vip_orders`&#039; at line 1
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
