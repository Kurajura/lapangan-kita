-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 08, 2026 at 08:23 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `oolahragabooking`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `lapangan_id` int(11) NOT NULL,
  `nomor_lapangan` int(11) NOT NULL DEFAULT 1,
  `tanggal` date NOT NULL,
  `jam_mulai` time NOT NULL,
  `jam_selesai` time NOT NULL,
  `total_harga` decimal(10,2) NOT NULL,
  `platform_fee` decimal(10,2) NOT NULL DEFAULT 0.00,
  `owner_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` enum('pending','paid','confirmed','cancelled') DEFAULT 'pending',
  `payment_method` varchar(50) DEFAULT NULL,
  `payment_status` enum('unpaid','paid') DEFAULT 'unpaid',
  `payment_proof` varchar(255) DEFAULT NULL,
  `booking_code` varchar(20) DEFAULT NULL,
  `booking_source` enum('online','offline') NOT NULL DEFAULT 'online',
  `mode_main` enum('biasa','kompetitif','kursus') NOT NULL DEFAULT 'biasa',
  `match_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `match_status` enum('inactive','waiting_score','completed','cancelled') NOT NULL DEFAULT 'inactive',
  `match_requested_at` timestamp NULL DEFAULT NULL,
  `match_opponent_name` varchar(100) DEFAULT NULL,
  `nama_pelanggan` varchar(100) DEFAULT NULL,
  `telepon_pelanggan` varchar(20) DEFAULT NULL,
  `catatan` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `user_id`, `lapangan_id`, `nomor_lapangan`, `tanggal`, `jam_mulai`, `jam_selesai`, `total_harga`, `platform_fee`, `owner_amount`, `status`, `payment_method`, `payment_status`, `payment_proof`, `booking_code`, `booking_source`, `mode_main`, `nama_pelanggan`, `telepon_pelanggan`, `catatan`, `created_at`) VALUES
(9, 8, 6, 1, '2026-06-03', '07:00:00', '08:00:00', 50000.00, 2500.00, 47500.00, 'confirmed', NULL, 'paid', NULL, 'BK202606024901', 'online', 'biasa', NULL, NULL, NULL, '2026-06-02 21:16:49'),
(10, 10, 6, 1, '2026-06-03', '06:00:00', '07:00:00', 50000.00, 2500.00, 47500.00, 'confirmed', NULL, 'paid', NULL, 'BK202606029367', 'online', 'biasa', NULL, NULL, NULL, '2026-06-02 21:17:45');

-- --------------------------------------------------------

--
-- Table structure for table `lapangan`
--

CREATE TABLE `lapangan` (
  `id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `nama_lapangan` varchar(100) NOT NULL,
  `jenis_olahraga` varchar(50) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `harga_per_jam` decimal(10,2) NOT NULL,
  `jumlah_lapangan` int(11) NOT NULL DEFAULT 1,
  `foto` varchar(255) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `wilayah` varchar(100) DEFAULT NULL,
  `kabupaten` varchar(100) DEFAULT NULL,
  `status` enum('aktif','nonaktif') DEFAULT 'aktif',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lapangan`
--

INSERT INTO `lapangan` (`id`, `admin_id`, `nama_lapangan`, `jenis_olahraga`, `deskripsi`, `harga_per_jam`, `jumlah_lapangan`, `foto`, `alamat`, `wilayah`, `kabupaten`, `status`, `created_at`) VALUES
(1, 4, 'lapangan futsal jaya', 'futsal', 'bermain futsal dengan kualitas mantap', 50000.00, 1, '1779231671_704747b12b4e21c03599a8429da2b8b4.jpg', 'jakarta', 'jakarta', 'jakarta', 'aktif', '2026-05-19 23:01:11'),
(3, 4, 'badminton indor senayan', 'badminton', 'badminton', 35000.00, 2, '1779238023_0cc0f6c8f3a0faa36ed7f941c70f9241.jpg', 'senayan', 'senayan', 'senayan', 'aktif', '2026-05-20 00:47:03'),
(5, 4, 'badminton', 'badminton', 'buka jam 08.00 - 03.00 am\r\nperalatan lengkap , fasilatak ok', 40000.00, 2, '1779240434_10116cc6bf87df122824d71db05391bd.jpg', 'jln.cendrawasih', 'jln.cendrawasih', 'jln.cendrawasih', 'aktif', '2026-05-20 01:27:14'),
(6, 9, 'tennis out door jln senayan', 'tennis', '', 50000.00, 1, '1779241345_fafa31b0eb6bff20650be9f5b301820c.jpg', 'jln senayan', 'jln senayan', 'jln senayan', 'aktif', '2026-05-20 01:42:25'),
(7, 4, 'Stadion Spotify Camp Nou', 'football', 'Lapangan dengan kelas internasional dan Markas bersar Team Catalan Barcelona', 99999999.99, 1, '1780899199_26d89a3f459881e3.png', 'Carrer d\'Arístides Maillol, 12, 08028 Barcelona, Spanyol.', NULL, NULL, 'aktif', '2026-06-08 06:13:19');

-- --------------------------------------------------------

--
-- Table structure for table `lapangan_tutup`
--

CREATE TABLE `lapangan_tutup` (
  `id` int(11) NOT NULL,
  `lapangan_id` int(11) NOT NULL,
  `nomor_lapangan` int(11) NOT NULL DEFAULT 1,
  `tanggal` date NOT NULL,
  `jam_mulai` time NOT NULL,
  `jam_selesai` time NOT NULL,
  `alasan` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lapangan_tutup`
--

INSERT INTO `lapangan_tutup` (`id`, `lapangan_id`, `nomor_lapangan`, `tanggal`, `jam_mulai`, `jam_selesai`, `alasan`, `created_at`) VALUES
(1, 7, 1, '2026-06-08', '00:00:00', '12:00:00', '', '2026-06-08 06:15:12'),
(2, 7, 1, '2026-06-08', '12:00:00', '23:59:00', '', '2026-06-08 06:18:57');

-- --------------------------------------------------------

--
-- Table structure for table `match_results`
--

CREATE TABLE `match_results` (
  `id` int(11) NOT NULL,
  `booking_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `lapangan_id` int(11) NOT NULL,
  `nomor_lapangan` int(11) NOT NULL DEFAULT 1,
  `jenis_olahraga` varchar(50) NOT NULL,
  `wilayah` varchar(100) DEFAULT NULL,
  `kabupaten` varchar(100) DEFAULT NULL,
  `opponent_name` varchar(100) NOT NULL,
  `user_score` int(11) NOT NULL DEFAULT 0,
  `opponent_score` int(11) NOT NULL DEFAULT 0,
  `winner` enum('user','opponent','draw') NOT NULL DEFAULT 'draw',
  `points` int(11) NOT NULL DEFAULT 0,
  `score_diff` int(11) NOT NULL DEFAULT 0,
  `catatan` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subscription_orders`
--

CREATE TABLE `subscription_orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `plan_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `platform_fee` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` enum('pending','success','failed','cancelled') NOT NULL DEFAULT 'pending',
  `payment_method` varchar(50) DEFAULT NULL,
  `payment_channel` varchar(50) DEFAULT NULL,
  `transaction_code` varchar(50) NOT NULL,
  `payment_date` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subscription_plans`
--

CREATE TABLE `subscription_plans` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `duration_days` int(11) NOT NULL DEFAULT 30,
  `features` text DEFAULT NULL,
  `allow_leaderboard` tinyint(1) NOT NULL DEFAULT 0,
  `allow_match_recording` tinyint(1) NOT NULL DEFAULT 0,
  `allow_course` tinyint(1) NOT NULL DEFAULT 0,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subscription_plans`
--

INSERT INTO `subscription_plans` (`id`, `name`, `slug`, `description`, `price`, `duration_days`, `features`, `allow_leaderboard`, `allow_match_recording`, `allow_course`, `status`, `created_at`) VALUES
(1, 'Pemain Tetap', 'pemain-tetap', 'Paket untuk user yang sering booking dan ingin menjadi member aktif.', 29000.00, 30, 'Status member aktif|Cocok untuk pemain rutin|Riwayat booking lebih rapi|Akses promo/member internal', 0, 0, 0, 'active', '2026-06-03 01:37:43'),
(2, 'Arena Kompetitif', 'arena-kompetitif', 'Paket turnamen/kompetitif untuk mencatat hasil pertandingan dan membuka leaderboard.', 49000.00, 30, 'Buka akses leaderboard|Catat hasil pertandingan|Ranking berdasarkan lapangan, wilayah, dan cabang olahraga|Cocok untuk sparing dan turnamen kecil', 1, 1, 0, 'active', '2026-06-03 01:37:43'),
(3, 'Akademi/Kursus', 'akademi-kursus', 'Paket untuk kelas latihan/kursus yang memakai lapangan bersama pelatih.', 79000.00, 30, 'Mode booking kursus|Cocok untuk latihan privat/kelompok|Membantu pengelolaan jadwal pelatih|Cocok untuk akademi olahraga', 0, 0, 1, 'active', '2026-06-03 01:37:43');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `booking_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `payment_channel` varchar(50) DEFAULT NULL,
  `qr_code` text DEFAULT NULL,
  `transaction_code` varchar(50) DEFAULT NULL,
  `status` enum('pending','success','failed','cancelled') DEFAULT 'pending',
  `payment_date` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `booking_id`, `user_id`, `amount`, `payment_method`, `payment_channel`, `qr_code`, `transaction_code`, `status`, `payment_date`, `created_at`) VALUES
(10, 9, 8, 50000.00, 'qris', 'QRIS', '{\"transaction_code\":\"TRX20260602231652258\",\"amount\":\"50000.00\",\"method\":\"qris\",\"channel\":\"QRIS\"}', 'TRX20260602231652258', 'success', '2026-06-02 21:16:53', '2026-06-02 21:16:52'),
(11, 10, 10, 50000.00, 'qris', 'QRIS', '{\"transaction_code\":\"TRX20260602231748775\",\"amount\":\"50000.00\",\"method\":\"qris\",\"channel\":\"QRIS\"}', 'TRX20260602231748775', 'success', '2026-06-02 21:17:49', '2026-06-02 21:17:48');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `display_name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `profile_photo` varchar(255) DEFAULT NULL,
  `show_rank_badges` tinyint(1) NOT NULL DEFAULT 1,
  `role` enum('user','admin','super_admin') DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `full_name`, `phone`, `role`, `created_at`) VALUES
(1, 'superadmin', 'superadmin@lapangankita.com', '$2y$10$YourHashedPasswordHere', 'Super Admin', NULL, 'super_admin', '2026-05-19 22:04:19'),
(3, 'agif', 'yusufbro3030@gmail.com', '$2y$10$QIHP8p8vQUqsKe38mlo5PeOkFem1/sWTRXzn9fcxezoElpFaBPbOm', 'agif', '083161423128', 'user', '2026-05-19 22:22:15'),
(4, 'zero', 'kukukaki.3019@gmail.com', '$2y$10$EANhX5UKOQqHRa4oqkW0j.uKU3BAMN37i7AKNTKSlQKOZiIg4PuMy', 'ziro', '083161423128', 'admin', '2026-05-19 22:24:30'),
(5, 'axel', 'pirmando.2005@gmail.com', '$2y$10$mu9JBVJARhfk/M6i4zjbYOJYyk3QCl/Cev.RnyFCExlzhaMVSTkRa', 'Agif', '083161423128', 'user', '2026-05-19 23:21:08'),
(6, 'nana', 'nana@gmail.com', '$2y$10$WKICvhvHthvp1ZboJeeK0uhybxjmPlmjJV5ElUNfuMzSXGFIBsQtC', 'nana', '083161423128', 'super_admin', '2026-05-19 23:52:06'),
(7, 'sandy', 'sandy@gmail.com', '$2y$10$IRJ03nMcZy7A9Ktfa5C.a.Dbg77RnskTMaspfNmV0/9eDDCzWddGm', 'sandy', '083161423128', 'user', '2026-05-20 00:36:36'),
(8, 'syakir', 'syakir@gmail.com', '$2y$10$2HMD0D.mDH1...qfXMmGeOL1rt2x9CUhn2QWQmk1.ziRMpuN2VjjO', 'syakir', '083161423128', 'user', '2026-05-20 01:30:56'),
(9, 'hasan', 'hasan@gmail.com', '$2y$10$VGc7TAlfBtX2ImEeK77qiOapEKTKPRS.M3BW0Odj9j2hxNcGPaSm2', 'hasan', '083161423128', 'admin', '2026-05-20 01:39:34'),
(10, 'laptop', 'laptop@gmail.com', '$2y$10$WFPd6q8ZGsDMEcqkigCxMOg2ZcpBwV.2/Vv93N3uOe.UyqsgYe4hG', 'laptop', '083161423128', 'user', '2026-06-02 21:17:18'),
(11, 'ayu', 'ayu@gmail.com', '$2y$10$9tj9ikurfh3SLjlrXdAWTONM/ZdRajDrDsEjg8QA.tub993G/C7yq', 'ayu', '083161423128', 'user', '2026-06-02 21:18:48');

-- --------------------------------------------------------

--
-- Table structure for table `user_subscriptions`
--

CREATE TABLE `user_subscriptions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `plan_id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` enum('pending','active','expired','cancelled') NOT NULL DEFAULT 'active',
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `platform_fee` decimal(10,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `booking_code` (`booking_code`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `lapangan_id` (`lapangan_id`),
  ADD KEY `idx_booking_cek_jadwal` (`lapangan_id`,`nomor_lapangan`,`tanggal`,`jam_mulai`,`jam_selesai`,`status`);

--
-- Indexes for table `lapangan`
--
ALTER TABLE `lapangan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- Indexes for table `lapangan_tutup`
--
ALTER TABLE `lapangan_tutup`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lapangan_id` (`lapangan_id`),
  ADD KEY `idx_tutup_cek_jadwal` (`lapangan_id`,`nomor_lapangan`,`tanggal`,`jam_mulai`,`jam_selesai`);

--
-- Indexes for table `match_results`
--
ALTER TABLE `match_results`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `booking_id` (`booking_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `lapangan_id` (`lapangan_id`),
  ADD KEY `idx_leaderboard_filter` (`jenis_olahraga`,`wilayah`,`kabupaten`,`lapangan_id`);

--
-- Indexes for table `subscription_orders`
--
ALTER TABLE `subscription_orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `transaction_code` (`transaction_code`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `plan_id` (`plan_id`);

--
-- Indexes for table `subscription_plans`
--
ALTER TABLE `subscription_plans`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `transaction_code` (`transaction_code`),
  ADD KEY `booking_id` (`booking_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `user_subscriptions`
--
ALTER TABLE `user_subscriptions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `plan_id` (`plan_id`),
  ADD KEY `order_id` (`order_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `lapangan`
--
ALTER TABLE `lapangan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `lapangan_tutup`
--
ALTER TABLE `lapangan_tutup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `match_results`
--
ALTER TABLE `match_results`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subscription_orders`
--
ALTER TABLE `subscription_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subscription_plans`
--
ALTER TABLE `subscription_plans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `user_subscriptions`
--
ALTER TABLE `user_subscriptions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`lapangan_id`) REFERENCES `lapangan` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `lapangan`
--
ALTER TABLE `lapangan`
  ADD CONSTRAINT `lapangan_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `lapangan_tutup`
--
ALTER TABLE `lapangan_tutup`
  ADD CONSTRAINT `lapangan_tutup_ibfk_1` FOREIGN KEY (`lapangan_id`) REFERENCES `lapangan` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `match_results`
--
ALTER TABLE `match_results`
  ADD CONSTRAINT `match_results_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `match_results_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `match_results_ibfk_3` FOREIGN KEY (`lapangan_id`) REFERENCES `lapangan` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `subscription_orders`
--
ALTER TABLE `subscription_orders`
  ADD CONSTRAINT `subscription_orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `subscription_orders_ibfk_2` FOREIGN KEY (`plan_id`) REFERENCES `subscription_plans` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `transactions_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_subscriptions`
--
ALTER TABLE `user_subscriptions`
  ADD CONSTRAINT `user_subscriptions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_subscriptions_ibfk_2` FOREIGN KEY (`plan_id`) REFERENCES `subscription_plans` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_subscriptions_ibfk_3` FOREIGN KEY (`order_id`) REFERENCES `subscription_orders` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
