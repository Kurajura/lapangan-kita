<?php 
include 'config/database.php';
if (!isLoggedIn()) {
    header("Location: login.php?error=Silakan login terlebih dahulu");
    exit();
}

$transaction_id = (int)($_GET['transaction_id'] ?? 0);
$stmt = $pdo->prepare("SELECT t.*, b.booking_code, b.lapangan_id, b.nomor_lapangan, b.vip_discount_amount, b.vip_discount_percent, l.nama_lapangan
                       FROM transactions t
                       JOIN bookings b ON t.booking_id = b.id
                       JOIN lapangan l ON b.lapangan_id = l.id
                       WHERE t.id = ? AND t.user_id = ?");
$stmt->execute([$transaction_id, $_SESSION['user_id']]);
$transaction = $stmt->fetch();

if (!$transaction) {
    header("Location: riwayat.php?error=Transaksi tidak ditemukan");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['confirm_payment'])) {
    $stmt = $pdo->prepare("UPDATE transactions SET status = 'success', payment_date = NOW() WHERE id = ?");
    $stmt->execute([$transaction_id]);
    $stmt = $pdo->prepare("UPDATE bookings SET status = 'confirmed', payment_status = 'paid' WHERE id = ?");
    $stmt->execute([$transaction['booking_id']]);
    header("Location: cetak-struk.php?transaction_id=" . $transaction_id);
    exit();
}

$qr_payload = $transaction['qr_code'] ?: json_encode([
    'transaction_code' => $transaction['transaction_code'],
    'amount' => $transaction['amount'],
    'method' => $transaction['payment_method'],
    'channel' => $transaction['payment_channel']
]);
$qr_svg = generateQrSvg($qr_payload, 300);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scan QR Code - LapanganKita</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="top-header">
    <div class="promo-box"> QR Payment <span>SCAN</span></div>
    <div class="top-right"><div class="user-info"><i class="fa-regular fa-user"></i> <?= e($_SESSION['username']) ?> <a href="logout.php" style="color:#ff003c;">Logout</a></div></div>
</div>
<?php renderNavbar(''); ?>

<div class="qr-container public-page-wrap">
    <div class="form-card payment-qr-card">
        <h2>Scan QR Code untuk Membayar</h2>
        <p><strong><?= e($transaction['nama_lapangan']) ?></strong> - Lapangan <?= (int)$transaction['nomor_lapangan'] ?></p>
        <p>Total: <strong>Rp <?= number_format($transaction['amount'], 0, ',', '.') ?></strong></p>
        <?php if((float)$transaction['vip_discount_amount'] > 0): ?>
            <p class="helper-text">Diskon VIP <?= number_format((float)$transaction['vip_discount_percent'], 0) ?>% sudah dipotong: Rp <?= number_format($transaction['vip_discount_amount'], 0, ',', '.') ?></p>
        <?php endif; ?>
        <p>Metode: <?= e(strtoupper($transaction['payment_method'])) ?> - <?= e($transaction['payment_channel']) ?></p>
        <div class="qr-box-real">
            <?= $qr_svg ?>
            <div class="qr-code-label"><?= e($transaction['transaction_code']) ?></div>
        </div>
        <div class="payment-help-box">
            <i class="fa-solid fa-circle-info"></i>
            <span>Ini QR simulasi untuk project lokal. Setelah scan/pilih bayar, klik tombol konfirmasi agar status booking menjadi paid.</span>
        </div>
        <form method="POST">
            <button type="submit" name="confirm_payment" class="btn-primary">Konfirmasi Pembayaran</button>
        </form>
    </div>
</div>
</body>
</html>
