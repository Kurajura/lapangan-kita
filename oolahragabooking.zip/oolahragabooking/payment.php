<?php 
include 'config/database.php';
if (!isLoggedIn()) {
    header("Location: login.php?error=Silakan login terlebih dahulu");
    exit();
}

$booking_id = $_GET['booking_id'] ?? 0;
$stmt = $pdo->prepare("SELECT b.*, l.nama_lapangan, l.harga_per_jam FROM bookings b JOIN lapangan l ON b.lapangan_id = l.id WHERE b.id = ? AND b.user_id = ?");
$stmt->execute([$booking_id, $_SESSION['user_id']]);
$booking = $stmt->fetch();

if (!$booking) {
    header("Location: riwayat.php?error=Booking tidak ditemukan");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $payment_method = $_POST['payment_method'];
    $payment_channel = $_POST['payment_channel'];
    $transaction_code = 'TRX' . date('YmdHis') . rand(100, 999);
    
    // Generate QR code data (simulasi)
    $qr_data = json_encode([
        'transaction_code' => $transaction_code,
        'amount' => $booking['total_harga'],
        'method' => $payment_method,
        'channel' => $payment_channel
    ]);
    
    $stmt = $pdo->prepare("INSERT INTO transactions (booking_id, user_id, amount, payment_method, payment_channel, qr_code, transaction_code) VALUES (?, ?, ?, ?, ?, ?, ?)");
    if ($stmt->execute([$booking_id, $_SESSION['user_id'], $booking['total_harga'], $payment_method, $payment_channel, $qr_data, $transaction_code])) {
        $transaction_id = $pdo->lastInsertId();
        header("Location: payment-process.php?transaction_id=" . $transaction_id);
        exit();
    } else {
        $error = "Pembayaran gagal diproses";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pembayaran - LapanganKita</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .payment-container {
            padding: 180px 7% 100px;
            max-width: 600px;
            margin: 0 auto;
        }
        .payment-detail {
            background: rgba(0,255,179,.1);
            padding: 20px;
            border-radius: 16px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
<div class="top-header">
    <div class="promo-box"> Payment <span>PREMIUM</span></div>
    <div class="top-right">
        <div class="user-info">
            <i class="fa-regular fa-user"></i> <?= $_SESSION['username'] ?>
            <a href="logout.php" style="color:#ff003c;">Logout</a>
        </div>
    </div>
</div>
<?php renderNavbar(''); ?>

<div class="payment-container">
    <div class="form-card">
        <h2>Detail Pembayaran</h2>
        <div class="payment-detail">
            <p><strong>Lapangan:</strong> <?= htmlspecialchars($booking['nama_lapangan']) ?></p>
            <p><strong>No. Lapangan:</strong> Lapangan <?= (int) $booking['nomor_lapangan'] ?></p>
            <p><strong>Tanggal:</strong> <?= date('d/m/Y', strtotime($booking['tanggal'])) ?></p>
            <p><strong>Jam:</strong> <?= substr($booking['jam_mulai'], 0, 5) ?> - <?= substr($booking['jam_selesai'], 0, 5) ?></p>
            <p><strong>Total Harga:</strong> Rp <?= number_format($booking['total_harga'], 0, ',', '.') ?></p>
        </div>
        
        <?php if(isset($error)): ?>
            <div class="alert-error"><?= $error ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <h3>Pilih Metode Pembayaran</h3><p class="helper-text">Setelah metode dipilih, sistem akan menampilkan halaman scan QR code.</p>
            <div class="payment-methods">
                <div class="payment-btn" data-method="qris" data-channel="QRIS">
                    <i class="fa-solid fa-qrcode"></i>
                    <span>QRIS</span>
                </div>
                <div class="payment-btn" data-method="ewallet" data-channel="DANA">
                    <i class="fa-solid fa-wallet"></i>
                    <span>DANA</span>
                </div>
                <div class="payment-btn" data-method="ewallet" data-channel="OVO">
                    <i class="fa-solid fa-mobile-alt"></i>
                    <span>OVO</span>
                </div>
                <div class="payment-btn" data-method="mbanking" data-channel="BCA Mobile">
                    <i class="fa-solid fa-university"></i>
                    <span>M-Banking BCA</span>
                </div>
                <div class="payment-btn" data-method="mbanking" data-channel="Mandiri Online">
                    <i class="fa-solid fa-building-columns"></i>
                    <span>M-Banking Mandiri</span>
                </div>
            </div>
            <input type="hidden" name="payment_method" id="payment_method" required>
            <input type="hidden" name="payment_channel" id="payment_channel" required>
            <button type="submit" class="btn-primary" id="submitBtn" disabled>Lanjutkan ke Scan QR</button>
        </form>
    </div>
</div>

<script>
    let selectedMethod = null;
    let selectedChannel = null;
    
    document.querySelectorAll('.payment-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.payment-btn').forEach(b => b.classList.remove('selected'));
            this.classList.add('selected');
            selectedMethod = this.dataset.method;
            selectedChannel = this.dataset.channel;
            document.getElementById('payment_method').value = selectedMethod;
            document.getElementById('payment_channel').value = selectedChannel;
            document.getElementById('submitBtn').disabled = false;
        });
    });
</script>
</body>
</html>