<?php
include 'config/database.php';
$q = trim($_GET['q'] ?? '');
$players = [];
if ($q !== '') {
    $like = '%' . $q . '%';
    $stmt = $pdo->prepare("SELECT id, player_code, username, full_name, display_name, bio, profile_photo
                           FROM users
                           WHERE role = 'user' AND (player_code LIKE ? OR username LIKE ? OR full_name LIKE ? OR display_name LIKE ? OR bio LIKE ?)
                           ORDER BY CASE WHEN player_code = ? OR username = ? THEN 0 ELSE 1 END, username ASC
                           LIMIT 30");
    $stmt->execute([$like, $like, $like, $like, $like, $q, $q]);
    $players = $stmt->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cari Pemain - LapanganKita</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="top-header"><div class="promo-box">Cari Pemain <span>SMART SEARCH</span></div><div class="top-right"><?php if(isLoggedIn()): ?><div class="user-info"><i class="fa-regular fa-user"></i> <?= e($_SESSION['username']) ?> <a href="logout.php" style="color:#ff003c;">Logout</a></div><?php else: ?><a href="login.php" class="login-btn"><div class="login-icon"><i class="fa-regular fa-user"></i></div> Login</a><a href="register.php" class="plan-btn">Daftar</a><?php endif; ?></div></div>
<?php renderNavbar(''); ?>
<div class="public-page-wrap">
    <div class="form-card">
        <h2>Pencarian Cerdas Pemain</h2>
        <p class="helper-text">Cari pemain berdasarkan ID 6 angka, username, nama profil, atau bio.</p>
        <form method="GET" class="player-search-page-form">
            <input type="text" name="q" value="<?= e($q) ?>" placeholder="Contoh: 301902, budi, top badminton" required>
            <button class="btn-primary">Cari Pemain</button>
        </form>
    </div>
    <div class="player-grid-results">
        <?php foreach($players as $p): ?>
            <a class="player-result-card" href="profile.php?id=<?= (int)$p['id'] ?>">
                <span class="profile-mini-avatar big">
                    <?php if($p['profile_photo']): ?><img src="assets/profiles/<?= e($p['profile_photo']) ?>" alt="Profil"><?php else: ?><i class="fa-regular fa-user"></i><?php endif; ?>
                </span>
                <strong><?= e(getPlayerPublicName($p)) ?></strong>
                <small>ID <?= e($p['player_code']) ?> · @<?= e($p['username']) ?></small>
                <p><?= e(mb_strimwidth($p['bio'] ?: 'Belum ada bio.', 0, 90, '...')) ?></p>
            </a>
        <?php endforeach; ?>
        <?php if($q !== '' && count($players) === 0): ?><div class="form-card"><p class="helper-text">Pemain tidak ditemukan.</p></div><?php endif; ?>
    </div>
</div>
</body>
</html>
