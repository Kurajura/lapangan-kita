<?php
include 'config/database.php';
$id=(int)($_GET['id'] ?? 0);
$stmt=$pdo->prepare("SELECT p.*, u.username, u.player_code, u.role, u.phone, COALESCE(NULLIF(u.display_name,''), NULLIF(u.full_name,''), u.username) AS seller_name FROM products p JOIN users u ON p.seller_id=u.id WHERE p.id=?");
$stmt->execute([$id]);
$product=$stmt->fetch();
if(!$product){ header('Location: marketplace.php?error=Produk tidak ditemukan'); exit(); }
function backProductDetail($id,$msg,$type='success'){ header('Location: product-detail.php?id='.(int)$id.'&'.$type.'='.urlencode($msg)); exit(); }
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['buy_product'])){
    if(!isLoggedIn()) backProductDetail($id,'Login dulu untuk membeli barang','error');
    if((int)$product['seller_id'] === (int)getUserId()) backProductDetail($id,'Kamu tidak bisa membeli barang sendiri','error');
    if($product['status'] !== 'active') backProductDetail($id,'Barang sedang tidak aktif','error');
    $qty = max(1, (int)($_POST['quantity'] ?? 1));
    $payment_method = trim($_POST['payment_method'] ?? 'qris');
    $payment_channel = trim($_POST['payment_channel'] ?? 'QRIS');
    if($qty > (int)$product['stock']) backProductDetail($id,'Stok barang tidak cukup','error');
    $total = (float)$product['price'] * $qty;
    $platform_fee = calculatePlatformFee($total);
    $seller_amount = max(0, $total - $platform_fee);
    $transaction_code = 'PRD' . date('YmdHis') . rand(100,999);
    $qr_data = json_encode(['transaction_code'=>$transaction_code,'product_id'=>$id,'qty'=>$qty,'amount'=>$total,'method'=>$payment_method,'channel'=>$payment_channel]);
    $stmt=$pdo->prepare("INSERT INTO product_orders (product_id,buyer_id,seller_id,quantity,price,total_amount,platform_fee,seller_amount,payment_method,payment_channel,qr_code,transaction_code,status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?, 'pending')");
    $stmt->execute([$id,getUserId(),(int)$product['seller_id'],$qty,(float)$product['price'],$total,$platform_fee,$seller_amount,$payment_method,$payment_channel,$qr_data,$transaction_code]);
    header('Location: product-payment.php?order_id='.(int)$pdo->lastInsertId());
    exit();
}

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['add_review'])){
    if(!isLoggedIn()) backProductDetail($id,'Login dulu untuk memberi review','error');
    $rating=(int)($_POST['rating'] ?? 0); $message=trim($_POST['message'] ?? '');
    if($rating<1 || $rating>5) backProductDetail($id,'Rating harus 1 sampai 5','error');
    $stmt=$pdo->prepare("INSERT INTO product_reviews (product_id,user_id,rating,message) VALUES (?,?,?,?)");
    $stmt->execute([$id,getUserId(),$rating,$message]);
    backProductDetail($id,'Review barang berhasil disimpan');
}
$stmt=$pdo->prepare("SELECT COALESCE(AVG(rating),0) avg_rating, COUNT(*) total_review FROM product_reviews WHERE product_id=?");
$stmt->execute([$id]);
$ratingInfo=$stmt->fetch();
$stmt=$pdo->prepare("SELECT pr.*, COALESCE(NULLIF(u.display_name,''), NULLIF(u.full_name,''), u.username) AS reviewer_name, u.player_code FROM product_reviews pr JOIN users u ON pr.user_id=u.id WHERE pr.product_id=? ORDER BY pr.created_at DESC LIMIT 30");
$stmt->execute([$id]);
$reviews=$stmt->fetchAll();
?>
<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title><?= e($product['product_name']) ?> - Market</title><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"><link rel="stylesheet" href="assets/css/style.css"></head><body>
<div class="top-header"><div class="promo-box">Detail Barang <span>REVIEW</span></div><div class="top-right"><?php if(isLoggedIn()): ?><div class="user-info"><i class="fa-regular fa-user"></i> <?= e($_SESSION['username']) ?> <a href="logout.php" style="color:#ff003c;">Logout</a></div><?php else: ?><a href="login.php" class="login-btn"><div class="login-icon"><i class="fa-regular fa-user"></i></div> Login</a><?php endif; ?></div></div>
<?php renderNavbar(''); ?>
<div class="public-page-wrap">
<?php if(isset($_GET['success'])): ?><div class="alert-success"><?= e($_GET['success']) ?></div><?php endif; ?><?php if(isset($_GET['error'])): ?><div class="alert-error"><?= e($_GET['error']) ?></div><?php endif; ?>
<div class="form-card product-detail-layout"><div class="product-detail-image"><?php if($product['photo']): ?><img src="assets/products/<?= e($product['photo']) ?>" alt="<?= e($product['product_name']) ?>"><?php else: ?><div class="product-empty-image"><i class="fa-solid fa-dumbbell"></i></div><?php endif; ?></div><div><span class="mini-badge"><?= e($product['category'] ?: 'Barang olahraga') ?></span><h2><?= e($product['product_name']) ?></h2><div class="product-price">Rp <?= number_format($product['price'],0,',','.') ?></div><div class="rating-row"><?= starRatingHtml($ratingInfo['avg_rating']) ?> <strong><?= number_format((float)$ratingInfo['avg_rating'],1) ?></strong><span>(<?= (int)$ratingInfo['total_review'] ?> review)</span></div><p><?= nl2br(e($product['description'] ?: 'Belum ada deskripsi barang.')) ?></p><div class="product-meta"><span>Stok: <?= (int)$product['stock'] ?></span><span>Status: <?= e($product['status']) ?></span><span>Penjual: <?= e($product['seller_name']) ?> <?= $product['player_code'] ? '(ID '.e($product['player_code']).')' : '' ?></span></div><div class="market-actions"><?php if(isLoggedIn() && (int)$product['seller_id'] !== (int)getUserId() && $product['role']==='user'): ?><a class="btn-primary" href="chat.php?user_id=<?= (int)$product['seller_id'] ?>">Chat Penjual</a><?php endif; ?><a class="btn-secondary" href="marketplace.php">Kembali ke Market</a></div>
<?php if(isLoggedIn() && (int)$product['seller_id'] !== (int)getUserId() && $product['status']==='active' && (int)$product['stock'] > 0): ?>
<div class="product-buy-box"><h3>Beli Barang</h3><p class="helper-text">Pembeli tidak wajib VIP. Fee sistem otomatis masuk ke bagian keuntungan super admin.</p><form method="POST" class="product-buy-grid"><div><label>Jumlah</label><input type="number" name="quantity" min="1" max="<?= (int)$product['stock'] ?>" value="1" required></div><div><label>Metode</label><select name="payment_method" required><option value="qris">QRIS</option><option value="ewallet">E-Wallet</option><option value="mbanking">M-Banking</option></select></div><div><label>Channel</label><select name="payment_channel" required><option value="QRIS">QRIS</option><option value="DANA">DANA</option><option value="OVO">OVO</option><option value="BCA Mobile">BCA Mobile</option><option value="Mandiri Online">Mandiri Online</option></select></div><button class="btn-primary" name="buy_product" value="1">Beli Sekarang</button></form></div>
<?php elseif(!isLoggedIn()): ?>
<div class="product-buy-box"><p class="helper-text">Login dulu untuk membeli barang ini.</p><a class="btn-primary" href="login.php?error=Login dulu untuk membeli barang">Login Pembeli</a></div>
<?php endif; ?>
</div></div>
<div class="form-card"><h2>Review Barang</h2><?php if(isLoggedIn()): ?><form method="POST" class="review-form-grid"><div><label>Bintang</label><select name="rating" required><option value="5">5 - Sangat puas</option><option value="4">4 - Puas</option><option value="3">3 - Cukup</option><option value="2">2 - Kurang</option><option value="1">1 - Tidak puas</option></select></div><div><label>Pesan review</label><textarea name="message" placeholder="Tulis pengalaman kamu tentang barang ini"></textarea></div><button class="btn-primary" name="add_review" value="1">Kirim Review</button></form><?php else: ?><p class="helper-text">Login dulu untuk memberi review barang.</p><?php endif; ?><div class="review-list"><?php foreach($reviews as $r): ?><div class="review-card"><strong><?= e($r['reviewer_name']) ?> <small>ID <?= e($r['player_code']) ?></small></strong><div><?= starRatingHtml($r['rating']) ?> <small><?= date('d/m/Y H:i',strtotime($r['created_at'])) ?></small></div><p><?= nl2br(e($r['message'] ?: '-')) ?></p></div><?php endforeach; ?><?php if(!$reviews): ?><p class="helper-text">Belum ada review.</p><?php endif; ?></div></div>
</div></body></html>
