<?php
include 'config/database.php';
if (!isLoggedIn()) { header('Location: login.php?error=Login dulu untuk jual barang'); exit(); }
if (!canSellProduct($pdo, getUserId(), getUserRole())) { header('Location: vip.php?error=' . urlencode('Jual barang olahraga untuk user harus VIP. Admin lapangan boleh jual tanpa VIP.')); exit(); }
function backProductForm($msg,$type='error'){ header('Location: product-form.php?'.$type.'='.urlencode($msg)); exit(); }
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $name = trim($_POST['product_name'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = (float)($_POST['price'] ?? 0);
    $stock = max(0, (int)($_POST['stock'] ?? 1));
    if ($name === '') backProductForm('Nama barang wajib diisi');
    if ($price <= 0) backProductForm('Harga barang wajib lebih dari 0');
    try {
        $photo = uploadImageFile('photo', __DIR__ . '/assets/products', 'product');
        $stmt = $pdo->prepare("INSERT INTO products (seller_id, product_name, category, description, price, stock, photo, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'active')");
        $stmt->execute([getUserId(), $name, $category, $description, $price, $stock, $photo]);
        header('Location: product-detail.php?id='.(int)$pdo->lastInsertId().'&success='.urlencode('Barang berhasil dipasang di market'));
        exit();
    } catch(Exception $e) { backProductForm('Gagal menyimpan barang: '.$e->getMessage()); }
}
?>
<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Jual Barang - LapanganKita</title><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"><link rel="stylesheet" href="assets/css/style.css"></head><body>
<div class="top-header"><div class="promo-box">Tambah Barang <span>SELLER</span></div><div class="top-right"><div class="user-info"><i class="fa-regular fa-user"></i> <?= e($_SESSION['username']) ?> <a href="logout.php" style="color:#ff003c;">Logout</a></div></div></div>
<?php renderNavbar(''); ?>
<div class="public-page-wrap"><div class="form-card admin-register-card"><h2>Jual Barang Olahraga</h2><p class="helper-text">User biasa wajib VIP untuk jualan. Admin lapangan boleh jual barang tanpa VIP. Contoh barang: raket, bola, sepatu, jersey, tas olahraga, grip, shuttlecock, dan lainnya.</p><?php if(isset($_GET['error'])): ?><div class="alert-error"><?= e($_GET['error']) ?></div><?php endif; ?><form method="POST" enctype="multipart/form-data" class="clean-form"><div class="form-group"><label>Nama Barang</label><input type="text" name="product_name" required></div><div class="form-group"><label>Kategori</label><input type="text" name="category" placeholder="Contoh: Badminton / Futsal / Basket"></div><div class="form-group"><label>Harga</label><input type="number" name="price" min="1" step="100" required></div><div class="form-group"><label>Stok</label><input type="number" name="stock" min="0" value="1"></div><div class="form-group"><label>Foto Barang</label><input type="file" name="photo" accept="image/*"></div><div class="form-group"><label>Deskripsi</label><textarea name="description" rows="5" placeholder="Kondisi barang, ukuran, lokasi COD, dll"></textarea></div><button class="btn-primary">Simpan Barang</button><a class="btn-secondary" href="marketplace.php">Kembali</a></form></div></div></body></html>
