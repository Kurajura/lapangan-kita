<?php
include 'config/database.php';
if (!isLoggedIn()) {
    header('Location: login.php?error=Silakan login terlebih dahulu');
    exit();
}
$order_id = (int)($_GET['order_id'] ?? 0);
$stmt = $pdo->prepare("SELECT po.*, p.product_name, p.photo, p.stock, u.username AS seller_username, COALESCE(NULLIF(u.display_name,''), NULLIF(u.full_name,''), u.username) AS seller_name
                       FROM product_orders po
                       JOIN products p ON po.product_id = p.id
                       JOIN users u ON po.seller_id = u.id
                       WHERE po.id = ? AND po.buyer_id = ?");
$stmt->execute([$order_id, getUserId()]);
$order = $stmt->fetch();
if (!$order) {
    header('Location: marketplace.php?error=Order barang tidak ditemukan');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_product_payment'])) {
    try {
        $pdo->beginTransaction();
        $stmt = $pdo->prepare("SELECT po.*, p.stock, p.product_name FROM product_orders po JOIN products p ON po.product_id = p.id WHERE po.id = ? AND po.buyer_id = ? FOR UPDATE");
        $stmt->execute([$order_id, getUserId()]);
        $locked = $stmt->fetch();
        if (!$locked) throw new Exception('Order tidak ditemukan');
        if ($locked['status'] === 'success') {
            $pdo->commit();
            header('Location: product-detail.php?id='.(int)$locked['product_id'].'&success='.urlencode('Order ini sudah sukses'));
            exit();
        }
        if ((int)$locked['stock'] < (int)$locked['quantity']) {
            $pdo->prepare("UPDATE product_orders SET status='cancelled' WHERE id=?")->execute([$order_id]);
            $pdo->commit();
            header('Location: product-detail.php?id='.(int)$locked['product_id'].'&error='.urlencode('Stok tidak cukup, order otomatis dibatalkan'));
            exit();
        }
        $pdo->prepare("UPDATE product_orders SET status='success', payment_date=NOW() WHERE id=?")->execute([$order_id]);
        $pdo->prepare("UPDATE products SET stock = GREATEST(0, stock - ?), status = CASE WHEN GREATEST(0, stock - ?) <= 0 THEN 'sold_out' ELSE status END WHERE id=?")->execute([(int)$locked['quantity'], (int)$locked['quantity'], (int)$locked['product_id']]);
        createNotification($pdo, (int)$locked['seller_id'], 'Barang terjual', 'Barang kamu berhasil dibeli. Kode transaksi: '.$locked['transaction_code'], 'my-products.php');
        $pdo->commit();
        header('Location: product-detail.php?id='.(int)$locked['product_id'].'&success='.urlencode('Pembayaran barang sukses. Order berhasil dibuat.'));
        exit();
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        header('Location: product-payment.php?order_id='.$order_id.'&error='.urlencode('Gagal konfirmasi pembayaran: '.$e->getMessage()));
        exit();
    }
}
$qr_payload = $order['qr_code'] ?: json_encode(['transaction_code'=>$order['transaction_code'],'amount'=>$order['total_amount']]);
$qr_svg = generateQrSvg($qr_payload, 300);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Pembayaran Barang - LapanganKita</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"><link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="top-header"><div class="promo-box">Payment Barang <span>MARKET</span></div><div class="top-right"><div class="user-info"><i class="fa-regular fa-user"></i> <?= e($_SESSION['username']) ?> <a href="logout.php" style="color:#ff003c;">Logout</a></div></div></div>
<?php renderNavbar(''); ?>
<div class="public-page-wrap qr-container">
    <div class="form-card payment-qr-card">
        <h2>Scan QR Pembayaran Barang</h2>
        <?php if(isset($_GET['error'])): ?><div class="alert-error"><?= e($_GET['error']) ?></div><?php endif; ?>
        <p><strong><?= e($order['product_name']) ?></strong></p>
        <p>Penjual: <?= e($order['seller_name']) ?> | Jumlah: <?= (int)$order['quantity'] ?></p>
        <p>Total: <strong>Rp <?= number_format((float)$order['total_amount'],0,',','.') ?></strong></p>
        <p>Metode: <?= e(strtoupper($order['payment_method'])) ?> - <?= e($order['payment_channel']) ?></p>
        <div class="qr-box-real"><?= $qr_svg ?><div class="qr-code-label"><?= e($order['transaction_code']) ?></div></div>
        <div class="payment-help-box"><i class="fa-solid fa-circle-info"></i><span>Ini QR simulasi untuk project lokal. Klik konfirmasi supaya status order sukses, stok berkurang, dan fee sistem masuk ke keuntungan super admin.</span></div>
        <?php if($order['status'] === 'pending'): ?>
        <form method="POST"><button class="btn-primary" name="confirm_product_payment" value="1">Konfirmasi Pembayaran Barang</button></form>
        <?php else: ?>
        <div class="alert-success">Status order: <?= e(productOrderStatusLabel($order['status'])) ?></div>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
