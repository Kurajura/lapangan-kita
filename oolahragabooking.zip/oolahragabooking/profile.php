<?php
include 'config/database.php';

$profile_id = (int) ($_GET['id'] ?? 0);
if ($profile_id <= 0 && isLoggedIn()) {
    $profile_id = getUserId();
}
if ($profile_id <= 0) {
    header("Location: login.php?error=Silakan login atau pilih profil user");
    exit();
}

$stmt = $pdo->prepare("SELECT id, player_code, username, email, full_name, display_name, phone, bio, profile_photo, show_rank_badges, role, created_at FROM users WHERE id = ?");
$stmt->execute([$profile_id]);
$profile = $stmt->fetch();
if (!$profile) {
    header("Location: index.php?error=Profil tidak ditemukan");
    exit();
}

$display_name = $profile['display_name'] ?: ($profile['full_name'] ?: $profile['username']);

$stmt = $pdo->prepare("SELECT COUNT(*) AS total_match,
                              SUM(points) AS total_points,
                              SUM(CASE WHEN winner = 'user' THEN 1 ELSE 0 END) AS menang,
                              SUM(CASE WHEN winner = 'draw' THEN 1 ELSE 0 END) AS seri,
                              SUM(CASE WHEN winner = 'opponent' THEN 1 ELSE 0 END) AS kalah
                       FROM match_results WHERE user_id = ?");
$stmt->execute([$profile_id]);
$stats = $stmt->fetch();

$stmt = $pdo->query("SELECT mr.user_id, mr.lapangan_id, l.nama_lapangan, l.jenis_olahraga,
                            COUNT(*) AS total_match,
                            SUM(mr.points) AS total_points,
                            SUM(CASE WHEN mr.winner = 'user' THEN 1 ELSE 0 END) AS menang,
                            SUM(mr.score_diff) AS total_diff
                     FROM match_results mr
                     JOIN lapangan l ON mr.lapangan_id = l.id
                     GROUP BY mr.user_id, mr.lapangan_id, l.nama_lapangan, l.jenis_olahraga
                     ORDER BY mr.lapangan_id ASC, total_points DESC, menang DESC, total_diff DESC, total_match DESC");
$allRows = $stmt->fetchAll();
$rank_badges = [];
$currentLap = null;
$rank = 0;
foreach ($allRows as $row) {
    if ($currentLap !== (int)$row['lapangan_id']) {
        $currentLap = (int)$row['lapangan_id'];
        $rank = 1;
    } else {
        $rank++;
    }
    if ((int)$row['user_id'] === $profile_id && $rank <= 10) {
        $row['rank_no'] = $rank;
        $rank_badges[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil <?= e($display_name) ?> - LapanganKita</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="top-header">
    <div class="promo-box"> Profil Pemain <span>PUBLIC</span></div>
    <div class="top-right">
        <?php if(isLoggedIn()): ?>
            <div class="user-info"><i class="fa-regular fa-user"></i> <?= htmlspecialchars($_SESSION['username']) ?> <a href="logout.php" style="color:#ff003c;">Logout</a></div>
        <?php else: ?>
            <a href="login.php" class="login-btn"><div class="login-icon"><i class="fa-regular fa-user"></i></div> Login</a>
            <a href="register.php" class="plan-btn">Daftar</a>
        <?php endif; ?>
    </div>
</div>
<?php renderNavbar(''); ?>

<div class="profile-page-wrap">
    <div class="profile-hero-card">
        <div class="profile-avatar-big">
            <?php if($profile['profile_photo']): ?>
                <img src="assets/profiles/<?= htmlspecialchars($profile['profile_photo']) ?>" alt="Foto Profil">
            <?php else: ?>
                <i class="fa-regular fa-user"></i>
            <?php endif; ?>
        </div>
        <div class="profile-main-info">
            <span class="mini-badge">ID <?= e($profile['player_code'] ?? '-') ?> · @<?= e($profile['username']) ?></span>
            <h1><?= e($display_name) ?></h1>
            <p><?= nl2br(e($profile['bio'] ?: 'Belum ada bio.')) ?></p>
            <div class="profile-actions">
                <?php if(isLoggedIn() && getUserId() === $profile_id): ?>
                    <a href="edit-profile.php" class="btn-primary"><i class="fa-solid fa-pen"></i> Edit Profil</a>
                <?php endif; ?>
                <a href="leaderboard.php" class="btn-secondary"><i class="fa-solid fa-trophy"></i> Lihat Leaderboard</a>
            </div>
        </div>
    </div>

    <div class="stats-grid public-stats-grid">
        <div class="stat-card"><i class="fa-solid fa-gamepad"></i><h2><?= (int)($stats['total_match'] ?? 0) ?></h2><p>Total Tanding</p></div>
        <div class="stat-card"><i class="fa-solid fa-trophy"></i><h2><?= (int)($stats['menang'] ?? 0) ?></h2><p>Menang</p></div>
        <div class="stat-card"><i class="fa-solid fa-star"></i><h2><?= (int)($stats['total_points'] ?? 0) ?></h2><p>Total Poin</p></div>
    </div>

    <div class="form-card">
        <h2>Lencana Top 10 Leaderboard</h2>
        <?php if((int)$profile['show_rank_badges'] !== 1): ?>
            <p class="helper-text">User ini menyembunyikan lencana leaderboard dari profilnya.</p>
        <?php elseif(count($rank_badges) > 0): ?>
            <div class="badge-grid">
                <?php foreach($rank_badges as $badge): ?>
                    <a class="rank-badge-card" href="leaderboard.php?lapangan_id=<?= $badge['lapangan_id'] ?>">
                        <i class="fa-solid fa-medal"></i>
                        <strong>No. <?= (int)$badge['rank_no'] ?> <?= htmlspecialchars($badge['jenis_olahraga']) ?></strong>
                        <span><?= htmlspecialchars($badge['nama_lapangan']) ?></span>
                        <small><?= (int)$badge['total_points'] ?> poin</small>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p class="helper-text">Belum masuk Top 10 leaderboard lapangan mana pun.</p>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
