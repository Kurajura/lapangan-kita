<?php
include 'config/database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $full_name = trim($_POST['full_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if ($username === '' || $email === '' || $password === '') {
        header("Location: register.php?error=Data wajib belum lengkap");
        exit();
    }
    if ($password !== $confirm_password) {
        header("Location: register.php?error=Password tidak cocok");
        exit();
    }
    if (strlen($password) < 6) {
        header("Location: register.php?error=Password minimal 6 karakter");
        exit();
    }

    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
    $stmt->execute([$username, $email]);
    if ($stmt->fetch()) {
        header("Location: register.php?error=Username atau email sudah terdaftar");
        exit();
    }

    try {
        $player_code = getNextPlayerCode($pdo);
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $display_name = $full_name !== '' ? $full_name : $username;
        $stmt = $pdo->prepare("INSERT INTO users (player_code, username, email, password, full_name, display_name, phone, role) VALUES (?, ?, ?, ?, ?, ?, ?, 'user')");
        $stmt->execute([$player_code, $username, $email, $hashed_password, $full_name, $display_name, $phone]);
        header("Location: login.php?success=" . urlencode("Registrasi berhasil. ID Pemain kamu: $player_code. Silakan login."));
        exit();
    } catch (Exception $e) {
        header("Location: register.php?error=" . urlencode('Registrasi gagal: ' . $e->getMessage()));
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar - LapanganKita</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="register-container auth-page-wrap">
    <div class="register-box auth-card-wide">
        <h1>Daftar Akun Pemain</h1>
        <p>Bergabung dengan LapanganKita. Setelah daftar, sistem otomatis membuat ID pemain 6 angka seperti 301901, 301902, dan seterusnya.</p>

        <?php if(isset($_GET['error'])): ?><div class="alert-error"><?= e($_GET['error']) ?></div><?php endif; ?>
        <?php if(isset($_GET['success'])): ?><div class="alert-success"><?= e($_GET['success']) ?></div><?php endif; ?>

        <form method="POST" action="" class="clean-form">
            <div class="form-group"><label>Username</label><input type="text" name="username" required></div>
            <div class="form-group"><label>Email</label><input type="email" name="email" required></div>
            <div class="form-group"><label>Nama Lengkap</label><input type="text" name="full_name"></div>
            <div class="form-group"><label>No. Telepon</label><input type="text" name="phone"></div>
            <div class="form-group"><label>Password</label><input type="password" name="password" minlength="6" required></div>
            <div class="form-group"><label>Konfirmasi Password</label><input type="password" name="confirm_password" minlength="6" required></div>
            <button type="submit" class="register-btn-submit">Daftar</button>
        </form>
        <div class="login-link auth-links">
            <p>Sudah punya akun? <a href="login.php">Login Sekarang</a></p>
            <p>Punya lapangan? <a href="daftar-admin.php">Daftar sebagai Admin Lapangan</a></p>
        </div>
    </div>
</div>
</body>
</html>
