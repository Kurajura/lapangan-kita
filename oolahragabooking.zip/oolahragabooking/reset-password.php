<?php
include 'config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $code = trim($_POST['reset_code'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if (!preg_match('/^[0-9]{6}$/', $code)) {
        header('Location: reset-password.php?error=' . urlencode('Kode reset harus 6 angka'));
        exit();
    }
    if ($password !== $confirm_password) {
        header('Location: reset-password.php?error=' . urlencode('Password tidak cocok'));
        exit();
    }
    if (strlen($password) < 6) {
        header('Location: reset-password.php?error=' . urlencode('Password minimal 6 karakter'));
        exit();
    }

    $stmt = $pdo->prepare("SELECT pr.*, u.username FROM password_resets pr JOIN users u ON pr.user_id = u.id WHERE pr.reset_code = ? AND pr.used = 0 AND pr.expires_at >= NOW() ORDER BY pr.id DESC LIMIT 1");
    $stmt->execute([$code]);
    $reset = $stmt->fetch();
    if (!$reset) {
        header('Location: reset-password.php?error=' . urlencode('Kode reset salah, sudah dipakai, atau kedaluwarsa'));
        exit();
    }

    try {
        $pdo->beginTransaction();
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $pdo->prepare("UPDATE users SET password = ? WHERE id = ?")->execute([$hash, $reset['user_id']]);
        $pdo->prepare("UPDATE password_resets SET used = 1 WHERE id = ?")->execute([$reset['id']]);
        $pdo->commit();
        header('Location: login.php?success=' . urlencode('Password berhasil direset. Silakan login dengan password baru.'));
        exit();
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        header('Location: reset-password.php?error=' . urlencode('Reset password gagal'));
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - LapanganKita</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="auth-page-wrap login-container">
    <div class="auth-card-wide login-box">
        <h1>Reset Password</h1>
        <p>Masukkan kode 6 angka dan password baru.</p>
        <?php if(isset($_GET['error'])): ?><div class="alert-error"><?= e($_GET['error']) ?></div><?php endif; ?>
        <form method="POST" class="clean-form">
            <div class="form-group"><label>Kode Reset</label><input type="text" name="reset_code" maxlength="6" pattern="[0-9]{6}" required></div>
            <div class="form-group"><label>Password Baru</label><input type="password" name="password" minlength="6" required></div>
            <div class="form-group"><label>Konfirmasi Password Baru</label><input type="password" name="confirm_password" minlength="6" required></div>
            <button type="submit" class="btn-primary" style="width:100%;">Reset Password</button>
        </form>
        <div class="auth-links"><p>Belum punya kode? <a href="forgot-password.php">Buat kode reset</a></p></div>
    </div>
</div>
</body>
</html>
