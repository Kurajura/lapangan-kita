<?php 
include 'config/database.php';
if (!isLoggedIn()) {
    header("Location: login.php?error=Silakan login terlebih dahulu");
    exit();
}
$user_id = getUserId();
$role = getUserRole();

if ($role == 'super_admin') {
    $stmt = $pdo->query("SELECT b.*, l.nama_lapangan, l.jenis_olahraga, u.username as user_name, u2.username as admin_name,
                         COALESCE(NULLIF(b.nama_pelanggan, ''), u.username) AS nama_customer,
                         mr.id AS match_result_id, mr.user_score, mr.opponent_score, mr.points, mr.winner
                         FROM bookings b JOIN lapangan l ON b.lapangan_id = l.id JOIN users u ON b.user_id = u.id JOIN users u2 ON l.admin_id = u2.id
                         LEFT JOIN match_results mr ON mr.booking_id = b.id AND mr.user_id = b.user_id 
                         ORDER BY b.tanggal DESC, b.jam_mulai DESC, b.created_at DESC");
} elseif ($role == 'admin') {
    $stmt = $pdo->prepare("SELECT b.*, l.nama_lapangan, l.jenis_olahraga, u.username as user_name,
                           COALESCE(NULLIF(b.nama_pelanggan, ''), u.username) AS nama_customer,
                           mr.id AS match_result_id, mr.user_score, mr.opponent_score, mr.points, mr.winner
                           FROM bookings b JOIN lapangan l ON b.lapangan_id = l.id JOIN users u ON b.user_id = u.id
                           LEFT JOIN match_results mr ON mr.booking_id = b.id AND mr.user_id = b.user_id 
                           WHERE l.admin_id = ? ORDER BY b.tanggal DESC, b.jam_mulai DESC, b.created_at DESC");
    $stmt->execute([$user_id]);
} else {
    $stmt = $pdo->prepare("SELECT b.*, l.nama_lapangan, l.jenis_olahraga, u.username as admin_name,
                           mr.id AS match_result_id, mr.user_score, mr.opponent_score, mr.points, mr.winner
                           FROM bookings b JOIN lapangan l ON b.lapangan_id = l.id JOIN users u ON l.admin_id = u.id
                           LEFT JOIN match_results mr ON mr.booking_id = b.id AND mr.user_id = b.user_id 
                           WHERE b.user_id = ? AND (b.booking_source IS NULL OR b.booking_source = 'online')
                           ORDER BY b.tanggal DESC, b.jam_mulai DESC, b.created_at DESC");
    $stmt->execute([$user_id]);
}
$bookings = $stmt->fetchAll();

$participant_map = [];
$team_map = [];
if ($bookings) {
    $ids = array_map(fn($b) => (int)$b['id'], $bookings);
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmtParticipants = $pdo->prepare("SELECT mp.*, COALESCE(NULLIF(u.display_name,''), NULLIF(u.full_name,''), u.username) AS player_name, u.player_code, u.username
                                      FROM match_participants mp JOIN users u ON mp.user_id = u.id
                                      WHERE mp.booking_id IN ($placeholders) ORDER BY mp.team ASC, mp.is_captain DESC, u.username ASC");
    $stmtParticipants->execute($ids);
    foreach ($stmtParticipants->fetchAll() as $part) $participant_map[(int)$part['booking_id']][] = $part;
    $teamIds = [];
    foreach ($bookings as $b) { if (!empty($b['requester_team_id'])) $teamIds[]=(int)$b['requester_team_id']; if (!empty($b['opponent_team_id'])) $teamIds[]=(int)$b['opponent_team_id']; }
    $teamIds = array_values(array_unique(array_filter($teamIds)));
    if ($teamIds) {
        $ph = implode(',', array_fill(0, count($teamIds), '?'));
        $st = $pdo->prepare("SELECT * FROM teams WHERE id IN ($ph)");
        $st->execute($teamIds);
        foreach($st->fetchAll() as $t) $team_map[(int)$t['id']] = $t;
    }
}
function renderTeamListUser($participants, $team) {
    $items = array_filter($participants ?? [], fn($p) => $p['team'] === $team);
    if (!$items) return '<small class="small-muted">Belum ada pemain</small>';
    $html = '<div class="team-mini-list">';
    foreach ($items as $p) {
        $badge = $p['status'] === 'accepted' ? 'completed' : ($p['status'] === 'rejected' ? 'rejected' : 'waiting');
        $html .= '<span><b>' . e($p['player_name']) . '</b> <small>ID ' . e($p['player_code']) . '</small> <em class="match-badge ' . $badge . '">' . e($p['status']) . '</em></span>';
    }
    return $html . '</div>';
}
$pendingInviteCount = 0;
if ($role === 'user') {
    $stmtPending = $pdo->prepare("SELECT
        (SELECT COUNT(*) FROM match_participants WHERE user_id=? AND status='pending' AND is_captain=0) +
        (SELECT COUNT(*) FROM team_members WHERE user_id=? AND status='pending' AND is_captain=0) +
        (SELECT COUNT(*) FROM team_match_requests tr JOIN teams t ON tr.opponent_team_id=t.id WHERE t.captain_id=? AND tr.status='pending') AS total");
    $stmtPending->execute([$user_id,$user_id,$user_id]);
    $pendingInviteCount = (int)$stmtPending->fetchColumn();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Riwayat Booking - LapanganKita</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"><link rel="stylesheet" href="assets/css/style.css">
<style>.riwayat-container{padding:180px 7% 100px}.status-badge{display:inline-block;padding:4px 12px;border-radius:20px;font-size:12px;font-weight:bold}.status-pending{background:#ff9800;color:#000}.status-paid{background:#2196f3;color:#fff}.status-confirmed{background:#4caf50;color:#fff}.status-cancelled{background:#f44336;color:#fff}</style>
</head>
<body>
<div class="top-header"><div class="promo-box">Riwayat Booking <span><?= userHasActiveVip($pdo) ? 'VIP AKTIF' : 'PREMIUM' ?></span></div><div class="top-right"><div class="user-info"><i class="fa-regular fa-user"></i> <?= e($_SESSION['username']) ?> <a href="logout.php" style="color:#ff003c;">Logout</a></div></div></div>
<?php renderNavbar(''); ?>
<div class="riwayat-container">
    <div class="page-header" style="padding-top:0"><h1>Riwayat Booking</h1><p>Semua transaksi booking lapangan Anda</p></div>
    <?php if(isset($_GET['success'])): ?><div class="alert-success"><?= e($_GET['success']) ?></div><?php endif; ?>
    <?php if(isset($_GET['error'])): ?><div class="alert-error"><?= e($_GET['error']) ?></div><?php endif; ?>
    <?php if($pendingInviteCount > 0): ?><div class="match-notification"><i class="fa-solid fa-handshake"></i> Kamu punya <strong><?= $pendingInviteCount ?></strong> undangan/tantangan. <a href="match-invitations.php">Lihat dan konfirmasi</a></div><?php endif; ?>
    <?php if($role==='user' && !userHasActiveVip($pdo)): ?><div class="vip-warning-box"><i class="fa-solid fa-crown"></i><span>Mode tanding sekarang khusus VIP. Aktifkan VIP untuk tanding solo/team dan dapat diskon booking.</span><a href="vip.php" class="btn-primary small-btn">Aktifkan VIP</a></div><?php endif; ?>
    <div class="form-card"><div class="table-responsive"><table class="data-table"><thead><tr>
        <th>Kode</th><?php if($role!='user'): ?><th>Sumber</th><?php endif; ?><th>Lapangan</th><th>No.</th>
        <?php if($role=='super_admin'): ?><th>Customer</th><th>Admin</th><?php elseif($role=='admin'): ?><th>Customer</th><?php else: ?><th>Admin</th><?php endif; ?>
        <th>Tanggal</th><th>Jam</th><th>Total</th><th>Mode Tanding</th><th>Status</th><th>Aksi</th>
    </tr></thead><tbody>
    <?php foreach($bookings as $booking): ?>
        <?php $parts=$participant_map[(int)$booking['id']]??[]; $matchStatus=$booking['match_status']??'inactive'; $paid=in_array($booking['status'],['paid','confirmed'],true)&&($booking['payment_status']??'')==='paid'; ?>
        <tr>
            <td><?= e($booking['booking_code']) ?></td>
            <?php if($role!='user'): ?><td><span class="source-badge <?= e($booking['booking_source'] ?? 'online') ?>"><?= ($booking['booking_source'] ?? 'online')==='offline'?'Offline':'Online' ?></span></td><?php endif; ?>
            <td><?= e($booking['nama_lapangan']) ?><br><small><?= e($booking['jenis_olahraga'] ?? '') ?></small></td><td>Lapangan <?= (int)$booking['nomor_lapangan'] ?></td>
            <?php if($role=='super_admin'): ?><td><?= e($booking['nama_customer']) ?></td><td><?= e($booking['admin_name']) ?></td><?php elseif($role=='admin'): ?><td><?= e($booking['nama_customer']) ?></td><?php else: ?><td><?= e($booking['admin_name']) ?></td><?php endif; ?>
            <td><?= date('d/m/Y', strtotime($booking['tanggal'])) ?></td><td><?= substr($booking['jam_mulai'],0,5) ?> - <?= substr($booking['jam_selesai'],0,5) ?></td>
            <td>Rp <?= number_format($booking['total_harga'],0,',','.') ?><?php if((float)($booking['vip_discount_amount']??0)>0): ?><br><small>VIP hemat Rp <?= number_format($booking['vip_discount_amount'],0,',','.') ?></small><?php endif; ?></td>
            <td>
                <?php if((int)($booking['match_enabled']??0)===1): ?>
                    <?php if($booking['match_result_id']): ?><span class="match-badge completed">Selesai</span><br><small>Skor kamu: <?= (int)$booking['user_score'] ?> - <?= (int)$booking['opponent_score'] ?> | <?= (int)$booking['points'] ?> poin</small>
                    <?php else: ?><span class="match-badge <?= $matchStatus==='rejected'?'rejected':'waiting' ?>"><?= e(str_replace('_',' ',ucfirst($matchStatus))) ?></span><br>
                        <?php if($matchStatus==='team_setup'): ?><small>Menunggu anggota team setuju.</small><?php elseif($matchStatus==='team_ready'): ?><small>Team aktif. Pilih team lawan.</small><?php elseif($matchStatus==='pending_opponent_team'): ?><small>Menunggu captain team lawan setuju.</small><?php elseif($matchStatus==='pending_approval'): ?><small>Menunggu persetujuan lawan.</small><?php elseif($matchStatus==='waiting_score'): ?><small>Siap dimainkan. Menunggu admin input skor.</small><?php elseif($matchStatus==='rejected'): ?><small><?= e($booking['match_rejected_reason'] ?: 'Permintaan ditolak.') ?></small><?php endif; ?>
                    <?php endif; ?>
                    <?php if(($booking['match_type']??'solo')==='team'): ?>
                        <div class="admin-teams-box"><strong>Team 1</strong><small><?= e($team_map[(int)($booking['requester_team_id']??0)]['team_name'] ?? '-') ?> <?= !empty($team_map[(int)($booking['requester_team_id']??0)]['team_code']) ? '(' . e($team_map[(int)$booking['requester_team_id']]['team_code']) . ')' : '' ?></small><?= renderTeamListUser($parts,'challenger') ?><strong>Team 2</strong><small><?= e($team_map[(int)($booking['opponent_team_id']??0)]['team_name'] ?? '-') ?></small><?= renderTeamListUser($parts,'opponent') ?></div>
                    <?php else: ?>
                        <div class="admin-teams-box"><strong>User 1</strong><?= renderTeamListUser($parts,'challenger') ?><strong>User 2</strong><?= renderTeamListUser($parts,'opponent') ?></div>
                    <?php endif; ?>
                    <?php if($role==='user' && ($booking['match_type']??'solo')==='team' && in_array($matchStatus,['team_ready','rejected'],true) && !$booking['match_result_id']): ?><a href="team-tanding.php?booking_id=<?= (int)$booking['id'] ?>" class="btn-secondary small-btn">Kelola Team</a><?php endif; ?>
                <?php elseif($role==='user' && $paid && !$booking['match_result_id']): ?>
                    <?php if(userHasActiveVip($pdo)): ?>
                        <div class="match-choice-box"><a href="aktifkan-tanding.php?booking_id=<?= (int)$booking['id'] ?>" class="btn-primary small-btn"><i class="fa-solid fa-user"></i> Tanding Solo</a><a href="team-tanding.php?booking_id=<?= (int)$booking['id'] ?>" class="btn-secondary small-btn"><i class="fa-solid fa-users"></i> Tanding Team</a></div>
                    <?php else: ?><span class="match-badge inactive">VIP Required</span><br><a href="vip.php" class="btn-primary small-btn">Aktifkan VIP</a><?php endif; ?>
                <?php else: ?><span class="match-badge inactive">Nonaktif</span><?php endif; ?>
            </td>
            <td><span class="status-badge status-<?= e($booking['status']) ?>"><?= e(ucfirst($booking['status'])) ?></span></td>
            <td><?php if($booking['status']=='confirmed'||$booking['status']=='paid'): ?><a href="cetak-struk.php?booking_id=<?= (int)$booking['id'] ?>" class="btn-secondary small-btn">Cetak</a><?php endif; ?></td>
        </tr>
    <?php endforeach; ?>
    <?php if(count($bookings)==0): ?><tr><td colspan="<?= $role=='user'?10:11 ?>" style="text-align:center">Belum ada riwayat booking</td></tr><?php endif; ?>
    </tbody></table></div></div>
</div>
</body></html>
