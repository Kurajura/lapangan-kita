<?php
include 'config/database.php';
header('Content-Type: application/json; charset=utf-8');

$q = trim($_GET['q'] ?? '');
if (mb_strlen($q) < 2) {
    echo json_encode([]);
    exit();
}

$keyword = '%' . $q . '%';
$stmt = $pdo->prepare("SELECT l.id, l.nama_lapangan, l.jenis_olahraga, l.alamat, l.wilayah, l.kabupaten, l.harga_per_jam, l.foto, l.jumlah_lapangan,
                              u.full_name AS admin_name
                       FROM lapangan l
                       JOIN users u ON l.admin_id = u.id
                       WHERE l.status = 'aktif'
                       AND (
                           l.nama_lapangan LIKE ? OR
                           l.jenis_olahraga LIKE ? OR
                           l.alamat LIKE ? OR
                           l.wilayah LIKE ? OR
                           l.kabupaten LIKE ? OR
                           l.deskripsi LIKE ? OR
                           u.full_name LIKE ?
                       )
                       ORDER BY
                           CASE WHEN l.nama_lapangan LIKE ? THEN 0 ELSE 1 END,
                           CASE WHEN l.jenis_olahraga LIKE ? THEN 0 ELSE 1 END,
                           l.created_at DESC
                       LIMIT 8");
$stmt->execute([$keyword, $keyword, $keyword, $keyword, $keyword, $keyword, $keyword, $keyword, $keyword]);
$rows = $stmt->fetchAll();

echo json_encode($rows, JSON_UNESCAPED_UNICODE);
