<?php
include 'config/database.php';
header('Content-Type: application/json; charset=utf-8');

$q = trim($_GET['q'] ?? '');
if ($q === '') {
    echo json_encode([]);
    exit();
}
$like = '%' . $q . '%';
$stmt = $pdo->prepare("SELECT id, player_code, username, full_name, display_name, profile_photo
                       FROM users
                       WHERE role = 'user'
                       AND (player_code LIKE ? OR username LIKE ? OR full_name LIKE ? OR display_name LIKE ?)
                       ORDER BY CASE WHEN player_code = ? OR username = ? THEN 0 ELSE 1 END, username ASC
                       LIMIT 10");
$stmt->execute([$like, $like, $like, $like, $q, $q]);
$rows = [];
foreach ($stmt->fetchAll() as $r) {
    $rows[] = [
        'id' => (int)$r['id'],
        'player_code' => $r['player_code'],
        'username' => $r['username'],
        'name' => getPlayerPublicName($r),
        'label' => getPlayerPublicName($r) . ' (@' . $r['username'] . ') - ID ' . $r['player_code']
    ];
}
echo json_encode($rows);
