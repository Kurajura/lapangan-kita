<?php 
include '../config/database.php';
if (!isLoggedIn() || !isSuperAdmin()) {
    header("Location: ../login.php");
    exit();
}

// Tambah admin baru
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_admin'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $full_name = $_POST['full_name'];
    $phone = $_POST['phone'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    
    $stmt = $pdo->prepare("INSERT INTO users (username, email, password, full_name, phone, role) VALUES (?, ?, ?, ?, ?, 'admin')");
    if ($stmt->execute([$username, $email, $password, $full_name, $phone])) {
        $success = "Admin berhasil ditambahkan";
    } else {
        $error = "Gagal menambahkan admin";
    }
}

// Hapus admin
if (isset($_GET['delete'])) {
    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ? AND role = 'admin'");
    $stmt->execute([$_GET['delete']]);
    header("Location: admins.php");
    exit();
}

$stmt = $pdo->query("SELECT * FROM users WHERE role = 'admin' ORDER BY created_at DESC");
$admins = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Admin - Super Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="top-header">
    <div class="promo-box"> Kelola Admin <span>SUPER ADMIN</span></div>
    <div class="top-right">
        <div class="user-info">
            <i class="fa-regular fa-user"></i> <?= $_SESSION['username'] ?>
            <a href="../logout.php" style="color:#ff003c;">Logout</a>
        </div>
    </div>
</div>
<?php renderNavbar('../'); ?>

<div class="dashboard-wrapper">
    <div class="sidebar">
        <h2>Super Admin Menu</h2>
        <a href="dashboard.php"><i class="fa-solid fa-chart-line"></i> Dashboard</a>
        <a href="admins.php" class="active"><i class="fa-solid fa-user-shield"></i> Kelola Admin</a>
        <a href="users.php"><i class="fa-solid fa-users"></i> Kelola User</a>
        <a href="lapangan.php"><i class="fa-solid fa-futbol"></i> Semua Lapangan</a>
        <a href="bookings.php"><i class="fa-solid fa-calendar-check"></i> Semua Booking</a>
        <a href="transactions.php"><i class="fa-solid fa-credit-card"></i> Semua Transaksi</a>
        <a href="../logout.php"><i class="fa-solid fa-sign-out-alt"></i> Logout</a>
    </div>
    
    <div class="main-content">
        <h1>Kelola Admin Lapangan</h1>
        
        <?php if(isset($success)): ?>
            <div class="alert-success"><?= $success ?></div>
        <?php endif; ?>
        <?php if(isset($error)): ?>
            <div class="alert-error"><?= $error ?></div>
        <?php endif; ?>
        
        <div class="form-card">
            <h2>Tambah Admin Baru</h2>
            <form method="POST">
                <input type="text" name="username" placeholder="Username" required>
                <input type="email" name="email" placeholder="Email" required>
                <input type="text" name="full_name" placeholder="Nama Lengkap">
                <input type="text" name="phone" placeholder="No. Telepon">
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit" name="add_admin" class="btn-primary">Tambah Admin</button>
            </form>
        </div>
        
        <div class="form-card">
            <h2>Daftar Admin Lapangan</h2>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Nama</th>
                        <th>Telepon</th>
                        <th>Bergabung</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($admins as $admin): ?>
                    <tr>
                        <td><?= htmlspecialchars($admin['username']) ?></td>
                        <td><?= htmlspecialchars($admin['email']) ?></td>
                        <td><?= htmlspecialchars($admin['full_name'] ?: '-') ?></td>
                        <td><?= htmlspecialchars($admin['phone'] ?: '-') ?></td>
                        <td><?= date('d/m/Y', strtotime($admin['created_at'])) ?></td>
                        <td>
                            <a href="?delete=<?= $admin['id'] ?>" class="btn-danger" onclick="return confirm('Yakin hapus admin ini?')">Hapus</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</body>
</html>