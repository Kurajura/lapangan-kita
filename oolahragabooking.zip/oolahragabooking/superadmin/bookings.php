<?php 
include '../config/database.php';
if (!isLoggedIn() || !isSuperAdmin()) {
    header("Location: ../login.php");
    exit();
}
function redirectBookingsSA($msg, $type='success') { header('Location: bookings.php?' . $type . '=' . urlencode($msg)); exit(); }

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $booking_id = (int)($_POST['booking_id'] ?? 0);
    $status = $_POST['status'] ?? '';
    if (!in_array($status, ['pending','paid','confirmed','cancelled'], true)) redirectBookingsSA('Status tidak valid', 'error');
    syncTransactionFromBookingStatus($pdo, $booking_id, $status);
    redirectBookingsSA('Status booking berhasil diupdate. Jika cancel, jadwal otomatis bisa dibooking lagi.');
}

if (isset($_GET['delete'])) {
    $booking_id = (int)$_GET['delete'];
    $pdo->prepare("DELETE FROM transactions WHERE booking_id = ?")->execute([$booking_id]);
    $pdo->prepare("DELETE FROM match_results WHERE booking_id = ?")->execute([$booking_id]);
    $pdo->prepare("DELETE FROM match_participants WHERE booking_id = ?")->execute([$booking_id]);
    $pdo->prepare("DELETE FROM bookings WHERE id = ?")->execute([$booking_id]);
    redirectBookingsSA('Booking berhasil dihapus');
}

$stmt = $pdo->query("SELECT b.*, l.nama_lapangan, l.jenis_olahraga, u.username as user_name, u2.username as admin_name,
                     COALESCE(NULLIF(b.nama_pelanggan, ''), u.username) AS nama_customer,
                     mr.id AS match_result_id, mr.user_score, mr.opponent_score, mr.points
                     FROM bookings b 
                     JOIN lapangan l ON b.lapangan_id = l.id 
                     JOIN users u ON b.user_id = u.id 
                     JOIN users u2 ON l.admin_id = u2.id
                     LEFT JOIN match_results mr ON mr.booking_id = b.id AND mr.user_id = b.user_id
                     ORDER BY b.tanggal DESC, b.jam_mulai DESC, b.created_at DESC");
$bookings = $stmt->fetchAll();
?>
<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Kelola Semua Booking - Super Admin</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"><link rel="stylesheet" href="../assets/css/style.css">
<style>.admin-summary-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:16px;margin:20px 0}.admin-mini-card{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);border-radius:18px;padding:16px}.admin-mini-card strong{display:block;color:#00ffb3;font-size:26px}.status-select{padding:8px 12px;border-radius:12px;border:1px solid rgba(255,255,255,.14);background:rgba(255,255,255,.08);color:#fff}.data-table td{vertical-align:top}.action-cell{display:flex;gap:8px;flex-wrap:wrap}.status-cancelled{background:#f44336;color:#fff}</style>
</head><body><div class="top-header"><div class="promo-box">Kelola Semua Booking <span>SUPER ADMIN</span></div><div class="top-right"><div class="user-info"><i class="fa-regular fa-user"></i> <?= e($_SESSION['username']) ?> <a href="../logout.php" style="color:#ff003c;">Logout</a></div></div></div>
<?php renderNavbar('../'); ?>
<div class="dashboard-wrapper"><div class="sidebar"><h2>Super Admin Menu</h2><a href="dashboard.php"><i class="fa-solid fa-chart-line"></i> Dashboard</a><a href="admins.php"><i class="fa-solid fa-user-shield"></i> Kelola Admin</a><a href="users.php"><i class="fa-solid fa-users"></i> Kelola User</a><a href="lapangan.php"><i class="fa-solid fa-futbol"></i> Kelola Lapangan</a><a href="bookings.php" class="active"><i class="fa-solid fa-calendar-check"></i> Kelola Booking</a><a href="transactions.php"><i class="fa-solid fa-credit-card"></i> Kelola Transaksi</a><a href="profit.php"><i class="fa-solid fa-coins"></i> Keuntungan Sistem</a><a href="../marketplace.php"><i class="fa-solid fa-store"></i> Market Olahraga</a><a href="../logout.php"><i class="fa-solid fa-sign-out-alt"></i> Logout</a></div>
<div class="main-content"><h1>Kelola Semua Booking</h1><p>Semua booking online/offline dari semua admin. Cancel booking otomatis membuka jadwal kembali.</p>
<?php if(isset($_GET['success'])): ?><div class="alert-success"><?= e($_GET['success']) ?></div><?php endif; ?><?php if(isset($_GET['error'])): ?><div class="alert-error"><?= e($_GET['error']) ?></div><?php endif; ?>
<div class="admin-summary-grid"><div class="admin-mini-card"><small>Total Booking</small><strong><?= count($bookings) ?></strong></div><div class="admin-mini-card"><small>Confirmed/Paid</small><strong><?= count(array_filter($bookings, fn($x)=>in_array($x['status'],['paid','confirmed'],true))) ?></strong></div><div class="admin-mini-card"><small>Pending</small><strong><?= count(array_filter($bookings, fn($x)=>$x['status']==='pending')) ?></strong></div><div class="admin-mini-card"><small>Cancel</small><strong><?= count(array_filter($bookings, fn($x)=>$x['status']==='cancelled')) ?></strong></div></div>
<div class="form-card"><h2>Daftar Booking</h2><div class="table-responsive"><table class="data-table"><thead><tr><th>Kode</th><th>Sumber</th><th>Customer</th><th>Admin</th><th>Lapangan</th><th>Jadwal</th><th>Total</th><th>Status</th><th>Mode Tanding</th><th>Aksi</th></tr></thead><tbody>
<?php foreach($bookings as $b): ?><tr><td><strong><?= e($b['booking_code']) ?></strong><br><small>ID #<?= (int)$b['id'] ?></small></td><td><span class="source-badge <?= e($b['booking_source'] ?? 'online') ?>"><?= ($b['booking_source'] ?? 'online')==='offline'?'Offline':'Online' ?></span></td><td><?= e($b['nama_customer']) ?><br><small><?= e($b['user_name']) ?></small></td><td><?= e($b['admin_name']) ?></td><td><?= e($b['nama_lapangan']) ?><br><small><?= e($b['jenis_olahraga']) ?> | Lapangan <?= (int)$b['nomor_lapangan'] ?></small></td><td><?= date('d/m/Y', strtotime($b['tanggal'])) ?><br><small><?= substr($b['jam_mulai'],0,5) ?> - <?= substr($b['jam_selesai'],0,5) ?></small></td><td>Rp <?= number_format($b['total_harga'],0,',','.') ?><br><small>Payment: <?= e($b['payment_status']) ?></small></td><td><form method="POST"><input type="hidden" name="booking_id" value="<?= (int)$b['id'] ?>"><select name="status" class="status-select" onchange="if(confirm('Update status booking ini?')) this.form.submit(); else this.value='<?= e($b['status']) ?>';"><option value="pending" <?= $b['status']==='pending'?'selected':'' ?>>Pending</option><option value="paid" <?= $b['status']==='paid'?'selected':'' ?>>Paid</option><option value="confirmed" <?= $b['status']==='confirmed'?'selected':'' ?>>Confirmed</option><option value="cancelled" <?= $b['status']==='cancelled'?'selected':'' ?>>Cancelled</option></select><input type="hidden" name="update_status" value="1"></form></td><td><?php if((int)($b['match_enabled']??0)===1): ?><span class="match-badge <?= $b['match_status']==='completed'?'completed':($b['match_status']==='rejected'?'rejected':'waiting') ?>"><?= e(str_replace('_',' ',$b['match_status'])) ?></span><br><small><?= e($b['match_type'] ?? 'solo') ?></small><?php if($b['match_result_id']): ?><br><small>Skor <?= (int)$b['user_score'] ?> - <?= (int)$b['opponent_score'] ?></small><?php endif; ?><?php else: ?><span class="match-badge inactive">Nonaktif</span><?php endif; ?></td><td class="action-cell"><a href="../cetak-struk.php?booking_id=<?= (int)$b['id'] ?>" class="btn-secondary small-btn">Cetak</a><a href="?delete=<?= (int)$b['id'] ?>" class="btn-danger small-btn" onclick="return confirm('Yakin hapus booking ini? Data transaksi dan match terkait ikut hilang.')">Hapus</a></td></tr><?php endforeach; ?>
<?php if(!$bookings): ?><tr><td colspan="10" style="text-align:center">Belum ada booking</td></tr><?php endif; ?></tbody></table></div></div>
</div></div></body></html>
