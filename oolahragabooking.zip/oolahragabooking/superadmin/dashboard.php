<?php 
include '../config/database.php';
if (!isLoggedIn() || !isSuperAdmin()) {
    header("Location: ../login.php");
    exit();
}

// Statistik super admin
$stmt = $pdo->query("SELECT COUNT(*) as total_users FROM users");
$total_users = $stmt->fetch()['total_users'];

$stmt = $pdo->query("SELECT COUNT(*) as total_admins FROM users WHERE role = 'admin'");
$total_admins = $stmt->fetch()['total_admins'];

$stmt = $pdo->query("SELECT COUNT(*) as total_lapangan FROM lapangan");
$total_lapangan = $stmt->fetch()['total_lapangan'];

$stmt = $pdo->query("SELECT COUNT(*) as total_bookings FROM bookings");
$total_bookings = $stmt->fetch()['total_bookings'];

$stmt = $pdo->query("SELECT SUM(amount) as total_revenue FROM transactions WHERE status = 'success'");
$total_revenue = $stmt->fetch()['total_revenue'];
$stmt = $pdo->query("SELECT COALESCE(SUM(platform_fee),0) AS profit FROM bookings WHERE status <> 'cancelled'");
$booking_profit = (float)$stmt->fetch()['profit'];
$product_profit = 0;
if (tableExists($pdo, 'product_orders')) {
    $stmt = $pdo->query("SELECT COALESCE(SUM(platform_fee),0) AS profit FROM product_orders WHERE status='success'");
    $product_profit = (float)$stmt->fetch()['profit'];
}
$vip_profit = 0;
if (tableExists($pdo, 'vip_orders')) {
    $stmt = $pdo->query("SELECT COALESCE(SUM(amount),0) AS profit FROM vip_orders WHERE status='success'");
    $vip_profit = (float)$stmt->fetch()['profit'];
}
$total_system_profit = $booking_profit + $product_profit + $vip_profit;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Super Admin Dashboard - LapanganKita</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="top-header">
    <div class="promo-box"> Super Admin <span>CONTROL</span></div>
    <div class="top-right">
        <div class="user-info">
            <i class="fa-regular fa-user"></i> <?= $_SESSION['username'] ?>
            <span style="background:#ff003c; padding:2px 8px; border-radius:20px;">Super Admin</span>
            <a href="../logout.php" style="color:#ff003c;">Logout</a>
        </div>
    </div>
</div>
<?php renderNavbar('../'); ?>

<div class="dashboard-wrapper">
    <div class="sidebar">
        <h2>Super Admin Menu</h2>
        <a href="dashboard.php" class="active"><i class="fa-solid fa-chart-line"></i> Dashboard</a>
        <a href="admins.php"><i class="fa-solid fa-user-shield"></i> Kelola Admin</a>
        <a href="users.php"><i class="fa-solid fa-users"></i> Kelola User</a>
        <a href="lapangan.php"><i class="fa-solid fa-futbol"></i> Semua Lapangan</a>
        <a href="bookings.php"><i class="fa-solid fa-calendar-check"></i> Semua Booking</a>
        <a href="transactions.php"><i class="fa-solid fa-credit-card"></i> Semua Transaksi</a>
        <a href="profit.php"><i class="fa-solid fa-coins"></i> Keuntungan Sistem</a><a href="../marketplace.php"><i class="fa-solid fa-store"></i> Market Olahraga</a><a href="../logout.php"><i class="fa-solid fa-sign-out-alt"></i> Logout</a>
    </div>
    
    <div class="main-content">
        <h1>Super Admin Dashboard</h1>
        <p>Kontrol penuh seluruh sistem LapanganKita</p>
        
        <div class="stats-grid">
            <div class="stat-card">
                <i class="fa-solid fa-users"></i>
                <h2><?= $total_users ?></h2>
                <p>Total User</p>
            </div>
            <div class="stat-card">
                <i class="fa-solid fa-user-shield"></i>
                <h2><?= $total_admins ?></h2>
                <p>Total Admin</p>
            </div>
            <div class="stat-card">
                <i class="fa-solid fa-futbol"></i>
                <h2><?= $total_lapangan ?></h2>
                <p>Total Lapangan</p>
            </div>
            <div class="stat-card">
                <i class="fa-solid fa-calendar-check"></i>
                <h2><?= $total_bookings ?></h2>
                <p>Total Booking</p>
            </div>
            <div class="stat-card">
                <i class="fa-solid fa-money-bill-wave"></i>
                <h2>Rp <?= number_format($total_revenue ?: 0, 0, ',', '.') ?></h2>
                <p>Total Transaksi Booking</p>
            </div>
            <div class="stat-card">
                <i class="fa-solid fa-coins"></i>
                <h2>Rp <?= number_format($total_system_profit ?: 0, 0, ',', '.') ?></h2>
                <p>Keuntungan Sistem</p>
            </div>
        </div>
    </div>
</div>
</body>
</html>