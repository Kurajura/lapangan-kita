<?php 
include '../config/database.php';
if (!isLoggedIn() || !isSuperAdmin()) { header("Location: ../login.php"); exit(); }
function redirectLapSA($msg,$type='success'){ header('Location: lapangan.php?'.$type.'='.urlencode($msg)); exit(); }

if (isset($_GET['delete'])) {
    $lapangan_id = (int)$_GET['delete'];
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare("SELECT id FROM bookings WHERE lapangan_id = ?");
        $stmt->execute([$lapangan_id]);
        $booking_ids = $stmt->fetchAll(PDO::FETCH_COLUMN);
        if ($booking_ids) {
            $ph = implode(',', array_fill(0, count($booking_ids), '?'));
            $pdo->prepare("DELETE FROM transactions WHERE booking_id IN ($ph)")->execute($booking_ids);
            $pdo->prepare("DELETE FROM match_results WHERE booking_id IN ($ph)")->execute($booking_ids);
            $pdo->prepare("DELETE FROM match_participants WHERE booking_id IN ($ph)")->execute($booking_ids);
            $pdo->prepare("DELETE FROM team_match_requests WHERE booking_id IN ($ph)")->execute($booking_ids);
            $pdo->prepare("DELETE FROM bookings WHERE id IN ($ph)")->execute($booking_ids);
        }
        $pdo->prepare("DELETE FROM lapangan_tutup WHERE lapangan_id = ?")->execute([$lapangan_id]);
        $pdo->prepare("DELETE FROM lapangan WHERE id = ?")->execute([$lapangan_id]);
        $pdo->commit(); redirectLapSA('Lapangan berhasil dihapus');
    } catch(Exception $e) { if($pdo->inTransaction()) $pdo->rollBack(); redirectLapSA('Lapangan gagal dihapus: '.$e->getMessage(),'error'); }
}
if (isset($_GET['delete_tutup'])) { $pdo->prepare("DELETE FROM lapangan_tutup WHERE id = ?")->execute([(int)$_GET['delete_tutup']]); redirectLapSA('Jadwal tutup berhasil dihapus'); }
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['update_status'])) {
    $status = $_POST['status'] ?? 'aktif';
    if(!in_array($status,['aktif','nonaktif'],true)) redirectLapSA('Status tidak valid','error');
    $pdo->prepare("UPDATE lapangan SET status = ? WHERE id = ?")->execute([$status,(int)$_POST['lapangan_id']]);
    redirectLapSA('Status lapangan berhasil diupdate');
}

$lapangan = $pdo->query("SELECT l.*, u.username as admin_name FROM lapangan l JOIN users u ON l.admin_id = u.id ORDER BY l.created_at DESC")->fetchAll();
$jadwal_tutup = $pdo->query("SELECT lt.*, l.nama_lapangan, u.username AS admin_name FROM lapangan_tutup lt JOIN lapangan l ON lt.lapangan_id = l.id JOIN users u ON l.admin_id = u.id ORDER BY lt.tanggal ASC, lt.jam_mulai ASC")->fetchAll();
?>
<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Kelola Semua Lapangan - Super Admin</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"><link rel="stylesheet" href="../assets/css/style.css">
<style>.admin-summary-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:16px;margin:20px 0}.admin-mini-card{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);border-radius:18px;padding:16px}.admin-mini-card strong{display:block;color:#00ffb3;font-size:26px}.status-select{padding:8px 12px;border-radius:12px;border:1px solid rgba(255,255,255,.14);background:rgba(255,255,255,.08);color:#fff}.field-photo{width:58px;height:58px;border-radius:14px;object-fit:cover;background:rgba(255,255,255,.1)}.data-table td{vertical-align:top}.action-cell{display:flex;gap:8px;flex-wrap:wrap}.field-name strong{color:#fff}.field-name small{display:block;color:#aeb8c7}</style>
</head><body><div class="top-header"><div class="promo-box">Kelola Semua Lapangan <span>SUPER ADMIN</span></div><div class="top-right"><div class="user-info"><i class="fa-regular fa-user"></i> <?= e($_SESSION['username']) ?> <a href="../logout.php" style="color:#ff003c;">Logout</a></div></div></div>
<?php renderNavbar('../'); ?>
<div class="dashboard-wrapper"><div class="sidebar"><h2>Super Admin Menu</h2><a href="dashboard.php"><i class="fa-solid fa-chart-line"></i> Dashboard</a><a href="admins.php"><i class="fa-solid fa-user-shield"></i> Kelola Admin</a><a href="users.php"><i class="fa-solid fa-users"></i> Kelola User</a><a href="lapangan.php" class="active"><i class="fa-solid fa-futbol"></i> Kelola Lapangan</a><a href="bookings.php"><i class="fa-solid fa-calendar-check"></i> Kelola Booking</a><a href="transactions.php"><i class="fa-solid fa-credit-card"></i> Kelola Transaksi</a><a href="profit.php"><i class="fa-solid fa-coins"></i> Keuntungan Sistem</a><a href="../marketplace.php"><i class="fa-solid fa-store"></i> Market Olahraga</a><a href="../logout.php"><i class="fa-solid fa-sign-out-alt"></i> Logout</a></div>
<div class="main-content"><h1>Kelola Semua Lapangan</h1><p>Tampilan dirapikan agar super admin mudah melihat pemilik, unit lapangan, status, dan jadwal tutup.</p><?php if(isset($_GET['success'])): ?><div class="alert-success"><?= e($_GET['success']) ?></div><?php endif; ?><?php if(isset($_GET['error'])): ?><div class="alert-error"><?= e($_GET['error']) ?></div><?php endif; ?>
<div class="admin-summary-grid"><div class="admin-mini-card"><small>Total Lapangan</small><strong><?= count($lapangan) ?></strong></div><div class="admin-mini-card"><small>Aktif</small><strong><?= count(array_filter($lapangan,fn($x)=>$x['status']==='aktif')) ?></strong></div><div class="admin-mini-card"><small>Nonaktif</small><strong><?= count(array_filter($lapangan,fn($x)=>$x['status']==='nonaktif')) ?></strong></div><div class="admin-mini-card"><small>Jadwal Tutup</small><strong><?= count($jadwal_tutup) ?></strong></div></div>
<div class="form-card"><h2>Semua Lapangan</h2><div class="table-responsive"><table class="data-table"><thead><tr><th>Lapangan</th><th>Admin</th><th>Jenis</th><th>Unit</th><th>Harga</th><th>Alamat</th><th>Status</th><th>Aksi</th></tr></thead><tbody><?php foreach($lapangan as $l): ?><tr><td><div style="display:flex;gap:12px;align-items:center"><?php if(!empty($l['foto'])): ?><img class="field-photo" src="../assets/uploads/<?= e($l['foto']) ?>"><?php else: ?><div class="field-photo" style="display:grid;place-items:center"><i class="fa-solid fa-futbol"></i></div><?php endif; ?><div class="field-name"><strong><?= e($l['nama_lapangan']) ?></strong><small>ID #<?= (int)$l['id'] ?></small></div></div></td><td><?= e($l['admin_name']) ?></td><td><?= e($l['jenis_olahraga']) ?></td><td><?= (int)$l['jumlah_lapangan'] ?> unit</td><td>Rp <?= number_format($l['harga_per_jam'],0,',','.') ?>/jam</td><td><?= e(mb_substr($l['alamat'] ?: '-',0,55)) ?><?= mb_strlen($l['alamat'] ?: '')>55?'...':'' ?></td><td><form method="POST"><input type="hidden" name="lapangan_id" value="<?= (int)$l['id'] ?>"><select name="status" class="status-select" onchange="this.form.submit()"><option value="aktif" <?= $l['status']==='aktif'?'selected':'' ?>>Aktif</option><option value="nonaktif" <?= $l['status']==='nonaktif'?'selected':'' ?>>Nonaktif</option></select><input type="hidden" name="update_status" value="1"></form></td><td class="action-cell"><a href="../detail-lapangan.php?id=<?= (int)$l['id'] ?>" class="btn-secondary small-btn">Detail</a><a href="?delete=<?= (int)$l['id'] ?>" class="btn-danger small-btn" onclick="return confirm('Yakin hapus lapangan ini? Semua booking dan transaksi terkait ikut terhapus.')">Hapus</a></td></tr><?php endforeach; ?><?php if(!$lapangan): ?><tr><td colspan="8" style="text-align:center">Belum ada lapangan</td></tr><?php endif; ?></tbody></table></div></div>
<div class="form-card"><h2>Semua Jadwal Tutup</h2><div class="table-responsive"><table class="data-table"><thead><tr><th>Lapangan</th><th>Admin</th><th>No.</th><th>Tanggal</th><th>Tipe</th><th>Jam</th><th>Alasan</th><th>Aksi</th></tr></thead><tbody><?php foreach($jadwal_tutup as $jt): ?><tr><td><?= e($jt['nama_lapangan']) ?></td><td><?= e($jt['admin_name']) ?></td><td>Lapangan <?= (int)$jt['nomor_lapangan'] ?></td><td><?= date('d/m/Y', strtotime($jt['tanggal'])) ?></td><td><span class="source-badge <?= ($jt['tipe_tutup'] ?? 'manual') === 'seharian' ? 'offline':'online' ?>"><?= e($jt['tipe_tutup'] ?? 'manual') ?></span></td><td><?= substr($jt['jam_mulai'],0,5) ?> - <?= substr($jt['jam_selesai'],0,5) ?></td><td><?= e($jt['alasan'] ?: '-') ?></td><td><a href="?delete_tutup=<?= (int)$jt['id'] ?>" class="btn-danger small-btn" onclick="return confirm('Hapus jadwal tutup ini?')">Hapus</a></td></tr><?php endforeach; ?><?php if(!$jadwal_tutup): ?><tr><td colspan="8" style="text-align:center">Belum ada jadwal tutup</td></tr><?php endif; ?></tbody></table></div></div>
</div></div></body></html>
