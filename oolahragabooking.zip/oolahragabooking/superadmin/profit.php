<?php
include '../config/database.php';
if (!isLoggedIn() || !isSuperAdmin()) {
    header('Location: ../login.php');
    exit();
}

$bookingFee = 0; $bookingGross = 0; $bookingCount = 0;
try {
    $stmt = $pdo->query("SELECT COUNT(*) AS total_count, COALESCE(SUM(t.amount),0) AS gross, COALESCE(SUM(b.platform_fee),0) AS fee
                         FROM transactions t
                         JOIN bookings b ON t.booking_id = b.id
                         WHERE t.status='success'");
    $r = $stmt->fetch();
    $bookingCount = (int)$r['total_count'];
    $bookingGross = (float)$r['gross'];
    $bookingFee = (float)$r['fee'];
} catch(Exception $e) {}

$productFee = 0; $productGross = 0; $productCount = 0;
if (tableExists($pdo, 'product_orders')) {
    $stmt = $pdo->query("SELECT COUNT(*) AS total_count, COALESCE(SUM(total_amount),0) AS gross, COALESCE(SUM(platform_fee),0) AS fee FROM product_orders WHERE status='success'");
    $r = $stmt->fetch();
    $productCount = (int)$r['total_count'];
    $productGross = (float)$r['gross'];
    $productFee = (float)$r['fee'];
}

$vipGross = 0; $vipCount = 0;
if (tableExists($pdo, 'vip_orders')) {
    $stmt = $pdo->query("SELECT COUNT(*) AS total_count, COALESCE(SUM(amount),0) AS gross FROM vip_orders WHERE status='success'");
    $r = $stmt->fetch();
    $vipCount = (int)$r['total_count'];
    $vipGross = (float)$r['gross'];
}

$totalProfit = $bookingFee + $productFee + $vipGross;

$recentBookings = $pdo->query("SELECT t.transaction_code, t.amount, t.status, t.created_at, b.platform_fee, b.owner_amount, l.nama_lapangan, u.username AS customer
                               FROM transactions t
                               JOIN bookings b ON t.booking_id=b.id
                               JOIN lapangan l ON b.lapangan_id=l.id
                               JOIN users u ON b.user_id=u.id
                               ORDER BY t.created_at DESC LIMIT 15")->fetchAll();
$recentProducts = [];
if (tableExists($pdo, 'product_orders')) {
    $recentProducts = $pdo->query("SELECT po.*, p.product_name, bu.username AS buyer_name, se.username AS seller_name
                                   FROM product_orders po
                                   JOIN products p ON po.product_id=p.id
                                   JOIN users bu ON po.buyer_id=bu.id
                                   JOIN users se ON po.seller_id=se.id
                                   ORDER BY po.created_at DESC LIMIT 15")->fetchAll();
}
?>
<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Keuntungan Super Admin</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"><link rel="stylesheet" href="../assets/css/style.css"></head><body>
<div class="top-header"><div class="promo-box">Keuntungan Sistem <span>SUPER ADMIN</span></div><div class="top-right"><div class="user-info"><i class="fa-regular fa-user"></i> <?= e($_SESSION['username']) ?> <a href="../logout.php" style="color:#ff003c;">Logout</a></div></div></div>
<?php renderNavbar('../'); ?>
<div class="dashboard-wrapper"><div class="sidebar"><h2>Super Admin Menu</h2><a href="dashboard.php"><i class="fa-solid fa-chart-line"></i> Dashboard</a><a href="admins.php"><i class="fa-solid fa-user-shield"></i> Kelola Admin</a><a href="users.php"><i class="fa-solid fa-users"></i> Kelola User</a><a href="lapangan.php"><i class="fa-solid fa-futbol"></i> Kelola Lapangan</a><a href="bookings.php"><i class="fa-solid fa-calendar-check"></i> Kelola Booking</a><a href="transactions.php"><i class="fa-solid fa-credit-card"></i> Kelola Transaksi</a><a href="profit.php" class="active"><i class="fa-solid fa-coins"></i> Keuntungan Sistem</a><a href="../marketplace.php"><i class="fa-solid fa-store"></i> Market Olahraga</a><a href="../logout.php"><i class="fa-solid fa-sign-out-alt"></i> Logout</a></div>
<div class="main-content"><h1>Keuntungan Super Admin</h1><p>Bagian ini menampilkan keuntungan sistem dari booking/sewa lapangan, penjualan barang olahraga, dan pembayaran VIP.</p>
<div class="super-profit-grid"><div class="profit-card"><small>Total Keuntungan Sistem</small><strong>Rp <?= number_format($totalProfit,0,',','.') ?></strong></div><div class="profit-card"><small>Fee Booking/Sewa Lapangan</small><strong>Rp <?= number_format($bookingFee,0,',','.') ?></strong><small><?= $bookingCount ?> transaksi sukses | Gross Rp <?= number_format($bookingGross,0,',','.') ?></small></div><div class="profit-card"><small>Fee Penjualan Barang</small><strong>Rp <?= number_format($productFee,0,',','.') ?></strong><small><?= $productCount ?> order sukses | Gross Rp <?= number_format($productGross,0,',','.') ?></small></div><div class="profit-card"><small>Pembayaran VIP</small><strong>Rp <?= number_format($vipGross,0,',','.') ?></strong><small><?= $vipCount ?> transaksi VIP sukses</small></div></div>
<div class="form-card"><h2>Transaksi Booking / Sewa Lapangan</h2><div class="table-responsive"><table class="data-table"><thead><tr><th>Kode</th><th>Customer</th><th>Lapangan</th><th>Total</th><th>Fee Sistem</th><th>Bagian Admin</th><th>Status</th></tr></thead><tbody><?php foreach($recentBookings as $b): ?><tr><td><?= e($b['transaction_code']) ?><br><small><?= date('d/m/Y H:i', strtotime($b['created_at'])) ?></small></td><td><?= e($b['customer']) ?></td><td><?= e($b['nama_lapangan']) ?></td><td>Rp <?= number_format((float)$b['amount'],0,',','.') ?></td><td>Rp <?= number_format((float)$b['platform_fee'],0,',','.') ?></td><td>Rp <?= number_format((float)$b['owner_amount'],0,',','.') ?></td><td><?= e($b['status']) ?></td></tr><?php endforeach; ?><?php if(!$recentBookings): ?><tr><td colspan="7" style="text-align:center">Belum ada data.</td></tr><?php endif; ?></tbody></table></div></div>
<div class="form-card"><h2>Transaksi Penjualan Barang Olahraga</h2><div class="table-responsive"><table class="data-table"><thead><tr><th>Kode</th><th>Barang</th><th>Pembeli</th><th>Penjual</th><th>Total</th><th>Fee Sistem</th><th>Bagian Penjual</th><th>Status</th></tr></thead><tbody><?php foreach($recentProducts as $p): ?><tr><td><?= e($p['transaction_code']) ?><br><small><?= date('d/m/Y H:i', strtotime($p['created_at'])) ?></small></td><td><?= e($p['product_name']) ?><br><small>Qty <?= (int)$p['quantity'] ?></small></td><td><?= e($p['buyer_name']) ?></td><td><?= e($p['seller_name']) ?></td><td>Rp <?= number_format((float)$p['total_amount'],0,',','.') ?></td><td>Rp <?= number_format((float)$p['platform_fee'],0,',','.') ?></td><td>Rp <?= number_format((float)$p['seller_amount'],0,',','.') ?></td><td><?= e(productOrderStatusLabel($p['status'])) ?></td></tr><?php endforeach; ?><?php if(!$recentProducts): ?><tr><td colspan="8" style="text-align:center">Belum ada transaksi barang.</td></tr><?php endif; ?></tbody></table></div></div>
</div></div></body></html>
