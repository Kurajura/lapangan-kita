<?php 
include '../config/database.php';
if (!isLoggedIn() || !isSuperAdmin()) {
    header("Location: ../login.php");
    exit();
}
function redirectTrans($msg, $type='success') { header('Location: transactions.php?' . $type . '=' . urlencode($msg)); exit(); }

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $transaction_id = (int)($_POST['transaction_id'] ?? 0);
    $status = $_POST['status'] ?? '';
    if (!in_array($status, ['pending','success','failed','cancelled'], true)) redirectTrans('Status tidak valid','error');
    if (!syncBookingFromTransactionStatus($pdo, $transaction_id, $status)) redirectTrans('Transaksi tidak ditemukan','error');
    redirectTrans('Status transaksi berhasil diupdate. Booking ikut disinkronkan.');
}

if (isset($_GET['delete'])) {
    $stmt = $pdo->prepare("DELETE FROM transactions WHERE id = ?");
    $stmt->execute([(int)$_GET['delete']]);
    redirectTrans('Transaksi berhasil dihapus');
}

$stmt = $pdo->query("SELECT t.*, b.booking_code, b.tanggal, b.jam_mulai, b.jam_selesai, b.nomor_lapangan, b.booking_source, b.nama_pelanggan, b.status AS booking_status, b.payment_status, l.nama_lapangan, u.username as user_name, u2.username AS admin_name, COALESCE(NULLIF(b.nama_pelanggan, ''), u.username) AS nama_customer 
                     FROM transactions t 
                     JOIN bookings b ON t.booking_id = b.id 
                     JOIN lapangan l ON b.lapangan_id = l.id 
                     JOIN users u ON b.user_id = u.id 
                     JOIN users u2 ON l.admin_id = u2.id
                     ORDER BY t.created_at DESC");
$transactions = $stmt->fetchAll();
$total_success = array_sum(array_map(fn($t)=>(float)$t['amount'], array_filter($transactions, fn($t)=>$t['status']==='success')));
?>
<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Kelola Semua Transaksi - Super Admin</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"><link rel="stylesheet" href="../assets/css/style.css">
<style>.admin-summary-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:16px;margin:20px 0}.admin-mini-card{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);border-radius:18px;padding:16px}.admin-mini-card strong{display:block;color:#00ffb3;font-size:26px}.status-select{padding:8px 12px;border-radius:12px;border:1px solid rgba(255,255,255,.14);background:rgba(255,255,255,.08);color:#fff}.status-cancelled{background:#f44336;color:#fff}.data-table td{vertical-align:top}.action-cell{display:flex;gap:8px;flex-wrap:wrap}.manage-title{display:flex;justify-content:space-between;gap:16px;align-items:center;flex-wrap:wrap}</style>
</head><body>
<div class="top-header"><div class="promo-box">Kelola Semua Transaksi <span>SUPER ADMIN</span></div><div class="top-right"><div class="user-info"><i class="fa-regular fa-user"></i> <?= e($_SESSION['username']) ?> <a href="../logout.php" style="color:#ff003c;">Logout</a></div></div></div>
<?php renderNavbar('../'); ?>
<div class="dashboard-wrapper"><div class="sidebar"><h2>Super Admin Menu</h2><a href="dashboard.php"><i class="fa-solid fa-chart-line"></i> Dashboard</a><a href="admins.php"><i class="fa-solid fa-user-shield"></i> Kelola Admin</a><a href="users.php"><i class="fa-solid fa-users"></i> Kelola User</a><a href="lapangan.php"><i class="fa-solid fa-futbol"></i> Kelola Lapangan</a><a href="bookings.php"><i class="fa-solid fa-calendar-check"></i> Kelola Booking</a><a href="transactions.php" class="active"><i class="fa-solid fa-credit-card"></i> Kelola Transaksi</a><a href="profit.php"><i class="fa-solid fa-coins"></i> Keuntungan Sistem</a><a href="../marketplace.php"><i class="fa-solid fa-store"></i> Market Olahraga</a><a href="../logout.php"><i class="fa-solid fa-sign-out-alt"></i> Logout</a></div>
<div class="main-content"><div class="manage-title"><div><h1>Kelola Semua Transaksi</h1><p>Super Admin dapat melihat, mengubah, dan membatalkan semua transaksi dari semua lapangan.</p></div></div>
<?php if(isset($_GET['success'])): ?><div class="alert-success"><?= e($_GET['success']) ?></div><?php endif; ?><?php if(isset($_GET['error'])): ?><div class="alert-error"><?= e($_GET['error']) ?></div><?php endif; ?>
<div class="admin-summary-grid"><div class="admin-mini-card"><small>Total Data</small><strong><?= count($transactions) ?></strong></div><div class="admin-mini-card"><small>Total Sukses</small><strong>Rp <?= number_format($total_success,0,',','.') ?></strong></div><div class="admin-mini-card"><small>Pending</small><strong><?= count(array_filter($transactions, fn($x)=>$x['status']==='pending')) ?></strong></div><div class="admin-mini-card"><small>Cancel</small><strong><?= count(array_filter($transactions, fn($x)=>$x['status']==='cancelled')) ?></strong></div></div>
<div class="form-card"><h2>Daftar Transaksi</h2><div class="table-responsive"><table class="data-table"><thead><tr><th>Kode</th><th>Customer</th><th>Admin</th><th>Lapangan</th><th>Jadwal</th><th>Jumlah</th><th>Metode</th><th>Status</th><th>Booking</th><th>Aksi</th></tr></thead><tbody>
<?php foreach($transactions as $trx): ?><tr><td><strong><?= e($trx['transaction_code']) ?></strong><br><small><?= date('d/m/Y H:i', strtotime($trx['created_at'])) ?></small></td><td><?= e($trx['nama_customer']) ?></td><td><?= e($trx['admin_name']) ?></td><td><?= e($trx['nama_lapangan']) ?><br><small>Lapangan <?= (int)$trx['nomor_lapangan'] ?> | <?= e($trx['booking_code']) ?></small></td><td><?= date('d/m/Y', strtotime($trx['tanggal'])) ?><br><small><?= substr($trx['jam_mulai'],0,5) ?> - <?= substr($trx['jam_selesai'],0,5) ?></small></td><td>Rp <?= number_format($trx['amount'],0,',','.') ?></td><td><?= e(strtoupper($trx['payment_method'])) ?><br><small><?= e($trx['payment_channel']) ?></small></td><td><form method="POST"><input type="hidden" name="transaction_id" value="<?= (int)$trx['id'] ?>"><select name="status" class="status-select" onchange="if(confirm('Update transaksi ini?')) this.form.submit(); else this.value='<?= e($trx['status']) ?>';"><option value="pending" <?= $trx['status']==='pending'?'selected':'' ?>>Pending</option><option value="success" <?= $trx['status']==='success'?'selected':'' ?>>Success</option><option value="failed" <?= $trx['status']==='failed'?'selected':'' ?>>Failed</option><option value="cancelled" <?= $trx['status']==='cancelled'?'selected':'' ?>>Cancelled</option></select><input type="hidden" name="update_status" value="1"></form></td><td><span class="status-badge status-<?= e($trx['booking_status']) ?>"><?= e($trx['booking_status']) ?></span><br><small><?= e($trx['payment_status']) ?></small></td><td class="action-cell"><a href="../cetak-struk.php?transaction_id=<?= (int)$trx['id'] ?>" class="btn-secondary small-btn">Cetak</a><a href="?delete=<?= (int)$trx['id'] ?>" class="btn-danger small-btn" onclick="return confirm('Yakin hapus transaksi ini?')">Hapus</a></td></tr><?php endforeach; ?>
<?php if(!$transactions): ?><tr><td colspan="10" style="text-align:center">Belum ada transaksi</td></tr><?php endif; ?></tbody></table></div></div>
</div></div></body></html>
