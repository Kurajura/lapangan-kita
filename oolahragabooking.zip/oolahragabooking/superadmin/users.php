<?php 
include '../config/database.php';
if (!isLoggedIn() || !isSuperAdmin()) {
    header("Location: ../login.php");
    exit();
}

// Hapus user
if (isset($_GET['delete'])) {
    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ? AND role = 'user'");
    $stmt->execute([$_GET['delete']]);
    header("Location: users.php");
    exit();
}

$stmt = $pdo->query("SELECT * FROM users WHERE role = 'user' ORDER BY created_at DESC");
$users = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola User - Super Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="top-header">
    <div class="promo-box"> Kelola User <span>SUPER ADMIN</span></div>
    <div class="top-right">
        <div class="user-info">
            <i class="fa-regular fa-user"></i> <?= $_SESSION['username'] ?>
            <a href="../logout.php" style="color:#ff003c;">Logout</a>
        </div>
    </div>
</div>
<?php renderNavbar('../'); ?>

<div class="dashboard-wrapper">
    <div class="sidebar">
        <h2>Super Admin Menu</h2>
        <a href="dashboard.php"><i class="fa-solid fa-chart-line"></i> Dashboard</a>
        <a href="admins.php"><i class="fa-solid fa-user-shield"></i> Kelola Admin</a>
        <a href="users.php" class="active"><i class="fa-solid fa-users"></i> Kelola User</a>
        <a href="lapangan.php"><i class="fa-solid fa-futbol"></i> Semua Lapangan</a>
        <a href="bookings.php"><i class="fa-solid fa-calendar-check"></i> Semua Booking</a>
        <a href="transactions.php"><i class="fa-solid fa-credit-card"></i> Semua Transaksi</a>
        <a href="../logout.php"><i class="fa-solid fa-sign-out-alt"></i> Logout</a>
    </div>
    
    <div class="main-content">
        <h1>Kelola User Biasa</h1>
        
        <div class="form-card">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Nama</th>
                        <th>Telepon</th>
                        <th>Bergabung</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($users as $user): ?>
                    <tr>
                        <td><?= htmlspecialchars($user['username']) ?></td>
                        <td><?= htmlspecialchars($user['email']) ?></td>
                        <td><?= htmlspecialchars($user['full_name'] ?: '-') ?></td>
                        <td><?= htmlspecialchars($user['phone'] ?: '-') ?></td>
                        <td><?= date('d/m/Y', strtotime($user['created_at'])) ?></td>
                        <td>
                            <a href="?delete=<?= $user['id'] ?>" class="btn-danger" onclick="return confirm('Yakin hapus user ini?')">Hapus</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</body>
</html>