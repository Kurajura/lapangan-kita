<?php
include 'config/database.php';
if (!isLoggedIn() || getUserRole() !== 'user') {
    header('Location: login.php?error=Silakan login sebagai user terlebih dahulu');
    exit();
}
function backTeam($booking_id, $message, $type='error') {
    header('Location: team-tanding.php?booking_id=' . (int)$booking_id . '&' . $type . '=' . urlencode($message));
    exit();
}

$booking_id = (int)($_GET['booking_id'] ?? $_POST['booking_id'] ?? 0);
$stmt = $pdo->prepare("SELECT b.*, l.nama_lapangan, l.jenis_olahraga, l.admin_id
                       FROM bookings b JOIN lapangan l ON b.lapangan_id = l.id
                       WHERE b.id = ? AND b.user_id = ? AND (b.booking_source IS NULL OR b.booking_source = 'online')");
$stmt->execute([$booking_id, getUserId()]);
$booking = $stmt->fetch();
if (!$booking) {
    header('Location: riwayat.php?error=' . urlencode('Booking tidak ditemukan'));
    exit();
}
$paidOk = in_array($booking['status'], ['paid','confirmed'], true) && $booking['payment_status'] === 'paid';
if (!$paidOk) {
    header('Location: riwayat.php?error=' . urlencode('Mode tanding hanya bisa diaktifkan setelah pembayaran sukses'));
    exit();
}
if (!userHasActiveVip($pdo)) {
    header('Location: vip.php?error=' . urlencode('Mode tanding team khusus member VIP'));
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'create_team') {
        $team_name = trim($_POST['team_name'] ?? '');
        $team_players_raw = trim($_POST['team_players'] ?? '');
        if ($team_name === '') backTeam($booking_id, 'Nama team wajib diisi');
        if (mb_strlen($team_name) < 3) backTeam($booking_id, 'Nama team minimal 3 karakter');
        if (!empty($booking['requester_team_id'])) backTeam($booking_id, 'Team untuk booking ini sudah dibuat');
        $parsed = parsePlayerList($pdo, $team_players_raw, [getUserId()]);
        if ($parsed['missing']) backTeam($booking_id, 'Pemain tidak ditemukan: ' . implode(', ', $parsed['missing']));
        try {
            $pdo->beginTransaction();
            $team_code = getNextTeamCode($pdo);
            $stmt = $pdo->prepare("INSERT INTO teams (team_code, team_name, captain_id, jenis_olahraga, status, created_by_booking_id) VALUES (?, ?, ?, ?, ?, ?)");
            $initialStatus = count($parsed['players']) > 0 ? 'pending' : 'active';
            $stmt->execute([$team_code, $team_name, getUserId(), $booking['jenis_olahraga'], $initialStatus, $booking_id]);
            $team_id = (int)$pdo->lastInsertId();
            $ins = $pdo->prepare("INSERT INTO team_members (team_id, user_id, status, is_captain, invited_by, responded_at) VALUES (?, ?, ?, ?, ?, ?)");
            $ins->execute([$team_id, getUserId(), 'accepted', 1, getUserId(), date('Y-m-d H:i:s')]);
            foreach ($parsed['players'] as $p) {
                $ins->execute([$team_id, (int)$p['id'], 'pending', 0, getUserId(), null]);
                createNotification($pdo, (int)$p['id'], 'Undangan masuk team', $_SESSION['username'] . ' mengajak kamu masuk team ' . $team_name . ' untuk mode tanding.', 'match-invitations.php');
            }
            $status = $initialStatus === 'active' ? 'team_ready' : 'team_setup';
            $pdo->prepare("UPDATE bookings SET mode_main='kompetitif', match_enabled=1, match_type='team', match_status=?, requester_team_id=?, match_requested_at=NOW(), match_rejected_reason=NULL WHERE id=? AND user_id=?")
                ->execute([$status, $team_id, $booking_id, getUserId()]);
            $pdo->commit();
            backTeam($booking_id, $initialStatus === 'active' ? 'Team berhasil dibuat dan langsung aktif. ID Team: ' . $team_code : 'Team berhasil dibuat. Menunggu semua anggota menyetujui undangan.', 'success');
        } catch (Exception $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            backTeam($booking_id, 'Gagal membuat team: ' . $e->getMessage());
        }
    }

    if ($action === 'challenge_team') {
        $opponent_keyword = trim($_POST['opponent_team'] ?? '');
        if ($opponent_keyword === '') backTeam($booking_id, 'Masukkan ID team atau nama team lawan');
        if (empty($booking['requester_team_id'])) backTeam($booking_id, 'Buat team kamu dulu');
        $stmt = $pdo->prepare("SELECT * FROM teams WHERE id = ? AND captain_id = ?");
        $stmt->execute([(int)$booking['requester_team_id'], getUserId()]);
        $myTeam = $stmt->fetch();
        if (!$myTeam || $myTeam['status'] !== 'active') backTeam($booking_id, 'Team kamu belum aktif. Semua anggota harus setuju dulu.');
        $opponent = findTeamByKeyword($pdo, $opponent_keyword, [(int)$myTeam['id']]);
        if (!$opponent) backTeam($booking_id, 'Team lawan tidak ditemukan atau belum aktif');
        if ((int)$opponent['captain_id'] === getUserId()) backTeam($booking_id, 'Tidak bisa menantang team sendiri');
        try {
            $pdo->beginTransaction();
            $pdo->prepare("UPDATE team_match_requests SET status='cancelled' WHERE booking_id=? AND status='pending'")->execute([$booking_id]);
            $stmt = $pdo->prepare("INSERT INTO team_match_requests (booking_id, requester_user_id, requester_team_id, opponent_team_id, status, message) VALUES (?, ?, ?, ?, 'pending', ?)");
            $stmt->execute([$booking_id, getUserId(), (int)$myTeam['id'], (int)$opponent['id'], trim($_POST['message'] ?? '')]);
            $reqId = (int)$pdo->lastInsertId();
            $pdo->prepare("UPDATE bookings SET match_status='pending_opponent_team', opponent_team_id=?, team_match_request_id=?, match_opponent_name=?, match_rejected_reason=NULL WHERE id=?")
                ->execute([(int)$opponent['id'], $reqId, $opponent['team_name'], $booking_id]);
            createNotification($pdo, (int)$opponent['captain_id'], 'Tantangan team masuk', 'Team ' . $myTeam['team_name'] . ' menantang team ' . $opponent['team_name'] . '. Terima atau tolak di menu undangan.', 'match-invitations.php');
            $pdo->commit();
            backTeam($booking_id, 'Tantangan dikirim ke captain team lawan. Menunggu persetujuan.', 'success');
        } catch (Exception $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            backTeam($booking_id, 'Gagal mengirim tantangan team: ' . $e->getMessage());
        }
    }
}

$stmt = $pdo->prepare("SELECT * FROM teams WHERE id = ?");
$stmt->execute([(int)($booking['requester_team_id'] ?? 0)]);
$myTeam = $stmt->fetch();
$myMembers = $myTeam ? getTeamMembers($pdo, $myTeam['id'], false) : [];
$opponentTeam = null;
if (!empty($booking['opponent_team_id'])) {
    $stmt = $pdo->prepare("SELECT t.*, COALESCE(NULLIF(u.display_name,''), NULLIF(u.full_name,''), u.username) AS captain_name FROM teams t JOIN users u ON t.captain_id=u.id WHERE t.id=?");
    $stmt->execute([(int)$booking['opponent_team_id']]);
    $opponentTeam = $stmt->fetch();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Tanding Team - LapanganKita</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"><link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="top-header"><div class="promo-box">Mode Tanding <span>TEAM</span></div><div class="top-right"><div class="user-info"><i class="fa-regular fa-user"></i> <?= e($_SESSION['username']) ?> <a href="logout.php" style="color:#ff003c;">Logout</a></div></div></div>
<?php renderNavbar(''); ?>
<div class="public-page-wrap team-match-wrap">
    <div class="form-card">
        <span class="match-badge completed">Team / Ganda / Grup</span>
        <h2>Alur Tanding Team</h2>
        <p class="helper-text">1) Buat team dan undang anggota. 2) Semua anggota setuju. 3) Team mendapat ID. 4) Masukkan ID/nama team lawan. 5) Captain lawan setuju. 6) Admin input skor Team 1 dan Team 2.</p>
        <p><strong>Booking:</strong> <?= e($booking['booking_code']) ?> | <?= e($booking['nama_lapangan']) ?> | <?= date('d/m/Y', strtotime($booking['tanggal'])) ?> <?= substr($booking['jam_mulai'],0,5) ?>-<?= substr($booking['jam_selesai'],0,5) ?></p>
        <?php if(isset($_GET['success'])): ?><div class="alert-success"><?= e($_GET['success']) ?></div><?php endif; ?>
        <?php if(isset($_GET['error'])): ?><div class="alert-error"><?= e($_GET['error']) ?></div><?php endif; ?>
    </div>

    <?php if(!$myTeam): ?>
    <div class="form-card team-builder-card">
        <h2>Buat Team Kamu</h2>
        <form method="POST" class="team-form-grid">
            <input type="hidden" name="booking_id" value="<?= (int)$booking_id ?>">
            <input type="hidden" name="action" value="create_team">
            <label>Nama Team</label>
            <input type="text" name="team_name" placeholder="Contoh: Garuda Smash" required>
            <label>Anggota Team</label>
            <textarea name="team_players" id="team_players" rows="3" placeholder="Masukkan ID pemain / username, pisahkan koma. Captain otomatis kamu sendiri."></textarea>
            <div class="player-search-box">
                <input type="text" class="player-smart-search" placeholder="Cari anggota by nama / username / ID">
                <div class="player-search-result"></div>
            </div>
            <button class="btn-primary">Buat Team & Kirim Undangan</button>
            <a class="btn-secondary" href="aktifkan-tanding.php?booking_id=<?= (int)$booking_id ?>">Pilih Mode Solo</a>
        </form>
    </div>
    <?php else: ?>
    <div class="form-card team-status-card">
        <h2>Team Kamu</h2>
        <div class="team-id-box"><span>ID Team</span><strong><?= e($myTeam['team_code']) ?></strong><small><?= e($myTeam['team_name']) ?></small></div>
        <p>Status: <span class="match-badge <?= $myTeam['status']==='active'?'completed':($myTeam['status']==='rejected'?'rejected':'waiting') ?>"><?= e($myTeam['status']) ?></span></p>
        <div class="team-member-grid">
            <?php foreach($myMembers as $m): ?>
                <div class="team-member-chip"><strong><?= e($m['player_name']) ?></strong><small>ID <?= e($m['player_code']) ?> | <?= $m['is_captain'] ? 'Captain' : 'Anggota' ?></small><span class="match-badge <?= $m['status']==='accepted'?'completed':($m['status']==='rejected'?'rejected':'waiting') ?>"><?= e($m['status']) ?></span></div>
            <?php endforeach; ?>
        </div>
        <?php if($myTeam['status'] === 'pending'): ?><p class="helper-text">Menunggu semua anggota menerima undangan di halaman Undangan Tanding.</p><?php endif; ?>
        <?php if($myTeam['status'] === 'rejected'): ?><div class="alert-error">Ada anggota yang menolak. Silakan gunakan booking lain atau hubungi admin untuk reset permintaan.</div><?php endif; ?>
    </div>

    <?php if($myTeam['status'] === 'active' && !in_array($booking['match_status'], ['pending_opponent_team','waiting_score','completed'], true)): ?>
    <div class="form-card team-builder-card">
        <h2>Tantang Team Lawan</h2>
        <form method="POST" class="team-form-grid">
            <input type="hidden" name="booking_id" value="<?= (int)$booking_id ?>">
            <input type="hidden" name="action" value="challenge_team">
            <label>ID Team / Nama Team Lawan</label>
            <input type="text" name="opponent_team" placeholder="Contoh: TM801001 atau Garuda Smash" required>
            <textarea name="message" rows="2" placeholder="Pesan opsional untuk captain lawan"></textarea>
            <button class="btn-primary">Kirim Tantangan Team</button>
        </form>
    </div>
    <?php elseif($booking['match_status'] === 'pending_opponent_team'): ?>
        <div class="form-card"><h2>Menunggu Team Lawan</h2><p>Menunggu captain team <strong><?= e($opponentTeam['team_name'] ?? $booking['match_opponent_name']) ?></strong> menerima tantangan.</p></div>
    <?php elseif($booking['match_status'] === 'waiting_score'): ?>
        <div class="form-card"><h2>Pertandingan Siap</h2><div class="alert-success">Team lawan sudah setuju. Setelah pertandingan selesai, admin lapangan akan input skor Team 1 dan Team 2.</div></div>
    <?php elseif($booking['match_status'] === 'rejected'): ?>
        <div class="form-card"><h2>Tantangan Ditolak</h2><div class="alert-error"><?= e($booking['match_rejected_reason'] ?: 'Team lawan menolak tantangan.') ?></div><p class="helper-text">Kamu bisa mengirim tantangan ke team lain dari form di atas setelah sistem reset oleh pengajuan baru.</p></div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<script>
const searchInput = document.querySelector('.player-smart-search');
if (searchInput) {
    const resultBox = document.querySelector('.player-search-result');
    const targetBox = document.getElementById('team_players');
    let timer = null;
    searchInput.addEventListener('input', () => {
        clearTimeout(timer);
        const q = searchInput.value.trim();
        if (q.length < 2) { resultBox.innerHTML = ''; return; }
        timer = setTimeout(() => {
            fetch('search-players.php?q=' + encodeURIComponent(q)).then(r=>r.json()).then(rows=>{
                resultBox.innerHTML = rows.map(row => `<button type="button" data-code="${row.player_code}">${row.label}</button>`).join('') || '<small>Tidak ada pemain ditemukan</small>';
            });
        }, 250);
    });
    resultBox.addEventListener('click', e => {
        const btn = e.target.closest('button[data-code]');
        if (!btn) return;
        targetBox.value = targetBox.value.trim() ? targetBox.value.trim() + ', ' + btn.dataset.code : btn.dataset.code;
        searchInput.value = '';
        resultBox.innerHTML = '';
    });
}
</script>
</body></html>
