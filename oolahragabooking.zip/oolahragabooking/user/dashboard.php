<?php 
include '../config/database.php';
if (!isLoggedIn() || isAdmin() || isSuperAdmin()) {
    header("Location: ../login.php");
    exit();
}

// Statistik user
$stmt = $pdo->prepare("SELECT COUNT(*) as total_booking FROM bookings WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$total_booking = $stmt->fetch()['total_booking'];

$stmt = $pdo->prepare("SELECT COUNT(*) as total_paid FROM bookings WHERE user_id = ? AND status = 'confirmed'");
$stmt->execute([$_SESSION['user_id']]);
$total_paid = $stmt->fetch()['total_paid'];

$stmt = $pdo->prepare("SELECT SUM(total_harga) as total_spent FROM bookings WHERE user_id = ? AND status = 'confirmed'");
$stmt->execute([$_SESSION['user_id']]);
$total_spent = $stmt->fetch()['total_spent'];

$stmt = $pdo->prepare("SELECT b.*, l.nama_lapangan 
                       FROM bookings b 
                       JOIN lapangan l ON b.lapangan_id = l.id 
                       WHERE b.user_id = ? 
                       ORDER BY b.created_at DESC LIMIT 5");
$stmt->execute([$_SESSION['user_id']]);
$recent_bookings = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT COALESCE(NULLIF(display_name, ''), NULLIF(full_name, ''), username) AS display_name FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$display_name = $stmt->fetch()['display_name'] ?? $_SESSION['username'];
$pending_invites = pendingInvitationCount($pdo, $_SESSION['user_id']);
$unread_notifs = unreadNotificationCount($pdo, $_SESSION['user_id']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard - LapanganKita</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Poppins', sans-serif; background: #07111f; color: white; overflow-x: hidden; }
        body::before { content: ''; position: fixed; width: 500px; height: 500px; background: radial-gradient(circle, #00ffb3 0%, transparent 70%); top: -200px; left: -200px; opacity: .18; z-index: -1; animation: moveGlow 8s infinite alternate; }
        body::after { content: ''; position: fixed; width: 400px; height: 400px; background: radial-gradient(circle, #00c3ff 0%, transparent 70%); bottom: -150px; right: -100px; opacity: .15; z-index: -1; animation: moveGlow2 9s infinite alternate; }
        @keyframes moveGlow { from { transform: translateY(0px) translateX(0px); } to { transform: translateY(100px) translateX(100px); } }
        @keyframes moveGlow2 { from { transform: translateY(0px) translateX(0px); } to { transform: translateY(-80px) translateX(-80px); } }
        .top-header { width: 100%; height: 72px; position: fixed; top: 0; left: 0; z-index: 3000; display: flex; justify-content: space-between; align-items: center; padding: 0 7%; background: linear-gradient(90deg, rgba(4,8,24,.96), rgba(8,15,38,.95)); border-bottom: 1px solid rgba(255,255,255,.08); backdrop-filter: blur(18px); }
        .promo-box { background: linear-gradient(90deg, rgba(0,102,255,.35), rgba(0,255,179,.18)); border: 1px solid rgba(255,255,255,.12); padding: 12px 22px; border-radius: 50px; font-size: 14px; font-weight: 700; font-family: 'Teko', sans-serif; }
        .promo-box span { color: #ffe600; }
        .top-right { display: flex; align-items: center; gap: 18px; }
        .user-info { background: linear-gradient(135deg, #00ffb322, #00c3ff22); padding: 8px 20px; border-radius: 40px; display: flex; align-items: center; gap: 15px; }
        .user-info a { color: #ff003c; text-decoration: none; }
        nav { width: 100%; height: 85px; position: fixed; top: 72px; left: 0; z-index: 2500; background: #f5f5f5; display: flex; justify-content: space-between; align-items: center; padding: 0 7%; border-bottom: 5px solid #00ffb3; }
        .logo { display: flex; align-items: center; gap: 14px; }
        .logo-icon { width: 62px; height: 62px; border-radius: 16px; background: linear-gradient(135deg, #00ffb3, #00c3ff); display: flex; justify-content: center; align-items: center; color: #07111f; font-size: 28px; }
        .logo h1 { color: #07111f; font-family: 'Teko', sans-serif; font-size: 38px; }
        nav ul { display: flex; align-items: center; gap: 42px; list-style: none; }
        nav ul li a { text-decoration: none; color: #07111f; font-family: 'Teko', sans-serif; font-size: 24px; font-weight: 600; transition: .4s; }
        nav ul li a:hover { color: #00b894; }
        .search-icon { color: #07111f; font-size: 28px; cursor: pointer; }
        .dashboard-wrapper { display: flex; padding-top: 157px; min-height: 100vh; }
        .sidebar { width: 280px; background: rgba(0,0,0,.8); backdrop-filter: blur(10px); padding: 30px; position: fixed; height: calc(100% - 157px); overflow-y: auto; }
        .sidebar h2 { font-family: 'Anton', sans-serif; color: #00ffb3; margin-bottom: 30px; font-size: 24px; }
        .sidebar a { display: block; color: white; text-decoration: none; padding: 12px; margin: 8px 0; border-radius: 12px; transition: .3s; font-family: 'Teko', sans-serif; font-size: 20px; }
        .sidebar a:hover, .sidebar a.active { background: rgba(0,255,179,.2); color: #00ffb3; }
        .main-content { margin-left: 280px; padding: 30px; width: 100%; }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 40px; }
        .stat-card { background: rgba(255,255,255,.1); padding: 25px; border-radius: 20px; text-align: center; border: 1px solid rgba(255,255,255,.1); }
        .stat-card i { font-size: 40px; color: #00ffb3; }
        .stat-card h2 { font-size: 32px; margin: 10px 0; }
        .invite-alert-card { background: linear-gradient(135deg, rgba(255,214,10,.16), rgba(0,255,179,.12)); border: 1px solid rgba(255,214,10,.35); padding: 18px 20px; border-radius: 20px; margin: 18px 0 24px; display:flex; align-items:center; justify-content:space-between; gap:16px; }
        .invite-alert-card strong { color:#ffe600; }
        .sidebar-badge { float:right; background:#ff003c; color:#fff; border-radius:999px; padding:2px 8px; font-size:12px; font-family:Poppins,sans-serif; }
        .form-card { background: rgba(255,255,255,.08); border-radius: 24px; padding: 30px; margin-bottom: 40px; border: 1px solid rgba(255,255,255,.1); }
        .form-card h2 { font-family: 'Anton', sans-serif; margin-bottom: 20px; color: #00ffb3; }
        .data-table { width: 100%; border-collapse: collapse; background: rgba(255,255,255,.05); border-radius: 16px; overflow: hidden; }
        .data-table th, .data-table td { padding: 12px 15px; text-align: left; border-bottom: 1px solid rgba(255,255,255,.1); }
        .data-table th { background: rgba(0,255,179,.15); font-family: 'Teko', sans-serif; font-size: 18px; }
        .status-badge { display: inline-block; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: bold; }
        .status-pending { background: #ff9800; color: #000; }
        .status-paid { background: #2196f3; color: #fff; }
        .status-confirmed { background: #4caf50; color: #fff; }
        .status-cancelled { background: #f44336; color: #fff; }
        @media(max-width: 900px) { .sidebar { width: 100%; position: relative; height: auto; } .main-content { margin-left: 0; } .dashboard-wrapper { flex-direction: column; } nav ul { display: none; } }
    </style>
</head>
<body>
<div class="top-header">
    <div class="promo-box"> User Dashboard <span>PREMIUM</span></div>
    <div class="top-right">
        <div class="user-info">
            <i class="fa-regular fa-user"></i> <?= $_SESSION['username'] ?>
            <a href="../logout.php" style="color:#ff003c;">Logout</a>
        </div>
    </div>
</div>
<?php renderNavbar('../'); ?>

<div class="dashboard-wrapper">
    <div class="sidebar">
        <h2>Menu User</h2>
        <a href="dashboard.php" class="active"><i class="fa-solid fa-chart-line"></i> Dashboard</a>
        <a href="../booking.php"><i class="fa-solid fa-calendar-plus"></i> Booking Baru</a>
        <a href="../riwayat.php"><i class="fa-solid fa-history"></i> Riwayat Booking</a>
        <a href="../profile.php?id=<?= getUserId() ?>"><i class="fa-solid fa-user"></i> Profil Publik</a>
        <a href="../edit-profile.php"><i class="fa-solid fa-pen"></i> Edit Profil</a>
        <a href="../match-invitations.php"><i class="fa-solid fa-handshake"></i> Undangan Tanding <?php if($pending_invites>0): ?><span class="sidebar-badge"><?= $pending_invites ?></span><?php endif; ?></a>
        <a href="../notifications.php"><i class="fa-solid fa-bell"></i> Notifikasi <?php if($unread_notifs>0): ?><span class="sidebar-badge"><?= $unread_notifs ?></span><?php endif; ?></a>
        <a href="../chat.php"><i class="fa-solid fa-comments"></i> Chat Pemain</a>
        <a href="../logout.php"><i class="fa-solid fa-sign-out-alt"></i> Logout</a>
    </div>
    
    <div class="main-content">
        <h1>Selamat Datang, <?= htmlspecialchars($display_name) ?>!</h1>
        <p>Dashboard user LapanganKita</p>
        <p><a href="../profile.php?id=<?= getUserId() ?>" class="btn-secondary small-btn">Lihat Profil Publik</a> <a href="../edit-profile.php" class="btn-primary small-btn">Edit Profil</a> <a href="../match-invitations.php" class="btn-secondary small-btn">Undangan Tanding</a></p>
        
        <?php if($pending_invites > 0): ?>
        <div class="invite-alert-card">
            <div><i class="fa-solid fa-handshake"></i> Kamu punya <strong><?= $pending_invites ?></strong> undangan tanding/team yang menunggu persetujuan.</div>
            <a href="../match-invitations.php" class="btn-primary small-btn">Terima / Tolak Sekarang</a>
        </div>
        <?php endif; ?>
        
        <div class="stats-grid">
            <div class="stat-card">
                <i class="fa-solid fa-calendar-check"></i>
                <h2><?= $total_booking ?></h2>
                <p>Total Booking</p>
            </div>
            <div class="stat-card">
                <i class="fa-solid fa-check-circle"></i>
                <h2><?= $total_paid ?></h2>
                <p>Booking Selesai</p>
            </div>
            <div class="stat-card">
                <i class="fa-solid fa-money-bill-wave"></i>
                <h2>Rp <?= number_format($total_spent ?: 0, 0, ',', '.') ?></h2>
                <p>Total Belanja</p>
            </div>
            <div class="stat-card">
                <i class="fa-solid fa-handshake"></i>
                <h2><?= $pending_invites ?></h2>
                <p>Undangan Tanding</p>
                <p style="margin-top:12px;"><a href="../match-invitations.php" class="btn-primary small-btn">Buka Undangan</a></p>
            </div>
        </div>
        
        <div class="form-card">
            <h2>Booking Terbaru</h2>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Kode</th>
                        <th>Lapangan</th>
                        <th>No.</th>
                        <th>Tanggal</th>
                        <th>Jam</th>
                        <th>Total</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($recent_bookings as $booking): ?>
                    <tr>
                        <td><?= $booking['booking_code'] ?></td>
                        <td><?= htmlspecialchars($booking['nama_lapangan']) ?></td>
                        <td>Lapangan <?= (int) $booking['nomor_lapangan'] ?></td>
                        <td><?= date('d/m/Y', strtotime($booking['tanggal'])) ?></td>
                        <td><?= $booking['jam_mulai'] ?> - <?= $booking['jam_selesai'] ?></td>
                        <td>Rp <?= number_format($booking['total_harga'], 0, ',', '.') ?></td>
                        <td><span class="status-badge status-<?= $booking['status'] ?>"><?= ucfirst($booking['status']) ?></span></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if(count($recent_bookings) == 0): ?>
                    <tr><td colspan="7" style="text-align: center;">Belum ada booking</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</body>
</html>