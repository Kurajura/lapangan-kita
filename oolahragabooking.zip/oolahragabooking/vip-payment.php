<?php
include 'config/database.php';
if (!isLoggedIn() || getUserRole() !== 'user') {
    header('Location: login.php?error=Silakan login sebagai user terlebih dahulu');
    exit();
}
$order_id = (int)($_GET['order_id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM vip_orders WHERE id = ? AND user_id = ?");
$stmt->execute([$order_id, getUserId()]);
$order = $stmt->fetch();
if (!$order) {
    header('Location: vip.php?error=Order VIP tidak ditemukan');
    exit();
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_payment'])) {
    $baseDate = date('Y-m-d');
    $stmt = $pdo->prepare("SELECT vip_until FROM users WHERE id = ?");
    $stmt->execute([getUserId()]);
    $oldUntil = $stmt->fetchColumn();
    if ($oldUntil && $oldUntil >= date('Y-m-d')) $baseDate = $oldUntil;
    $newUntil = date('Y-m-d', strtotime($baseDate . ' +' . (int)$order['duration_days'] . ' days'));
    $pdo->beginTransaction();
    try {
        $pdo->prepare("UPDATE vip_orders SET status = 'success', payment_date = NOW() WHERE id = ?")->execute([$order_id]);
        $pdo->prepare("UPDATE users SET vip_until = ?, vip_discount_percent = ? WHERE id = ?")->execute([$newUntil, $order['discount_percent'], getUserId()]);
        $pdo->commit();
        header('Location: vip.php?success=VIP berhasil aktif sampai ' . urlencode(date('d/m/Y', strtotime($newUntil))));
        exit();
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = 'Gagal konfirmasi VIP: ' . $e->getMessage();
    }
}
$qr_svg = generateQrSvg($order['qr_code'] ?: $order['transaction_code'], 300);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Bayar VIP - LapanganKita</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"><link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="top-header"><div class="promo-box">Bayar VIP <span>QR</span></div><div class="top-right"><div class="user-info"><i class="fa-regular fa-user"></i> <?= e($_SESSION['username']) ?> <a href="logout.php" style="color:#ff003c;">Logout</a></div></div></div>
<?php renderNavbar(''); ?>
<div class="public-page-wrap"><div class="form-card payment-qr-card">
<h2>Scan QR Pembayaran VIP</h2>
<?php if(isset($error)): ?><div class="alert-error"><?= e($error) ?></div><?php endif; ?>
<p>Total: <strong>Rp <?= number_format($order['amount'],0,',','.') ?></strong></p>
<p>Metode: <?= e(strtoupper($order['payment_method'])) ?> - <?= e($order['payment_channel']) ?></p>
<div class="qr-box-real"><?= $qr_svg ?><div class="qr-code-label"><?= e($order['transaction_code']) ?></div></div>
<p class="helper-text">Setelah pembayaran berhasil, klik tombol konfirmasi untuk mengaktifkan VIP.</p>
<form method="POST"><button class="btn-primary" name="confirm_payment">Konfirmasi Pembayaran VIP</button></form>
</div></div>
</body></html>
