<?php
include 'config/database.php';
if (!isLoggedIn() || getUserRole() !== 'user') {
    header('Location: login.php?error=Silakan login sebagai user terlebih dahulu');
    exit();
}

$vipPrice = 29000;
$durationDays = 30;
$discountPercent = 10;
$currentVip = null;
$stmt = $pdo->prepare("SELECT vip_until, vip_discount_percent FROM users WHERE id = ?");
$stmt->execute([getUserId()]);
$currentVip = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $payment_method = $_POST['payment_method'] ?? '';
    $payment_channel = $_POST['payment_channel'] ?? '';
    if ($payment_method === '' || $payment_channel === '') {
        $error = 'Pilih metode pembayaran VIP terlebih dahulu';
    } else {
        $transaction_code = 'VIP' . date('YmdHis') . rand(100,999);
        $qr = json_encode([
            'transaction_code' => $transaction_code,
            'amount' => $vipPrice,
            'method' => $payment_method,
            'channel' => $payment_channel,
            'duration_days' => $durationDays,
            'discount_percent' => $discountPercent
        ]);
        $stmt = $pdo->prepare("INSERT INTO vip_orders (user_id, amount, duration_days, discount_percent, payment_method, payment_channel, qr_code, transaction_code)
                               VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([getUserId(), $vipPrice, $durationDays, $discountPercent, $payment_method, $payment_channel, $qr, $transaction_code]);
        header('Location: vip-payment.php?order_id=' . $pdo->lastInsertId());
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VIP Member - LapanganKita</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="top-header"><div class="promo-box">VIP Member <span>MODE TANDING</span></div><div class="top-right"><div class="user-info"><i class="fa-regular fa-user"></i> <?= e($_SESSION['username']) ?> <a href="logout.php" style="color:#ff003c;">Logout</a></div></div></div>
<?php renderNavbar(''); ?>
<div class="public-page-wrap vip-page">
    <div class="vip-hero-card">
        <div>
            <span class="match-badge completed">VIP</span>
            <h1>Buka Mode Tanding + Diskon Booking</h1>
            <p>VIP diperlukan untuk mengaktifkan mode tanding solo maupun team. VIP juga memberi diskon otomatis saat booking lapangan.</p>
            <?php if(userHasActiveVip($pdo)): ?>
                <div class="alert-success">VIP kamu aktif sampai <?= date('d/m/Y', strtotime($currentVip['vip_until'])) ?>. Diskon booking <?= number_format((float)$currentVip['vip_discount_percent'], 0) ?>%.</div>
            <?php else: ?>
                <div class="alert-error">VIP belum aktif. Aktifkan VIP agar bisa memakai mode tanding.</div>
            <?php endif; ?>
        </div>
        <div class="vip-price-box">
            <small>Paket 30 Hari</small>
            <strong>Rp <?= number_format($vipPrice, 0, ',', '.') ?></strong>
            <span>Diskon booking <?= $discountPercent ?>%</span>
        </div>
    </div>

    <div class="form-card">
        <h2>Bayar VIP</h2>
        <?php if(isset($error)): ?><div class="alert-error"><?= e($error) ?></div><?php endif; ?>
        <form method="POST">
            <div class="payment-methods payment-methods-spacious">
                <button type="button" class="payment-btn" data-method="qris" data-channel="QRIS"><i class="fa-solid fa-qrcode"></i><span>QRIS</span><small>Scan semua e-wallet</small></button>
                <button type="button" class="payment-btn" data-method="ewallet" data-channel="DANA"><i class="fa-solid fa-wallet"></i><span>DANA</span><small>E-wallet</small></button>
                <button type="button" class="payment-btn" data-method="ewallet" data-channel="OVO"><i class="fa-solid fa-mobile-screen"></i><span>OVO</span><small>E-wallet</small></button>
                <button type="button" class="payment-btn" data-method="mbanking" data-channel="BCA Mobile"><i class="fa-solid fa-building-columns"></i><span>BCA Mobile</span><small>M-Banking</small></button>
                <button type="button" class="payment-btn" data-method="mbanking" data-channel="Mandiri Online"><i class="fa-solid fa-landmark"></i><span>Mandiri</span><small>M-Banking</small></button>
            </div>
            <input type="hidden" name="payment_method" id="payment_method" required>
            <input type="hidden" name="payment_channel" id="payment_channel" required>
            <button class="btn-primary" id="submitBtn" disabled>Aktifkan VIP Sekarang</button>
        </form>
    </div>
</div>
<script>
document.querySelectorAll('.payment-btn').forEach(btn => {
    btn.addEventListener('click', function(){
        document.querySelectorAll('.payment-btn').forEach(b => b.classList.remove('selected'));
        this.classList.add('selected');
        document.getElementById('payment_method').value = this.dataset.method;
        document.getElementById('payment_channel').value = this.dataset.channel;
        document.getElementById('submitBtn').disabled = false;
    });
});
</script>
</body>
</html>
